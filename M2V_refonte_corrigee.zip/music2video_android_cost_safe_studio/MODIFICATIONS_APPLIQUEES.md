# Modifications appliquées — refonte interface et sécurité vidéo

Cette version corrige les problèmes signalés pendant les tests sur smartphone.

## Interface

- Séparation claire en 3 modes :
  - Créer une vidéo depuis une chanson
  - Créer une vidéo depuis un texte
  - Corriger / améliorer une vidéo existante
- Ajout d'une zone visible de fichiers importés avec nom et durée quand la durée est disponible.
- Ajout d'un aperçu vidéo direct pour la vidéo source et pour la dernière vidéo exportée.
- Ajout de boutons pour écouter/ouvrir les fichiers, supprimer les sélections et relancer un import.
- Ajout d'une zone de progression plus visible et d'une zone résultat dédiée.

## Durée et export

- Le mode test 20 secondes est maintenant désactivé par défaut.
- Les vidéos créées depuis une chanson utilisent la durée complète de l'audio, sauf si l'utilisateur active volontairement le mode test.
- La correction vidéo conserve la durée complète de la vidéo originale, sauf si l'utilisateur active volontairement le mode test.

## Correction vidéo non destructive

- La vidéo originale n'est jamais remplacée.
- Le réglage par défaut est désormais : `Préserver original — copie non destructive`.
- Ce mode crée une copie de la vidéo originale sans la réencoder quand aucune image et aucune nouvelle musique ne sont demandées.
- Les corrections visuelles, remplacements d'images et remplacements audio créent toujours une nouvelle vidéo exportée.

## Lip-sync / smiley

- L'avatar lip-sync simple est maintenant désactivé par défaut.
- Il ne sera utilisé que si l'utilisateur coche volontairement l'option correspondante.

## Build

- Correction de l'erreur Java `illegal escape character` dans `LyricsEngine.java`.
- Correction de l'appel à `VideoCorrector.correct(...)` dans `MainActivity.java`.
- Ajout d'une fonction de copie non destructive dans `MediaMuxerTools.java`.
