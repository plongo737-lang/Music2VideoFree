package com.entilio.music2videofree;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_IMAGES = 1002;
    private static final int REQ_CORRECTION_VIDEO = 1003;
    private static final int REQ_CORRECTION_AUDIO = 1004;
    private static final int REQ_REPLACEMENT_IMAGES = 1005;
    private static final int REQ_TEXT_AUDIO = 1006;

    private Uri audioUri;
    private Uri textAudioUri;
    private Uri videoToCorrectUri;
    private Uri correctionAudioUri;
    private Uri lastOutputUri;

    private final ArrayList<Uri> imageUris = new ArrayList<>();
    private final ArrayList<Uri> replacementImageUris = new ArrayList<>();

    private LinearLayout modeContainer;
    private LinearLayout outputBox;
    private TextView statusText;
    private TextView songSelectionText;
    private TextView textSelectionText;
    private TextView correctionSelectionText;
    private TextView outputText;
    private ProgressBar progressBar;
    private VideoView sourceVideoPreview;
    private VideoView outputVideoPreview;

    private Spinner formatSpinner;
    private Spinner styleSpinner;
    private Spinner motionSpinner;
    private Spinner visualizerSpinner;
    private Spinner correctionSpinner;
    private Spinner replacementModeSpinner;
    private Spinner replacementMotionSpinner;
    private Spinner textDurationSpinner;
    private Spinner aiCostSpinner;

    private EditText songStoryEdit;
    private EditText textPromptEdit;

    private CheckBox lipSyncCheck;
    private CheckBox testModeCheck;
    private CheckBox useReplacementAudioCheck;
    private CheckBox blockPaidOptionsCheck;

    private Button songGenerateButton;
    private Button textGenerateButton;
    private Button correctionGenerateButton;
    private Button openButton;
    private TextView costSafetyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 17, 22));
        getWindow().setNavigationBarColor(Color.rgb(16, 17, 22));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16, 17, 22));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Music2Video Free Studio");
        title.setTextColor(Color.rgb(244, 241, 232));
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(4), 0, dp(6));
        root.addView(title);

        TextView subtitle = smallText("Studio local gratuit : vos fichiers restent sur le téléphone. L'original n'est jamais remplacé ; chaque rendu crée une nouvelle vidéo MP4 dans la galerie.");
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        root.addView(tabs);

        Button songTab = tabButton("Chanson");
        Button textTab = tabButton("Texte");
        Button correctionTab = tabButton("Correction");
        tabs.addView(songTab);
        tabs.addView(textTab);
        tabs.addView(correctionTab);
        songTab.setOnClickListener(v -> showSongMode());
        textTab.setOnClickListener(v -> showTextMode());
        correctionTab.setOnClickListener(v -> showCorrectionMode());

        modeContainer = new LinearLayout(this);
        modeContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.setPadding(0, dp(8), 0, dp(8));
        root.addView(modeContainer);

        buildProgressAndOutput(root);
        buildCostSafety(root);
        showSongMode();
        setContentView(scroll);
    }

    private void buildProgressAndOutput(LinearLayout root) {
        root.addView(sectionTitle("Progression et résultat"));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.VISIBLE);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(16));
        barParams.setMargins(0, dp(8), 0, dp(8));
        root.addView(progressBar, barParams);

        statusText = smallText("Prêt. Choisissez un mode ci-dessus.");
        root.addView(statusText);

        outputBox = card();
        outputBox.setVisibility(View.GONE);
        outputText = smallText("Aucune vidéo exportée pour le moment.");
        outputBox.addView(outputText);
        outputVideoPreview = new VideoView(this);
        outputBox.addView(outputVideoPreview, videoLayoutParams());
        openButton = secondaryButton("Ouvrir la dernière vidéo dans le lecteur du téléphone");
        openButton.setOnClickListener(v -> openLastVideo());
        outputBox.addView(openButton);
        root.addView(outputBox);
    }

    private void buildCostSafety(LinearLayout root) {
        root.addView(sectionTitle("Sécurité coûts / IA avancée"));
        TextView costIntro = smallText("Les fonctions cloud ou payantes restent verrouillées par défaut. Cette version ne contient aucune clé API et ne lance aucun paiement.");
        root.addView(costIntro);

        blockPaidOptionsCheck = new CheckBox(this);
        blockPaidOptionsCheck.setText("Bloquer toutes les options payantes/cloud — recommandé");
        blockPaidOptionsCheck.setTextColor(Color.rgb(244, 241, 232));
        blockPaidOptionsCheck.setChecked(true);
        root.addView(blockPaidOptionsCheck);

        root.addView(label("Option IA avancée à vérifier"));
        aiCostSpinner = spinner(CostPolicy.featureLabels());
        root.addView(aiCostSpinner);

        Button explainCostButton = secondaryButton("Voir coût, risque et alternative gratuite");
        explainCostButton.setOnClickListener(v -> showAiCostDialog(false));
        root.addView(explainCostButton);

        Button guardedLaunchButton = secondaryButton("Tester le verrouillage avant option payante");
        guardedLaunchButton.setOnClickListener(v -> showAiCostDialog(true));
        root.addView(guardedLaunchButton);

        costSafetyText = smallText("Statut : mode gratuit/offline. Aucune option payante n'est autorisée.");
        root.addView(costSafetyText);
    }

    private void showSongMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Créer une vidéo depuis une chanson"));
        modeContainer.addView(smallText("Importez la chanson, ajoutez des images si vous en avez, puis exportez une vidéo de la durée complète de la musique. Le mode 20 secondes est désactivé par défaut."));

        Button pickAudio = primaryButton("Choisir la musique");
        pickAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_AUDIO));
        modeContainer.addView(pickAudio);

        Button addImages = secondaryButton("Ajouter des images pour la vidéo");
        addImages.setOnClickListener(v -> pickMultiple("image/*", REQ_IMAGES));
        modeContainer.addView(addImages);

        LinearLayout fileActions = new LinearLayout(this);
        fileActions.setOrientation(LinearLayout.HORIZONTAL);
        Button openAudio = compactButton("Écouter");
        openAudio.setOnClickListener(v -> openUri(audioUri, "audio/*"));
        Button clearSong = compactButton("Supprimer fichiers");
        clearSong.setOnClickListener(v -> { audioUri = null; imageUris.clear(); updateSongSelectionText(); });
        fileActions.addView(openAudio);
        fileActions.addView(clearSong);
        modeContainer.addView(fileActions);

        songSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers importés", songSelectionText));
        updateSongSelectionText();

        modeContainer.addView(label("Histoire ou intention visuelle"));
        songStoryEdit = editText("Exemple : clip cinématographique noir et blanc dans un village portugais, scènes cohérentes avec la chanson, sans texte à l'écran…", 4);
        modeContainer.addView(songStoryEdit);

        addCommonVideoControls(modeContainer);

        lipSyncCheck = new CheckBox(this);
        lipSyncCheck.setText("Ajouter un avatar lip-sync simple / smiley — désactivé par défaut");
        lipSyncCheck.setTextColor(Color.rgb(244, 241, 232));
        lipSyncCheck.setChecked(false);
        modeContainer.addView(lipSyncCheck);

        addTestModeCheck(modeContainer);

        songGenerateButton = primaryButton("Générer la vidéo MP4 complète");
        songGenerateButton.setOnClickListener(v -> startSongRender());
        modeContainer.addView(songGenerateButton);
    }

    private void showTextMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Créer une vidéo depuis un texte"));
        modeContainer.addView(smallText("Écrivez une scène, un poème, un synopsis ou un storyboard. L'application crée des scènes animées locales, puis ajoute une musique optionnelle si vous en choisissez une."));

        textPromptEdit = editText("Écrivez votre histoire ou vos scènes ici…", 7);
        modeContainer.addView(textPromptEdit);

        Button pickTextAudio = secondaryButton("Ajouter une musique optionnelle");
        pickTextAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_TEXT_AUDIO));
        modeContainer.addView(pickTextAudio);

        Button clearTextAudio = secondaryButton("Supprimer la musique du mode texte");
        clearTextAudio.setOnClickListener(v -> { textAudioUri = null; updateTextSelectionText(); });
        modeContainer.addView(clearTextAudio);

        textSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers du mode texte", textSelectionText));
        updateTextSelectionText();

        modeContainer.addView(label("Durée si aucune musique n'est ajoutée"));
        textDurationSpinner = spinner(new String[]{"15 secondes", "30 secondes", "60 secondes", "90 secondes"});
        modeContainer.addView(textDurationSpinner);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        textGenerateButton = primaryButton("Créer la vidéo depuis le texte");
        textGenerateButton.setOnClickListener(v -> startTextRender());
        modeContainer.addView(textGenerateButton);
    }

    private void showCorrectionMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Corriger / améliorer une vidéo existante"));
        modeContainer.addView(smallText("Mode non destructif : la vidéo originale reste intacte. La correction crée une copie exportée. Par défaut, la durée et la motion originale sont préservées."));

        Button pickVideo = primaryButton("Choisir la vidéo à corriger");
        pickVideo.setOnClickListener(v -> pickSingle("video/*", REQ_CORRECTION_VIDEO));
        modeContainer.addView(pickVideo);

        sourceVideoPreview = new VideoView(this);
        sourceVideoPreview.setVisibility(videoToCorrectUri == null ? View.GONE : View.VISIBLE);
        modeContainer.addView(sourceVideoPreview, videoLayoutParams());
        if (videoToCorrectUri != null) prepareVideoPreview(sourceVideoPreview, videoToCorrectUri, false);

        Button pickReplacementImages = secondaryButton("Ajouter image(s) de remplacement optionnelle(s)");
        pickReplacementImages.setOnClickListener(v -> pickMultiple("image/*", REQ_REPLACEMENT_IMAGES));
        modeContainer.addView(pickReplacementImages);

        Button pickCorrectionAudio = secondaryButton("Ajouter nouvelle musique optionnelle");
        pickCorrectionAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_CORRECTION_AUDIO));
        modeContainer.addView(pickCorrectionAudio);

        Button clearCorrectionFiles = secondaryButton("Supprimer les fichiers de correction sélectionnés");
        clearCorrectionFiles.setOnClickListener(v -> {
            videoToCorrectUri = null;
            correctionAudioUri = null;
            replacementImageUris.clear();
            if (useReplacementAudioCheck != null) useReplacementAudioCheck.setChecked(false);
            updateCorrectionSelectionText();
            showCorrectionMode();
        });
        modeContainer.addView(clearCorrectionFiles);

        correctionSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers importés pour correction", correctionSelectionText));
        updateCorrectionSelectionText();

        modeContainer.addView(label("Type de correction"));
        correctionSpinner = spinner(new String[]{
                "Préserver original — copie non destructive",
                "Auto léger sans détruire",
                "Éclaircir",
                "Contraste fort",
                "Couleurs douces",
                "Noir et blanc cinéma",
                "Stabilisation visuelle légère"
        });
        modeContainer.addView(correctionSpinner);

        modeContainer.addView(label("Remplacement d'image"));
        replacementModeSpinner = spinner(new String[]{
                "Garder la vidéo originale",
                "Remplacer quelques scènes par les images",
                "Alterner vidéo originale et images",
                "Remplacer toute la vidéo par les images"
        });
        modeContainer.addView(replacementModeSpinner);

        modeContainer.addView(label("Motion des images remplacées"));
        replacementMotionSpinner = spinner(new String[]{
                "Garder motion similaire",
                "Motion corrigée douce",
                "Motion dynamique",
                "Motion pulse audio"
        });
        modeContainer.addView(replacementMotionSpinner);

        useReplacementAudioCheck = new CheckBox(this);
        useReplacementAudioCheck.setText("Remplacer l'audio par la nouvelle musique sélectionnée");
        useReplacementAudioCheck.setTextColor(Color.rgb(244, 241, 232));
        useReplacementAudioCheck.setChecked(false);
        modeContainer.addView(useReplacementAudioCheck);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        correctionGenerateButton = primaryButton("Créer une copie corrigée");
        correctionGenerateButton.setOnClickListener(v -> startVideoCorrection());
        modeContainer.addView(correctionGenerateButton);
    }

    private void addCommonVideoControls(LinearLayout parent) {
        parent.addView(label("Format d'export"));
        formatSpinner = spinner(new String[]{"YouTube 16:9", "TikTok / Reels 9:16", "Carré 1:1"});
        parent.addView(formatSpinner);

        parent.addView(label("Ambiance visuelle"));
        styleSpinner = spinner(new String[]{"Cinématique sombre", "Rêve lumineux", "Nature douce", "Sport chic", "Abstrait néon"});
        parent.addView(styleSpinner);

        parent.addView(label("Motion"));
        motionSpinner = spinner(new String[]{"Ken Burns", "Slide dynamique", "Pulse audio", "Rotation douce", "Shake dramatique"});
        parent.addView(motionSpinner);

        parent.addView(label("Visualiseur audio"));
        visualizerSpinner = spinner(new String[]{"Minimal", "Barres audio", "Anneau audio"});
        parent.addView(visualizerSpinner);
    }

    private void addTestModeCheck(LinearLayout parent) {
        testModeCheck = new CheckBox(this);
        testModeCheck.setText("Mode test : limiter à 20 secondes — désactivé par défaut");
        testModeCheck.setTextColor(Color.rgb(244, 241, 232));
        testModeCheck.setChecked(false);
        parent.addView(testModeCheck);
    }

    private void pickSingle(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    private void pickMultiple(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        final int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;

        if (requestCode == REQ_AUDIO && data.getData() != null) {
            audioUri = data.getData();
            persistReadPermission(audioUri, flags);
            updateSongSelectionText();
        } else if (requestCode == REQ_TEXT_AUDIO && data.getData() != null) {
            textAudioUri = data.getData();
            persistReadPermission(textAudioUri, flags);
            updateTextSelectionText();
        } else if (requestCode == REQ_IMAGES) {
            addReturnedUris(data, imageUris, flags);
            updateSongSelectionText();
        } else if (requestCode == REQ_REPLACEMENT_IMAGES) {
            addReturnedUris(data, replacementImageUris, flags);
            updateCorrectionSelectionText();
        } else if (requestCode == REQ_CORRECTION_VIDEO && data.getData() != null) {
            videoToCorrectUri = data.getData();
            persistReadPermission(videoToCorrectUri, flags);
            updateCorrectionSelectionText();
            showCorrectionMode();
        } else if (requestCode == REQ_CORRECTION_AUDIO && data.getData() != null) {
            correctionAudioUri = data.getData();
            persistReadPermission(correctionAudioUri, flags);
            if (useReplacementAudioCheck != null) useReplacementAudioCheck.setChecked(true);
            updateCorrectionSelectionText();
        }
    }

    private void addReturnedUris(Intent data, ArrayList<Uri> list, int flags) {
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < count; i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                list.add(uri);
                persistReadPermission(uri, flags);
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            list.add(uri);
            persistReadPermission(uri, flags);
        }
    }

    private void persistReadPermission(Uri uri, int flags) {
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
    }

    private void updateSongSelectionText() {
        if (songSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Musique : ").append(describeMedia(audioUri)).append("\n");
        sb.append("Images : ").append(imageUris.size()).append(imageUris.isEmpty() ? "" : " image(s) sélectionnée(s)").append("\n");
        if (!imageUris.isEmpty()) sb.append("Première image : ").append(nameOf(imageUris.get(0))).append("\n");
        sb.append("Contrôle : vous pouvez écouter la musique, supprimer les fichiers et relancer un import.");
        songSelectionText.setText(sb.toString());
    }

    private void updateTextSelectionText() {
        if (textSelectionText == null) return;
        textSelectionText.setText("Musique optionnelle : " + describeMedia(textAudioUri));
    }

    private void updateCorrectionSelectionText() {
        if (correctionSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Vidéo originale : ").append(describeMedia(videoToCorrectUri)).append("\n");
        sb.append("Images de remplacement : ").append(replacementImageUris.size()).append("\n");
        sb.append("Nouvelle musique : ").append(describeMedia(correctionAudioUri)).append("\n");
        sb.append("Règle : la vidéo source reste intacte ; l'export crée une nouvelle copie.");
        correctionSelectionText.setText(sb.toString());
    }

    private void startSongRender() {
        if (audioUri == null) {
            Toast.makeText(this, "Choisissez d'abord une musique.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageUris.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Aucune image ajoutée")
                    .setMessage("Sans images importées, le rendu local sera abstrait. Pour obtenir une histoire réaliste, ajoutez vos photos/images ou utilisez plus tard un module IA visuel explicitement activé.")
                    .setPositiveButton("Continuer", (d, w) -> renderSongNow())
                    .setNegativeButton("Ajouter des images", null)
                    .show();
        } else {
            renderSongNow();
        }
    }

    private void renderSongNow() {
        ProjectOptions options = readOptions();
        String story = songStoryEdit == null || songStoryEdit.getText() == null ? "" : songStoryEdit.getText().toString().trim();
        options.filmPrompt = story;
        setBusy(true, "Préparation de la vidéo depuis la chanson…");
        List<Uri> images = new ArrayList<>(imageUris);
        new Thread(() -> {
            try {
                Uri output = VideoComposer.compose(MainActivity.this, audioUri, images, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startTextRender() {
        String text = textPromptEdit == null || textPromptEdit.getText() == null ? "" : textPromptEdit.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "Écrivez d'abord un texte ou une histoire.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.textPrompt = text;
        options.textVideoSeconds = readTextSeconds();
        setBusy(true, "Préparation de la vidéo depuis le texte…");
        new Thread(() -> {
            try {
                Uri output = ImageVideoComposer.composeTextToVideo(MainActivity.this, text, textAudioUri, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo texte créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startVideoCorrection() {
        if (videoToCorrectUri == null) {
            Toast.makeText(this, "Choisissez d'abord une vidéo à corriger.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (useReplacementAudioCheck != null && useReplacementAudioCheck.isChecked() && correctionAudioUri == null) {
            Toast.makeText(this, "Choisissez une nouvelle musique ou décochez le remplacement audio.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.correctionPreset = correctionSpinner == null ? "Préserver original — copie non destructive" : String.valueOf(correctionSpinner.getSelectedItem());
        options.replacementMode = replacementModeSpinner == null ? "Garder la vidéo originale" : String.valueOf(replacementModeSpinner.getSelectedItem());
        options.replacementMotion = replacementMotionSpinner == null ? "Garder motion similaire" : String.valueOf(replacementMotionSpinner.getSelectedItem());
        Uri audioForCorrection = useReplacementAudioCheck != null && useReplacementAudioCheck.isChecked() ? correctionAudioUri : null;
        List<Uri> replacements = new ArrayList<>(replacementImageUris);

        setBusy(true, "Préparation de la copie corrigée…");
        new Thread(() -> {
            try {
                Uri output = VideoCorrector.correct(MainActivity.this, videoToCorrectUri, audioForCorrection, replacements, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Copie corrigée créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private ProjectOptions readOptions() {
        ProjectOptions o = new ProjectOptions();
        o.format = formatSpinner == null ? "YouTube 16:9" : String.valueOf(formatSpinner.getSelectedItem());
        o.style = styleSpinner == null ? "Cinématique sombre" : String.valueOf(styleSpinner.getSelectedItem());
        o.motion = motionSpinner == null ? "Ken Burns" : String.valueOf(motionSpinner.getSelectedItem());
        o.visualizer = visualizerSpinner == null ? "Minimal" : String.valueOf(visualizerSpinner.getSelectedItem());
        o.simpleLipSync = lipSyncCheck != null && lipSyncCheck.isChecked();
        o.testMode = testModeCheck != null && testModeCheck.isChecked();
        o.blockPaidOptions = blockPaidOptionsCheck == null || blockPaidOptionsCheck.isChecked();
        o.allowCloudAi = !o.blockPaidOptions;
        o.requireExplicitCostConsent = true;
        if (aiCostSpinner != null) o.selectedAdvancedAiFeature = String.valueOf(aiCostSpinner.getSelectedItem());

        if (o.format.contains("16:9")) {
            o.width = 1280;
            o.height = 720;
            o.bitrate = 4_500_000;
        } else if (o.format.contains("1:1")) {
            o.width = 1080;
            o.height = 1080;
            o.bitrate = 5_000_000;
        } else {
            o.width = 720;
            o.height = 1280;
            o.bitrate = 4_500_000;
        }
        return o;
    }

    private int readTextSeconds() {
        String v = textDurationSpinner == null ? "30 secondes" : String.valueOf(textDurationSpinner.getSelectedItem());
        if (v.startsWith("15")) return 15;
        if (v.startsWith("60")) return 60;
        if (v.startsWith("90")) return 90;
        return 30;
    }

    private void setBusy(boolean busy, String message) {
        if (songGenerateButton != null) songGenerateButton.setEnabled(!busy);
        if (textGenerateButton != null) textGenerateButton.setEnabled(!busy);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(!busy);
        if (openButton != null) openButton.setEnabled(!busy);
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        if (progressBar != null) progressBar.setProgress(0);
        if (statusText != null) statusText.setText(message);
        if (outputBox != null) outputBox.setVisibility(View.GONE);
    }

    private void finishJob(Uri output, String message) {
        lastOutputUri = output;
        statusText.setText(message);
        progressBar.setProgress(100);
        if (songGenerateButton != null) songGenerateButton.setEnabled(true);
        if (textGenerateButton != null) textGenerateButton.setEnabled(true);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
        if (openButton != null) openButton.setEnabled(true);
        if (outputBox != null) outputBox.setVisibility(View.VISIBLE);
        if (outputText != null) outputText.setText(message + "\nFichier : " + describeMedia(output));
        if (outputVideoPreview != null && output != null) prepareVideoPreview(outputVideoPreview, output, false);
    }

    private void failJob(Exception e) {
        String msg = e == null || e.getMessage() == null ? "erreur inconnue" : e.getMessage();
        statusText.setText("Erreur : " + msg);
        if (songGenerateButton != null) songGenerateButton.setEnabled(true);
        if (textGenerateButton != null) textGenerateButton.setEnabled(true);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
        progressBar.setVisibility(View.GONE);
        new AlertDialog.Builder(this)
                .setTitle("Erreur de rendu")
                .setMessage(msg)
                .setPositiveButton("Compris", null)
                .show();
    }

    private void openLastVideo() {
        openUri(lastOutputUri, "video/mp4");
    }

    private void openUri(Uri uri, String mimeType) {
        if (uri == null) {
            Toast.makeText(this, "Aucun fichier sélectionné.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, mimeType);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(intent); } catch (Exception e) { Toast.makeText(this, "Aucune application compatible trouvée.", Toast.LENGTH_SHORT).show(); }
    }

    private void prepareVideoPreview(VideoView view, Uri uri, boolean autoplay) {
        if (view == null || uri == null) return;
        view.setVisibility(View.VISIBLE);
        MediaController controller = new MediaController(this);
        controller.setAnchorView(view);
        view.setMediaController(controller);
        view.setVideoURI(uri);
        view.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            try { view.seekTo(autoplay ? 0 : 250); } catch (Exception ignored) {}
            if (autoplay) view.start();
        });
    }

    private String describeMedia(Uri uri) {
        if (uri == null) return "aucun fichier";
        long durationUs = MediaMuxerTools.getDurationUs(this, uri);
        String duration = durationUs > 0 ? " • durée " + formatDuration(durationUs) : "";
        return nameOf(uri) + duration;
    }

    private String nameOf(Uri uri) {
        if (uri == null) return "";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.trim().length() > 0) return name;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "fichier sélectionné" : last;
    }

    private String formatDuration(long durationUs) {
        long total = Math.max(0L, durationUs / 1_000_000L);
        long minutes = total / 60L;
        long seconds = total % 60L;
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private void showAiCostDialog(boolean attemptLaunch) {
        String label = aiCostSpinner == null ? "" : String.valueOf(aiCostSpinner.getSelectedItem());
        CostPolicy.CostInfo info = CostPolicy.infoFor(label);
        String message = CostPolicy.buildHumanMessage(info);

        if (!attemptLaunch) {
            new AlertDialog.Builder(this)
                    .setTitle("Information coût")
                    .setMessage(message)
                    .setPositiveButton("Compris", null)
                    .show();
            return;
        }

        if (blockPaidOptionsCheck == null || blockPaidOptionsCheck.isChecked()) {
            new AlertDialog.Builder(this)
                    .setTitle("Option bloquée")
                    .setMessage(message + "\n\nAction refusée : le blocage des options payantes/cloud est activé. Aucun coût ne peut être lancé.")
                    .setPositiveButton("Garder le blocage", null)
                    .show();
            if (costSafetyText != null) costSafetyText.setText("Statut : action bloquée. Aucun coût lancé.");
            return;
        }

        final EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setHint(CostPolicy.CONSENT_PHRASE);
        input.setTextColor(Color.rgb(20, 18, 14));
        new AlertDialog.Builder(this)
                .setTitle("Confirmation obligatoire")
                .setMessage(message + "\n\nPour confirmer volontairement dans une future version cloud, il faudra taper exactement : " + CostPolicy.CONSENT_PHRASE + "\n\nDans cette version, aucun service payant n'est configuré.")
                .setView(input)
                .setPositiveButton("Confirmer", (dialog, which) -> {
                    String typed = input.getText() == null ? "" : input.getText().toString().trim();
                    if (CostPolicy.CONSENT_PHRASE.equals(typed)) {
                        if (costSafetyText != null) costSafetyText.setText("Statut : consentement compris, mais aucun module payant n'est configuré. Aucun coût lancé.");
                        Toast.makeText(this, "Aucun service payant configuré : coût impossible.", Toast.LENGTH_LONG).show();
                    } else {
                        if (costSafetyText != null) costSafetyText.setText("Statut : confirmation incorrecte. Aucun coût lancé.");
                        Toast.makeText(this, "Confirmation incorrecte : action annulée.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Annuler", (dialog, which) -> {
                    if (costSafetyText != null) costSafetyText.setText("Statut : action annulée. Aucun coût lancé.");
                })
                .show();
    }

    private LinearLayout fileCard(String title, TextView body) {
        LinearLayout box = card();
        TextView t = label(title);
        t.setPadding(0, 0, 0, dp(6));
        box.addView(t);
        box.addView(body);
        return box;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackgroundColor(Color.rgb(28, 30, 38));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(244, 241, 232));
        v.setTextSize(20);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(18), 0, dp(8));
        return v;
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(216, 180, 93));
        v.setTextSize(14);
        v.setPadding(0, dp(12), 0, dp(4));
        return v;
    }

    private TextView smallText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(190, 188, 180));
        v.setTextSize(13);
        v.setLineSpacing(2, 1.08f);
        return v;
    }

    private EditText editText(String hint, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(Color.rgb(244, 241, 232));
        e.setHintTextColor(Color.rgb(150, 150, 145));
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setSingleLine(false);
        e.setBackgroundColor(Color.rgb(38, 40, 50));
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private Button primaryButton(String text) {
        Button b = baseButton(text);
        b.setTextColor(Color.rgb(20, 18, 14));
        b.setBackgroundColor(Color.rgb(216, 180, 93));
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = baseButton(text);
        b.setTextColor(Color.rgb(244, 241, 232));
        b.setBackgroundColor(Color.rgb(38, 40, 50));
        return b;
    }

    private Button compactButton(String text) {
        Button b = secondaryButton(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), dp(6), dp(3), dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private Button tabButton(String text) {
        Button b = secondaryButton(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private Button baseButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout.LayoutParams videoLayoutParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        lp.setMargins(0, dp(8), 0, dp(8));
        return lp;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class UiProgress implements ProgressCallback {
        @Override public void onStep(String message) {
            runOnUiThread(() -> statusText.setText(message));
        }
        @Override public void onProgress(int percent) {
            runOnUiThread(() -> progressBar.setProgress(Math.max(0, Math.min(100, percent))));
        }
    }
}
