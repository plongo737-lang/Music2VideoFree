# Music2VideoFree — version refonte

Cette archive contient la version corrigée après retour utilisateur : interface en 3 modes, fichiers importés visibles, aperçu vidéo, correction non destructive, mode 20 secondes désactivé par défaut et avatar lip-sync/smiley désactivé par défaut. Voir `MODIFICATIONS_APPLIQUEES.md`.

# Music2Video Free — Android Cost-Safe Studio

Projet Android Studio gratuit/offline pour créer et corriger des vidéos depuis une musique, des images, du texte ou un projet film guidé.

Cette version ajoute une protection importante : **aucune option IA payante/cloud ne peut être lancée par erreur**.

## Ce que fait cette version

- Sélection d'une musique depuis le téléphone : M4A/AAC conseillé, MP3 parfois accepté selon l'appareil.
- Sélection d'images optionnelles depuis la galerie.
- Export MP4 dans : **Galerie > Movies > Music2VideoFree**.
- Formats : TikTok/Reels 9:16, YouTube 16:9, Carré 1:1.
- Motions de mouvement : Ken Burns, slide dynamique, pulse audio, rotation douce, shake dramatique.
- Visualiseur audio : barres, anneau ou minimal.
- Lip-sync avatar simple : bouche animée par l'intensité de la voix/musique.
- Correction/réexport d'une vidéo existante : presets lumière, contraste, couleur, noir et blanc cinéma, stabilisation visuelle légère.
- Préparation des modules : Image -> Vidéo, Texte -> Vidéo, Texte -> Song, Song -> Vidéo, Film guidé, studio multipiste, mixage/mastering.
- Fonctionne localement avec les API Android natives : MediaCodec, MediaMuxer, MediaStore.

## Nouveau : sécurité coûts / IA avancée

L'application contient maintenant une section **Sécurité coûts / IA avancée**.

Par défaut :

- toutes les options payantes/cloud sont bloquées ;
- aucune clé API n'est incluse ;
- aucun service externe n'est appelé ;
- aucun paiement ne peut être déclenché ;
- les options IA lourdes affichent une alternative gratuite et un avertissement de coût.

Options protégées :

- transcription automatique précise des paroles depuis une chanson existante ;
- karaoké synchronisé mot par mot ;
- séparation voix/instrumental ;
- lip-sync réaliste sur visage/photo ;
- génération vidéo IA réaliste ;
- texte -> chanson avec vraie voix chantée.

Même si l'utilisateur décoche le blocage, la version actuelle ne lance aucun coût. Une future version cloud devra demander une confirmation explicite avec la phrase :

```text
J'ACCEPTE LE COUT
```

Voir :

- `COST_SAFETY_POLICY.md`
- `AI_COSTS_AND_FREE_OPTIONS.md`

## Important sur le lip-sync

Cette version inclut un **lip-sync simple gratuit/offline**, sous forme d'avatar dont la bouche réagit à l'audio.

Un lip-sync photo-réaliste sur un visage réel, comme faire chanter une photo, demande généralement :

1. un modèle IA lourd,
2. beaucoup de calcul,
3. parfois un serveur ou un service payant,
4. des vérifications de droits et de consentement pour les visages.

Le code est organisé pour pouvoir ajouter plus tard un module IA avancé, mais la première version reste volontairement gratuite, légère et installable.

## Installation avec Android Studio

1. Dézipper le dossier.
2. Ouvrir **Android Studio**.
3. Choisir **Open** puis sélectionner le dossier `music2video_android_cost_safe_studio`.
4. Laisser Android Studio synchroniser Gradle.
5. Brancher un téléphone Android ou lancer un émulateur.
6. Cliquer sur **Run** pour installer sur le téléphone.

Pour créer un fichier APK :

- Menu **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
- Android Studio affichera ensuite le chemin du fichier `app-debug.apk`.
- Pour publier sur Play Store, il faudra créer une version signée avec ta clé privée.

Configuration utilisée :

- `minSdk 29` : Android 10+
- `targetSdk 35`
- Java natif Android, sans librairie payante.
- Version app : `0.4.0-cost-safe`

## Générer l'APK depuis smartphone

Le projet contient toujours le workflow GitHub Actions dans `.github/workflows/build-apk.yml`.
Tu peux envoyer le projet dans un dépôt GitHub depuis ton smartphone, lancer l'action, puis télécharger l'APK généré.

Voir : `BUILD_APK_SUR_SMARTPHONE.md`

## Conseils d'utilisation

Pour le premier test :

1. Choisir une musique courte en **M4A/AAC**.
2. Ajouter 3 à 8 images.
3. Garder **Mode test : 20 secondes** activé.
4. Générer la vidéo.
5. Vérifier la vidéo dans la galerie.
6. Tester la section **Sécurité coûts / IA avancée** pour vérifier que rien de payant ne peut se lancer.

Quand le test fonctionne, désactiver le mode test pour générer toute la musique.

## Ressources gratuites pour images/vidéos

Tu peux utiliser des ressources gratuites en vérifiant toujours la licence de chaque média :

- Pexels
- Pixabay
- Unsplash
- Openverse

Attention aux visages, marques, monuments, œuvres d'art, logos, vêtements de marque et bâtiments privés : même si le média est gratuit, certains usages commerciaux peuvent nécessiter une autorisation.

## Limites de cette version MVP

- L'app sélectionne des images, pas encore des clips vidéo en entrée pour tous les modules.
- Le lip-sync réaliste sur photo n'est pas inclus dans cette version gratuite/offline.
- La transcription exacte automatique des paroles depuis une chanson existante est préparée mais doit passer par un module local/IA à ajouter.
- L'audio AAC/M4A est le format le plus fiable pour l'export MP4.
- Les longues vidéos peuvent prendre du temps selon la puissance du téléphone.

## Prochaines améliorations possibles

- Intégration locale Vosk/Whisper pour transcription offline.
- Import de clips vidéo courts.
- Timeline multipiste plus visuelle avec scènes déplaçables.
- Recherche intégrée de médias gratuits.
- Presets cinématiques pour chansons longues.
- Export 1080p/4K selon puissance du téléphone.
- Modules IA cloud optionnels uniquement avec coût affiché et consentement explicite.
