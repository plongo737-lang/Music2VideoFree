package com.entilio.music2videofree;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.List;
import java.util.Random;

public class BitmapFrameRenderer {
    private final int width;
    private final int height;
    private final List<Bitmap> images;
    private final ProjectOptions options;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random(7);

    public BitmapFrameRenderer(int width, int height, List<Bitmap> images, ProjectOptions options) {
        this.width = width;
        this.height = height;
        this.images = images;
        this.options = options;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    public void render(Bitmap target, float timeSec, int frameIndex, float rawLevel) {
        float level = clamp(rawLevel, 0f, 1f);
        Canvas canvas = new Canvas(target);
        drawBackground(canvas, timeSec, level);

        if (images != null && !images.isEmpty()) {
            drawPhotoMotion(canvas, timeSec, level);
        } else {
            drawGeneratedMotion(canvas, timeSec, frameIndex, level);
        }

        drawLightLeaks(canvas, timeSec, level);
        drawVisualizer(canvas, timeSec, level);
        if (options.simpleLipSync) {
            drawLipSyncAvatar(canvas, timeSec, level);
        }
        drawVignette(canvas);
    }

    private void drawBackground(Canvas c, float t, float level) {
        int[] colors = palette();
        LinearGradient gradient = new LinearGradient(
                0, 0, width, height,
                colors[0], colors[1], Shader.TileMode.CLAMP);
        paint.setShader(gradient);
        paint.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, width, height, paint);
        paint.setShader(null);

        paint.setColor(adjustAlpha(colors[2], 38));
        for (int i = 0; i < 5; i++) {
            float x = (float) (width * (0.15 + 0.18 * i + 0.03 * Math.sin(t * 0.55 + i)));
            float y = (float) (height * (0.12 + 0.13 * i + 0.04 * Math.cos(t * 0.45 + i * 2)));
            float r = width * (0.18f + level * 0.08f);
            RadialGradient rg = new RadialGradient(x, y, r,
                    adjustAlpha(colors[2], 42), adjustAlpha(colors[2], 0), Shader.TileMode.CLAMP);
            paint.setShader(rg);
            c.drawCircle(x, y, r, paint);
            paint.setShader(null);
        }
    }

    private void drawPhotoMotion(Canvas c, float timeSec, float level) {
        float segment = 5.6f;
        int index = ((int) (timeSec / segment)) % images.size();
        Bitmap bitmap = images.get(index);
        float p = (timeSec % segment) / segment;
        float cx = width / 2f;
        float cy = height / 2f;

        float cover = Math.max(width / (float) bitmap.getWidth(), height / (float) bitmap.getHeight());
        float baseW = bitmap.getWidth() * cover;
        float baseH = bitmap.getHeight() * cover;
        RectF dst = new RectF(-baseW / 2f, -baseH / 2f, baseW / 2f, baseH / 2f);

        float zoom = 1.08f;
        float dx = 0f;
        float dy = 0f;
        float rotate = 0f;
        String motion = options.motion == null ? "" : options.motion;
        if (motion.contains("fixe") || motion.contains("source")) {
            zoom = 1.0f;
            dx = 0f;
            dy = 0f;
            rotate = 0f;
        } else if (motion.contains("Ken Burns")) {
            zoom = 1.02f + 0.16f * p + level * 0.03f;
            dx = (p - 0.5f) * width * 0.09f;
            dy = (float) Math.sin(p * Math.PI) * height * 0.035f;
        } else if (motion.contains("Slide")) {
            zoom = 1.12f + level * 0.04f;
            dx = (float) Math.sin(timeSec * 0.62f) * width * 0.08f;
            dy = (float) Math.cos(timeSec * 0.48f) * height * 0.04f;
        } else if (motion.contains("Pulse")) {
            zoom = 1.05f + level * 0.13f;
        } else if (motion.contains("Rotation")) {
            zoom = 1.12f;
            rotate = (float) Math.sin(timeSec * 0.25f) * 2.4f;
        } else if (motion.contains("Shake")) {
            zoom = 1.10f + level * 0.04f;
            dx = (float) Math.sin(timeSec * 22f) * width * 0.006f * level;
            dy = (float) Math.cos(timeSec * 19f) * height * 0.006f * level;
            rotate = (float) Math.sin(timeSec * 18f) * 0.6f * level;
        }

        c.save();
        c.clipRect(0, 0, width, height);
        c.translate(cx + dx, cy + dy);
        c.rotate(rotate);
        c.scale(zoom, zoom);
        paint.setAlpha(255);
        c.drawBitmap(bitmap, null, dst, paint);
        c.restore();

        if (!(motion.contains("fixe") || motion.contains("source"))) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(adjustAlpha(Color.BLACK, 95));
            c.drawRect(0, 0, width, height, paint);
        }
    }

    private void drawGeneratedMotion(Canvas c, float t, int frameIndex, float level) {
        int[] colors = palette();
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 34; i++) {
            float seed = i * 13.13f;
            float x = (float) (width * (0.5 + 0.45 * Math.sin(t * (0.08 + i * 0.004) + seed)));
            float y = (float) (height * (0.5 + 0.45 * Math.cos(t * (0.10 + i * 0.005) + seed * 0.7)));
            float r = width * (0.006f + 0.024f * (0.2f + level)) * (1f + (i % 5) * 0.18f);
            paint.setColor(adjustAlpha(colors[2], 22 + (i % 4) * 16));
            c.drawCircle(x, y, r, paint);
        }

        stroke.setColor(adjustAlpha(colors[2], 90));
        stroke.setStrokeWidth(Math.max(2f, width * 0.003f));
        Path path = new Path();
        for (int yLine = 0; yLine < 4; yLine++) {
            path.reset();
            float baseY = height * (0.20f + yLine * 0.16f);
            path.moveTo(0, baseY);
            for (int x = 0; x <= width; x += 18) {
                float wave = (float) Math.sin(x * 0.012f + t * (1.2f + yLine * 0.32f)) * height * (0.012f + level * 0.03f);
                path.lineTo(x, baseY + wave);
            }
            c.drawPath(path, stroke);
        }
    }

    private void drawLightLeaks(Canvas c, float t, float level) {
        int[] colors = palette();
        paint.setStyle(Paint.Style.FILL);
        float x = (float) (width * (0.12 + 0.08 * Math.sin(t * 0.30)));
        float y = (float) (height * (0.15 + 0.06 * Math.cos(t * 0.24)));
        RadialGradient rg = new RadialGradient(x, y, width * (0.32f + level * 0.08f),
                adjustAlpha(colors[2], 44), adjustAlpha(colors[2], 0), Shader.TileMode.CLAMP);
        paint.setShader(rg);
        c.drawCircle(x, y, width * 0.45f, paint);
        paint.setShader(null);
    }

    private void drawVisualizer(Canvas c, float t, float level) {
        if (options.visualizer == null || options.visualizer.contains("Minimal")) return;
        int[] colors = palette();
        if (options.visualizer.contains("Anneau")) {
            drawRingVisualizer(c, t, level, colors);
        } else {
            drawBarsVisualizer(c, t, level, colors);
        }
    }

    private void drawBarsVisualizer(Canvas c, float t, float level, int[] colors) {
        int bars = 42;
        float margin = width * 0.08f;
        float areaW = width - margin * 2f;
        float gap = areaW / bars * 0.34f;
        float barW = areaW / bars - gap;
        float baseY = height * 0.88f;
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(Math.max(3f, barW));
        stroke.setColor(adjustAlpha(colors[2], 180));
        for (int i = 0; i < bars; i++) {
            float x = margin + i * (barW + gap) + barW / 2f;
            float local = (float) (0.22f + level * 0.78f * Math.abs(Math.sin(t * 5.3f + i * 0.55f)));
            float h = height * (0.025f + local * 0.12f);
            c.drawLine(x, baseY, x, baseY - h, stroke);
        }
    }

    private void drawRingVisualizer(Canvas c, float t, float level, int[] colors) {
        float cx = width / 2f;
        float cy = height * 0.34f;
        float base = Math.min(width, height) * 0.19f;
        stroke.setColor(adjustAlpha(colors[2], 168));
        stroke.setStrokeWidth(Math.max(4f, width * 0.006f));
        for (int i = 0; i < 72; i++) {
            double a = Math.toRadians(i * 5);
            float amp = (float) (1f + level * 0.55f * Math.abs(Math.sin(t * 6.0f + i * 0.33f)));
            float r1 = base;
            float r2 = base + width * 0.045f * amp;
            c.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                    cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, stroke);
        }
    }

    private void drawLipSyncAvatar(Canvas c, float t, float level) {
        int[] colors = palette();
        float faceR = Math.min(width, height) * 0.105f;
        float cx = width * 0.50f;
        float cy = height * (options.visualizer != null && options.visualizer.contains("Anneau") ? 0.34f : 0.69f);
        float bob = (float) Math.sin(t * 4.1f) * height * 0.004f * level;
        cy += bob;

        paint.setMaskFilter(new BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL));
        paint.setColor(adjustAlpha(Color.BLACK, 95));
        c.drawCircle(cx + width * 0.01f, cy + height * 0.012f, faceR * 1.06f, paint);
        paint.setMaskFilter(null);

        LinearGradient face = new LinearGradient(cx - faceR, cy - faceR, cx + faceR, cy + faceR,
                Color.rgb(228, 192, 142), Color.rgb(137, 88, 58), Shader.TileMode.CLAMP);
        paint.setShader(face);
        paint.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, faceR, paint);
        paint.setShader(null);

        paint.setColor(adjustAlpha(colors[2], 70));
        c.drawCircle(cx - faceR * 0.32f, cy - faceR * 0.26f, faceR * 0.13f, paint);
        c.drawCircle(cx + faceR * 0.32f, cy - faceR * 0.26f, faceR * 0.13f, paint);

        paint.setColor(Color.rgb(20, 14, 12));
        c.drawCircle(cx - faceR * 0.32f, cy - faceR * 0.26f, faceR * 0.045f, paint);
        c.drawCircle(cx + faceR * 0.32f, cy - faceR * 0.26f, faceR * 0.045f, paint);

        paint.setColor(Color.rgb(84, 38, 36));
        float mouthW = faceR * (0.30f + level * 0.20f);
        float mouthH = faceR * (0.08f + level * 0.44f);
        RectF mouth = new RectF(cx - mouthW, cy + faceR * 0.25f - mouthH / 2f,
                cx + mouthW, cy + faceR * 0.25f + mouthH / 2f);
        c.drawOval(mouth, paint);

        paint.setColor(adjustAlpha(Color.WHITE, 190));
        RectF shine = new RectF(cx - mouthW * 0.45f, cy + faceR * 0.25f - mouthH * 0.30f,
                cx + mouthW * 0.45f, cy + faceR * 0.25f - mouthH * 0.08f);
        c.drawOval(shine, paint);
    }

    private void drawVignette(Canvas c) {
        RadialGradient vignette = new RadialGradient(width / 2f, height / 2f,
                Math.max(width, height) * 0.75f,
                adjustAlpha(Color.BLACK, 0), adjustAlpha(Color.BLACK, 180), Shader.TileMode.CLAMP);
        paint.setShader(vignette);
        paint.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, width, height, paint);
        paint.setShader(null);
    }

    private int[] palette() {
        String s = options.style == null ? "" : options.style;
        if (s.contains("Rêve")) {
            return new int[]{Color.rgb(38, 27, 66), Color.rgb(244, 204, 218), Color.rgb(255, 214, 242)};
        } else if (s.contains("Nature")) {
            return new int[]{Color.rgb(10, 34, 28), Color.rgb(83, 119, 79), Color.rgb(180, 214, 141)};
        } else if (s.contains("Sport")) {
            return new int[]{Color.rgb(10, 11, 15), Color.rgb(42, 35, 24), Color.rgb(216, 180, 93)};
        } else if (s.contains("néon") || s.contains("Abstrait")) {
            return new int[]{Color.rgb(10, 9, 28), Color.rgb(18, 10, 45), Color.rgb(121, 235, 255)};
        }
        return new int[]{Color.rgb(10, 12, 18), Color.rgb(35, 26, 24), Color.rgb(216, 180, 93)};
    }

    private int adjustAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
