# Politique sécurité coût — Music2Video Free

Objectif : l'application doit rester gratuite/offline par défaut et ne jamais déclencher une dépense par erreur.

## Règles intégrées

1. **Aucune clé API dans l'application**
   - Pas de clé OpenAI, Google Cloud, Replicate, ElevenLabs, Suno, Udio ou autre service externe.
   - Aucun paiement ne peut être déclenché dans cette version.

2. **Blocage par défaut**
   - Le bouton **Bloquer toutes les options payantes/cloud** est activé par défaut.
   - Toute tentative d'option IA avancée affiche une fenêtre d'explication puis refuse l'action.

3. **Confirmation explicite obligatoire pour une future version cloud**
   - Même si le blocage est décoché, l'utilisateur devra taper exactement :

   ```text
   J'ACCEPTE LE COUT
   ```

   - Sans cette phrase exacte : annulation automatique.

4. **Affichage obligatoire avant traitement payant**
   Une future intégration cloud devra afficher avant tout lancement :
   - le nom du fournisseur ;
   - le tarif officiel ou le lien tarifaire ;
   - une estimation du coût total ;
   - la durée estimée ;
   - les fichiers qui seront envoyés ;
   - l'alternative gratuite/offline ;
   - le bouton annuler.

5. **Limites anti-surprise pour une future version cloud**
   - Coût maximal par opération, par exemple 1 € par défaut.
   - Coût mensuel maximal, par exemple 5 € par défaut.
   - Mode test court obligatoire avant vidéo longue.
   - Avertissement spécial si la vidéo dépasse 30 secondes.

## Fonctions gratuites/offline recommandées

- Montage vidéo local.
- Image -> vidéo local.
- Texte -> vidéo local.
- Song -> vidéo local.
- Motion design local.
- Remplacement d'images/scènes local.
- Studio multipiste local.
- Mixage/mastering simple local.
- Lip-sync avatar simple local.
- Transcription locale future avec Vosk/Whisper local si le téléphone le supporte.

## Fonctions qui doivent rester verrouillées tant qu'elles peuvent coûter

- Transcription audio cloud.
- Karaoké mot par mot cloud.
- Séparation voix/instrumental cloud.
- Lip-sync réaliste visage/photo cloud.
- Génération vidéo IA réaliste cloud.
- Texte -> chanson avec vraie voix chantée via service externe.

## Principe final

Le mode gratuit doit toujours fonctionner sans compte, sans abonnement, sans carte bancaire et sans internet.
Toute option non gratuite doit être visible, expliquée, estimée, confirmée et annulable.
