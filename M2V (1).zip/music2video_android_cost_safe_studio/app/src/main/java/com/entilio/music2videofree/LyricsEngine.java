package com.entilio.music2videofree;

import android.content.Context;
import android.net.Uri;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LyricsEngine {
    public static String generateOriginalLyrics(String theme, String mood) {
        String subject = cleanTheme(theme);
        String style = mood == null ? "pop cinématique" : mood.toLowerCase(Locale.ROOT);
        String hook = hookFor(subject, style);
        String tempoLine = style.contains("rap") ? "les mots frappent en cadence, je transforme le silence" :
                style.contains("emotion") || style.contains("émotion") ? "mon cœur garde la lumière au bord de la nuit" :
                style.contains("dance") ? "la nuit nous soulève, les lumières répondent" :
                "chaque image avance, portée par la musique";

        StringBuilder sb = new StringBuilder();
        sb.append("[Titre] ").append(titleCase(subject)).append("\n\n");
        sb.append("[Couplet 1]\n");
        sb.append("Je marche avec ").append(subject).append(" dans la poitrine\n");
        sb.append("Des souvenirs reviennent, mais je garde la ligne\n");
        sb.append("Dans le bruit du monde, je cherche mon chemin\n");
        sb.append("Je tombe, je me relève, je reprends demain\n\n");
        sb.append("[Pré-refrain]\n");
        sb.append("Et même quand la nuit veut fermer mes yeux\n");
        sb.append(tempoLine).append("\n\n");
        sb.append("[Refrain]\n");
        sb.append(hook).append("\n");
        sb.append("Je donne ma voix, je garde ma foi\n");
        sb.append(hook).append("\n");
        sb.append("Ce film dans mon âme devient plus grand que moi\n\n");
        sb.append("[Couplet 2]\n");
        sb.append("Les visages défilent comme un vieux cinéma\n");
        sb.append("Je choisis la lumière, même quand elle tremble bas\n");
        sb.append("Chaque pas raconte ce que je n'ai pas dit\n");
        sb.append("Chaque note dessine une part de ma vie\n\n");
        sb.append("[Pont]\n");
        sb.append("Si le passé revient, je ne baisse plus les bras\n");
        sb.append("Je transforme la peine en force dans ma voix\n\n");
        sb.append("[Refrain final]\n");
        sb.append(hook).append("\n");
        sb.append("Je donne ma voix, je garde ma foi\n");
        sb.append(hook).append("\n");
        sb.append("Et la vidéo s'allume autour de moi\n");
        return sb.toString();
    }

    public static String createExistingSongTranscriptionGuide(Context context, Uri audioUri, ProjectOptions options) {
        long durationUs = audioUri == null ? options.textSongDurationUs() : MediaMuxerTools.getDurationUs(context, audioUri);
        if (durationUs <= 0) durationUs = 60_000_000L;
        int seconds = (int) Math.max(8, durationUs / 1_000_000L);
        int lineCount = Math.max(6, Math.min(36, seconds / 7));
        StringBuilder sb = new StringBuilder();
        sb.append("[Transcription paroles existantes]\n");
        sb.append("Mode gratuit/offline : guide de synchronisation créé automatiquement depuis la durée audio.\n");
        sb.append("Pour obtenir les mots exacts automatiquement, ajoute le module IA Whisper/Vosk décrit dans TRANSCRIPTION_AND_AI_MODULES.md, ou colle les paroles exactes ici.\n\n");
        for (int i = 0; i < lineCount; i++) {
            int start = Math.round(i * seconds / (float) lineCount);
            int end = Math.round((i + 1) * seconds / (float) lineCount);
            sb.append("[").append(formatTime(start)).append(" - ").append(formatTime(end)).append("] ");
            sb.append("ligne de paroles à transcrire / remplacer\n");
        }
        return sb.toString();
    }

    public static List<String> splitForTimeline(String text) {
        List<String> lines = new ArrayList<>();
        if (text == null) return lines;
        String[] raw = text.replace("\r", "").split("\n");
        StringBuilder current = new StringBuilder();
        for (String line : raw) {
            String l = line.trim();
            if (l.isEmpty()) continue;
            if (l.startsWith("[Titre") || l.startsWith("[Couplet") || l.startsWith("[Refrain") ||
                    l.startsWith("[Pont") || l.startsWith("[Pré") || l.startsWith("[Transcription")) {
                continue;
            }
            if (l.matches("^\\[[0-9: .\u2013\u2014\-]+\\].*")) {
                l = l.replaceFirst("^\\[[^\\]]+\\]", "").trim();
            }
            if (l.length() == 0) continue;
            if (current.length() > 0) current.append("\n");
            current.append(l);
            if (current.length() > 70 || current.toString().contains("\n")) {
                lines.add(current.toString());
                current.setLength(0);
            }
        }
        if (current.length() > 0) lines.add(current.toString());
        if (lines.isEmpty() && text.trim().length() > 0) lines.add(text.trim());
        return lines;
    }

    public static String normalizePrompt(String text) {
        if (text == null) return "";
        return Normalizer.normalize(text.trim(), Normalizer.Form.NFC);
    }

    private static String cleanTheme(String theme) {
        String s = theme == null ? "l'espoir" : theme.trim();
        if (s.length() == 0) s = "l'espoir";
        if (s.length() > 48) s = s.substring(0, 48).trim();
        return s;
    }

    private static String titleCase(String text) {
        if (text == null || text.length() == 0) return "Chanson";
        return text.substring(0, 1).toUpperCase(Locale.ROOT) + text.substring(1);
    }

    private static String hookFor(String subject, String mood) {
        if (mood.contains("rap")) return "Je viens de loin, " + subject + " dans les veines";
        if (mood.contains("emotion") || mood.contains("émotion")) return "Je reste debout, même quand " + subject + " m'appelle";
        if (mood.contains("dance")) return "On danse avec " + subject + ", jusqu'au matin";
        return "Je suis encore là, porté par " + subject;
    }

    private static String formatTime(int seconds) {
        int m = Math.max(0, seconds) / 60;
        int s = Math.max(0, seconds) % 60;
        return String.format(Locale.US, "%02d:%02d", m, s);
    }
}
