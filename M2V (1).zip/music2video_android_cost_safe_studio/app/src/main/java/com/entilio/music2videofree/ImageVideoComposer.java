package com.entilio.music2videofree;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import java.io.File;
import java.util.List;

public class ImageVideoComposer {
    public static Uri composeImageToVideo(Context context, List<Uri> imageUris, ProjectOptions options,
                                          ProgressCallback callback) throws Exception {
        if (imageUris == null || imageUris.isEmpty()) throw new Exception("Ajoute au moins une image.");
        callback.onStep("Chargement des images pour Image → Vidéo…");
        List<Bitmap> images = ImageLoader.loadBitmaps(context, imageUris, 1800);
        if (images.isEmpty()) throw new Exception("Aucune image lisible.");
        long durationUs = options.textVideoDurationUs();
        int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));
        float[] levels = VideoEncoder.syntheticLevels(frameCount);
        File tempVideo = new File(context.getCacheDir(), "image_to_video_" + System.currentTimeMillis() + ".mp4");
        try {
            callback.onStep("Création de la vidéo depuis les images…");
            BitmapFrameRenderer renderer = new BitmapFrameRenderer(options.width, options.height, images, options);
            VideoEncoder.encodeVideoOnly(tempVideo, durationUs, options, levels,
                    (target, timeSec, frameIndex, level) -> renderer.render(target, timeSec, frameIndex, level),
                    callback, 10, 88);
            callback.onStep("Enregistrement dans la galerie…");
            Uri out = MediaMuxerTools.saveVideoOnlyToGallery(context, tempVideo, "image_to_video");
            callback.onProgress(100);
            return out;
        } finally {
            ImageLoader.recycle(images);
            if (tempVideo.exists()) tempVideo.delete();
        }
    }

    public static Uri composeTextToVideo(Context context, String text, Uri optionalAudioUri,
                                         ProjectOptions options, ProgressCallback callback) throws Exception {
        callback.onStep("Préparation des scènes texte…");
        List<Bitmap> scenes = TextMediaFactory.createTextSceneBitmaps(text, options);
        long durationUs = optionalAudioUri != null ? options.maxDurationUs(MediaMuxerTools.getDurationUs(context, optionalAudioUri)) : options.textVideoDurationUs();
        int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));
        float[] levels = optionalAudioUri != null ? AudioAnalyzer.analyze(context, optionalAudioUri, frameCount, options.fps) : VideoEncoder.syntheticLevels(frameCount);
        File tempVideo = new File(context.getCacheDir(), "text_to_video_" + System.currentTimeMillis() + ".mp4");
        try {
            callback.onStep("Animation du texte en vidéo…");
            BitmapFrameRenderer renderer = new BitmapFrameRenderer(options.width, options.height, scenes, options);
            VideoEncoder.encodeVideoOnly(tempVideo, durationUs, options, levels,
                    (target, timeSec, frameIndex, level) -> renderer.render(target, timeSec, frameIndex, level),
                    callback, 10, 86);
            callback.onStep(optionalAudioUri == null ? "Enregistrement dans la galerie…" : "Ajout de la chanson au MP4…");
            Uri out = optionalAudioUri == null
                    ? MediaMuxerTools.saveVideoOnlyToGallery(context, tempVideo, "text_to_video")
                    : MediaMuxerTools.muxVideoAndAudioToGallery(context, tempVideo, optionalAudioUri, durationUs, "text_song_video", callback);
            callback.onProgress(100);
            return out;
        } finally {
            ImageLoader.recycle(scenes);
            if (tempVideo.exists()) tempVideo.delete();
        }
    }
}
