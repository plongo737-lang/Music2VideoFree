package com.entilio.music2videofree;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.nio.ByteBuffer;
import java.util.Locale;

public class TextSongComposer {
    private static final int TIMEOUT_US = 10_000;

    public static Uri compose(Context context, String text, ProjectOptions options, ProgressCallback callback) throws Exception {
        String clean = text == null || text.trim().isEmpty() ? "Je suis encore là" : text.trim();
        long durationUs = options.textSongDurationUs();
        int sampleRate = 44100;
        int channels = 1;
        int bitRate = 128_000;
        long totalSamples = Math.max(1, durationUs * sampleRate / 1_000_000L);

        Uri outUri = MediaMuxerTools.createAudioUri(context, "text_to_song", ".m4a", "audio/mp4");
        ParcelFileDescriptor pfd = null;
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean success = false;
        try {
            callback.onStep("Composition Texte → Song…");
            pfd = context.getContentResolver().openFileDescriptor(outUri, "w");
            if (pfd == null) throw new Exception("Impossible d’ouvrir le fichier audio.");

            MediaFormat format = MediaFormat.createAudioFormat("audio/mp4a-latm", sampleRate, channels);
            format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitRate);
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024);

            encoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            boolean muxerStarted = false;
            int trackIndex = -1;
            long sampleCursor = 0;
            SongPlan plan = new SongPlan(clean, options);

            while (!outputDone) {
                if (!inputDone) {
                    int inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US);
                    if (inputIndex >= 0) {
                        ByteBuffer input = encoder.getInputBuffer(inputIndex);
                        if (input == null) continue;
                        input.clear();
                        int maxSamples = Math.max(256, input.remaining() / 2);
                        int samples = (int) Math.min(maxSamples, totalSamples - sampleCursor);
                        long ptsUs = sampleCursor * 1_000_000L / sampleRate;
                        if (samples <= 0) {
                            encoder.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            fillPcm(input, samples, sampleCursor, sampleRate, plan);
                            encoder.queueInputBuffer(inputIndex, 0, samples * 2, ptsUs, 0);
                            sampleCursor += samples;
                            int progress = 8 + Math.round((sampleCursor / (float) totalSamples) * 72f);
                            callback.onProgress(progress);
                        }
                    }
                }

                int outputIndex = encoder.dequeueOutputBuffer(info, TIMEOUT_US);
                if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    // Wait for more output.
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new RuntimeException("Format changed twice");
                    trackIndex = muxer.addTrack(encoder.getOutputFormat());
                    muxer.start();
                    muxerStarted = true;
                } else if (outputIndex >= 0) {
                    ByteBuffer output = encoder.getOutputBuffer(outputIndex);
                    if (output == null) throw new RuntimeException("Audio encoder buffer null");
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size != 0) {
                        if (!muxerStarted) throw new RuntimeException("Muxer audio non démarré");
                        output.position(info.offset);
                        output.limit(info.offset + info.size);
                        muxer.writeSampleData(trackIndex, output, info);
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    encoder.releaseOutputBuffer(outputIndex, false);
                }
            }
            callback.onProgress(96);
            success = true;
            return outUri;
        } finally {
            try { if (muxer != null) muxer.stop(); } catch (Exception ignored) {}
            if (muxer != null) muxer.release();
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
            if (pfd != null) pfd.close();
            MediaMuxerTools.finishPendingAudio(context, outUri, success);
        }
    }

    private static void fillPcm(ByteBuffer input, int samples, long startSample, int sampleRate, SongPlan plan) {
        for (int i = 0; i < samples; i++) {
            long globalSample = startSample + i;
            double t = globalSample / (double) sampleRate;
            double beat = t / plan.beatSeconds;
            int beatIndex = (int) Math.floor(beat);
            double beatPhase = beat - beatIndex;
            int chordIndex = (beatIndex / 4) % plan.chords.length;
            int noteSeed = plan.noteSeed(beatIndex);
            double melodyFreq = plan.root * plan.scale[(noteSeed + beatIndex) % plan.scale.length] * plan.octaveForBeat(beatIndex);
            double chordFreq = plan.root * plan.chords[chordIndex];

            double env = Math.exp(-beatPhase * 3.4) * (0.55 + 0.45 * Math.sin(Math.PI * Math.min(1.0, beatPhase * 2.0)));
            double vibrato = 1.0 + 0.006 * Math.sin(2.0 * Math.PI * 5.2 * t);
            double melody = Math.sin(2.0 * Math.PI * melodyFreq * vibrato * t) * 0.28 * env;
            double pad = (Math.sin(2.0 * Math.PI * chordFreq * t) + Math.sin(2.0 * Math.PI * chordFreq * 1.5 * t) * 0.6) * 0.10;
            double bass = Math.sin(2.0 * Math.PI * (plan.root / 2.0) * plan.chords[chordIndex] * t) * 0.17 * Math.exp(-beatPhase * 4.0);

            double kick = 0.0;
            if (beatIndex % 4 == 0 && beatPhase < 0.22) {
                kick = Math.sin(2.0 * Math.PI * (54 + 80 * (1 - beatPhase)) * t) * 0.35 * Math.exp(-beatPhase * 13);
            }
            double snare = 0.0;
            if ((beatIndex % 4 == 1 || beatIndex % 4 == 3) && beatPhase < 0.12) {
                snare = noise(globalSample) * 0.18 * Math.exp(-beatPhase * 18);
            }
            double hat = 0.0;
            double halfBeatPhase = (beat * 2.0) - Math.floor(beat * 2.0);
            if (halfBeatPhase < 0.08) hat = noise(globalSample * 7) * 0.06 * Math.exp(-halfBeatPhase * 18);

            double value = (melody + pad + bass + kick + snare + hat) * plan.masterGain;
            short pcm = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, (int) (value * 32767.0)));
            input.put((byte) (pcm & 0xff));
            input.put((byte) ((pcm >> 8) & 0xff));
        }
    }

    private static double noise(long x) {
        long n = (x << 13) ^ x;
        return 1.0 - ((n * (n * n * 15731L + 789221L) + 1376312589L) & 0x7fffffff) / 1073741824.0;
    }

    private static class SongPlan {
        final String text;
        final int hash;
        final double beatSeconds;
        final double root;
        final double[] scale;
        final double[] chords;
        final double masterGain;

        SongPlan(String text, ProjectOptions options) {
            this.text = text.toLowerCase(Locale.ROOT);
            this.hash = Math.abs(this.text.hashCode());
            String mood = options.textSongMood == null ? "" : options.textSongMood;
            int tempo = 88 + (hash % 34);
            if (mood.contains("Rap")) tempo = 92 + (hash % 22);
            if (mood.contains("Émotion")) tempo = 72 + (hash % 18);
            if (mood.contains("Dance")) tempo = 112 + (hash % 24);
            this.beatSeconds = 60.0 / tempo;
            this.root = mood.contains("Émotion") ? 220.0 : (mood.contains("Dance") ? 261.63 : 246.94);
            if (mood.contains("Émotion")) {
                this.scale = new double[]{1.0, 1.122, 1.189, 1.335, 1.498, 1.587, 1.782, 2.0};
                this.chords = new double[]{1.0, 1.335, 1.498, 1.122};
                this.masterGain = 0.76;
            } else if (mood.contains("Rap")) {
                this.scale = new double[]{1.0, 1.122, 1.335, 1.498, 1.682, 2.0};
                this.chords = new double[]{1.0, 1.0, 1.335, 1.122};
                this.masterGain = 0.84;
            } else {
                this.scale = new double[]{1.0, 1.125, 1.25, 1.333, 1.5, 1.667, 1.875, 2.0};
                this.chords = new double[]{1.0, 1.25, 1.5, 1.333};
                this.masterGain = 0.78;
            }
        }

        int noteSeed(int beatIndex) {
            if (text.length() == 0) return beatIndex;
            char c = text.charAt(Math.abs(beatIndex * 3 + hash) % text.length());
            return Math.abs(c + beatIndex + hash) % 97;
        }

        double octaveForBeat(int beatIndex) {
            return (beatIndex % 8 < 6) ? 1.0 : 2.0;
        }
    }
}
