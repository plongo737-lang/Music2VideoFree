package com.entilio.music2videofree;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MediaMuxerTools {
    public static long getDurationUs(Context context, Uri uri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, uri);
            String ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (ms == null) return 0;
            return Long.parseLong(ms) * 1000L;
        } catch (Exception e) {
            return 0;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    public static Uri saveVideoOnlyToGallery(Context context, File videoOnlyFile, String prefix) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        Uri outUri = createVideoUri(context, prefix);
        boolean success = false;
        try (OutputStream out = resolver.openOutputStream(outUri, "w");
             FileInputStream in = new FileInputStream(videoOnlyFile)) {
            if (out == null) throw new Exception("Impossible d’ouvrir le fichier de sortie.");
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            success = true;
        } finally {
            finishPendingVideo(context, outUri, success);
        }
        return outUri;
    }

    public static Uri muxVideoAndAudioToGallery(Context context, File videoOnlyFile, Uri audioSourceUri,
                                                long durationUs, String prefix, ProgressCallback callback) throws Exception {
        if (audioSourceUri == null) {
            return saveVideoOnlyToGallery(context, videoOnlyFile, prefix);
        }

        ContentResolver resolver = context.getContentResolver();
        Uri outUri = createVideoUri(context, prefix);
        MediaExtractor videoExtractor = new MediaExtractor();
        MediaExtractor audioExtractor = new MediaExtractor();
        ParcelFileDescriptor pfd = null;
        MediaMuxer muxer = null;
        boolean success = false;
        try {
            videoExtractor.setDataSource(videoOnlyFile.getAbsolutePath());
            int videoTrack = AudioAnalyzer.selectTrack(videoExtractor, false);
            if (videoTrack < 0) throw new Exception("Piste vidéo non trouvée.");
            MediaFormat videoFormat = videoExtractor.getTrackFormat(videoTrack);

            audioExtractor.setDataSource(context, audioSourceUri, null);
            int audioTrack = AudioAnalyzer.selectTrack(audioExtractor, true);
            MediaFormat audioFormat = audioTrack >= 0 ? audioExtractor.getTrackFormat(audioTrack) : null;

            pfd = resolver.openFileDescriptor(outUri, "w");
            if (pfd == null) throw new Exception("Impossible d’ouvrir le fichier de sortie.");
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int muxVideo = muxer.addTrack(videoFormat);
            int muxAudio = -1;
            if (audioFormat != null) {
                try { muxAudio = muxer.addTrack(audioFormat); } catch (Exception ignored) { muxAudio = -1; }
            }
            muxer.start();

            copyTrack(videoExtractor, videoTrack, muxer, muxVideo, durationUs);
            if (callback != null) callback.onProgress(90);
            if (muxAudio >= 0) {
                copyTrack(audioExtractor, audioTrack, muxer, muxAudio, durationUs);
            }
            if (callback != null) callback.onProgress(97);
            success = true;
        } finally {
            try { if (muxer != null) muxer.stop(); } catch (Exception ignored) {}
            if (muxer != null) muxer.release();
            if (pfd != null) pfd.close();
            videoExtractor.release();
            audioExtractor.release();
            finishPendingVideo(context, outUri, success);
        }
        return outUri;
    }

    public static Uri createAudioUri(Context context, String prefix, String extension, String mimeType) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.Audio.Media.DISPLAY_NAME, prefix + "_" + stamp + extension);
        values.put(MediaStore.Audio.Media.MIME_TYPE, mimeType);
        values.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Music2VideoFree");
        values.put(MediaStore.Audio.Media.IS_PENDING, 1);
        Uri uri = context.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Impossible de créer le fichier audio.");
        return uri;
    }

    public static void finishPendingAudio(Context context, Uri uri, boolean success) {
        try {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            context.getContentResolver().update(uri, done, null, null);
            if (!success) context.getContentResolver().delete(uri, null, null);
        } catch (Exception ignored) {}
    }

    private static Uri createVideoUri(Context context, String prefix) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, prefix + "_" + stamp + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Music2VideoFree");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri uri = context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Impossible de créer le fichier vidéo.");
        return uri;
    }

    private static void finishPendingVideo(Context context, Uri uri, boolean success) {
        try {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            context.getContentResolver().update(uri, done, null, null);
            if (!success) context.getContentResolver().delete(uri, null, null);
        } catch (Exception ignored) {}
    }

    private static void copyTrack(MediaExtractor extractor, int sourceTrack, MediaMuxer muxer, int muxTrack,
                                  long durationUs) {
        extractor.selectTrack(sourceTrack);
        ByteBuffer buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024);
        android.media.MediaCodec.BufferInfo info = new android.media.MediaCodec.BufferInfo();
        while (true) {
            buffer.clear();
            int sampleSize = extractor.readSampleData(buffer, 0);
            if (sampleSize < 0) break;
            long sampleTimeUs = extractor.getSampleTime();
            if (durationUs > 0 && sampleTimeUs > durationUs) break;
            info.set(0, sampleSize, Math.max(0, sampleTimeUs), extractor.getSampleFlags());
            muxer.writeSampleData(muxTrack, buffer, info);
            extractor.advance();
        }
    }
}
