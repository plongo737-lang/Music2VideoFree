package com.entilio.music2videofree;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_IMAGES = 1002;
    private static final int REQ_CORRECTION_VIDEO = 1003;
    private static final int REQ_CORRECTION_AUDIO = 1004;

    private Uri audioUri;
    private Uri videoToCorrectUri;
    private Uri correctionAudioUri;
    private final ArrayList<Uri> imageUris = new ArrayList<>();

    private TextView statusText;
    private TextView selectionText;
    private TextView correctionSelectionText;
    private ProgressBar progressBar;
    private Button generateButton;
    private Button correctVideoButton;
    private Button openButton;
    private Uri lastOutputUri;

    private Spinner formatSpinner;
    private Spinner styleSpinner;
    private Spinner motionSpinner;
    private Spinner visualizerSpinner;
    private Spinner correctionSpinner;
    private CheckBox lipSyncCheck;
    private CheckBox testModeCheck;
    private CheckBox useReplacementAudioCheck;
    private CheckBox blockPaidOptionsCheck;
    private Spinner aiCostSpinner;
    private TextView costSafetyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 17, 22));
        getWindow().setNavigationBarColor(Color.rgb(16, 17, 22));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16, 17, 22));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Music2Video Free");
        title.setTextColor(Color.rgb(244, 241, 232));
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(8), 0, dp(8));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Crée une vidéo MP4 depuis une musique, corrige une vidéo déjà créée et prépare les modules IA avancés avec sécurité anti-coût. Par défaut : local, gratuit, sans abonnement et sans lancement de paiement.");
        subtitle.setTextColor(Color.rgb(190, 188, 180));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, 0, 0, dp(16));
        root.addView(subtitle);

        root.addView(sectionTitle("Créer une nouvelle vidéo"));

        Button pickAudio = primaryButton("1. Choisir une musique");
        pickAudio.setOnClickListener(v -> pickAudio());
        root.addView(pickAudio);

        Button pickImages = secondaryButton("2. Ajouter des images optionnelles");
        pickImages.setOnClickListener(v -> pickImages());
        root.addView(pickImages);

        selectionText = smallText("Aucune musique sélectionnée. Les images sont optionnelles.");
        root.addView(selectionText);

        root.addView(label("Format d'export"));
        formatSpinner = spinner(new String[]{"TikTok / Reels 9:16", "YouTube 16:9", "Carré 1:1"});
        root.addView(formatSpinner);

        root.addView(label("Ambiance visuelle"));
        styleSpinner = spinner(new String[]{"Cinématique sombre", "Rêve lumineux", "Nature douce", "Sport chic", "Abstrait néon"});
        root.addView(styleSpinner);

        root.addView(label("Motion de mouvement"));
        motionSpinner = spinner(new String[]{"Ken Burns", "Slide dynamique", "Pulse audio", "Rotation douce", "Shake dramatique"});
        root.addView(motionSpinner);

        root.addView(label("Visualiseur audio"));
        visualizerSpinner = spinner(new String[]{"Barres audio", "Anneau audio", "Minimal"});
        root.addView(visualizerSpinner);

        lipSyncCheck = new CheckBox(this);
        lipSyncCheck.setText("Inclure lip-sync avatar simple");
        lipSyncCheck.setTextColor(Color.rgb(244, 241, 232));
        lipSyncCheck.setChecked(true);
        root.addView(lipSyncCheck);

        testModeCheck = new CheckBox(this);
        testModeCheck.setText("Mode test : exporter seulement 20 secondes");
        testModeCheck.setTextColor(Color.rgb(244, 241, 232));
        testModeCheck.setChecked(true);
        root.addView(testModeCheck);

        generateButton = primaryButton("3. Générer la vidéo MP4");
        generateButton.setOnClickListener(v -> startRender());
        root.addView(generateButton);

        root.addView(sectionTitle("Corriger une vidéo existante"));

        TextView correctionIntro = smallText("Importe une vidéo déjà créée puis réexporte-la avec des corrections simples : lumière, contraste, couleurs, noir et blanc cinéma, recadrage vers TikTok/YouTube/carré, ou nouvelle musique.");
        correctionIntro.setPadding(0, 0, 0, dp(8));
        root.addView(correctionIntro);

        Button pickVideo = secondaryButton("1. Choisir une vidéo à corriger");
        pickVideo.setOnClickListener(v -> pickVideoToCorrect());
        root.addView(pickVideo);

        Button pickCorrectionAudio = secondaryButton("2. Nouvelle musique optionnelle");
        pickCorrectionAudio.setOnClickListener(v -> pickCorrectionAudio());
        root.addView(pickCorrectionAudio);

        correctionSelectionText = smallText("Vidéo à corriger : aucune • Nouvelle musique : aucune");
        root.addView(correctionSelectionText);

        root.addView(label("Correction vidéo"));
        correctionSpinner = spinner(new String[]{
                "Auto léger",
                "Éclaircir",
                "Contraste fort",
                "Couleurs douces",
                "Noir et blanc cinéma",
                "Stabilisation visuelle légère"
        });
        root.addView(correctionSpinner);

        useReplacementAudioCheck = new CheckBox(this);
        useReplacementAudioCheck.setText("Remplacer l'audio par la nouvelle musique sélectionnée");
        useReplacementAudioCheck.setTextColor(Color.rgb(244, 241, 232));
        useReplacementAudioCheck.setChecked(false);
        root.addView(useReplacementAudioCheck);

        correctVideoButton = primaryButton("3. Corriger / réexporter la vidéo");
        correctVideoButton.setOnClickListener(v -> startVideoCorrection());
        root.addView(correctVideoButton);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(18));
        barParams.setMargins(0, dp(10), 0, dp(10));
        root.addView(progressBar, barParams);

        statusText = smallText("Prêt.");
        root.addView(statusText);

        openButton = secondaryButton("Ouvrir la dernière vidéo");
        openButton.setVisibility(View.GONE);
        openButton.setOnClickListener(v -> openLastVideo());
        root.addView(openButton);

        root.addView(sectionTitle("Sécurité coûts / IA avancée"));

        TextView costIntro = smallText("Toutes les fonctions qui pourraient coûter de l'argent sont verrouillées par défaut. L'app ne contient aucune clé API, ne lance aucun paiement et ne fait aucun appel cloud automatiquement.");
        costIntro.setPadding(0, 0, 0, dp(8));
        root.addView(costIntro);

        blockPaidOptionsCheck = new CheckBox(this);
        blockPaidOptionsCheck.setText("Bloquer toutes les options payantes/cloud — recommandé");
        blockPaidOptionsCheck.setTextColor(Color.rgb(244, 241, 232));
        blockPaidOptionsCheck.setChecked(true);
        root.addView(blockPaidOptionsCheck);

        root.addView(label("Option IA avancée à vérifier"));
        aiCostSpinner = spinner(CostPolicy.featureLabels());
        root.addView(aiCostSpinner);

        Button explainCostButton = secondaryButton("Voir coût, risque et alternative gratuite");
        explainCostButton.setOnClickListener(v -> showAiCostDialog(false));
        root.addView(explainCostButton);

        Button guardedLaunchButton = secondaryButton("Tester le verrouillage avant option payante");
        guardedLaunchButton.setOnClickListener(v -> showAiCostDialog(true));
        root.addView(guardedLaunchButton);

        costSafetyText = smallText("Statut : mode gratuit/offline. Aucune option payante n'est autorisée.");
        root.addView(costSafetyText);

        TextView note = smallText("Note : le lip-sync inclus est volontairement simple et gratuit/offline. La correction vidéo utilise un réencodage local image par image ; elle améliore l'apparence, mais ne remplace pas un vrai logiciel de montage professionnel. Les modules IA lourds sont documentés, verrouillés et doivent afficher leur coût avant toute activation.");
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void showAiCostDialog(boolean attemptLaunch) {
        String label = String.valueOf(aiCostSpinner.getSelectedItem());
        CostPolicy.CostInfo info = CostPolicy.infoFor(label);
        String message = CostPolicy.buildHumanMessage(info);

        if (!attemptLaunch) {
            new AlertDialog.Builder(this)
                    .setTitle("Information coût")
                    .setMessage(message)
                    .setPositiveButton("Compris", null)
                    .show();
            return;
        }

        if (blockPaidOptionsCheck.isChecked()) {
            new AlertDialog.Builder(this)
                    .setTitle("Option bloquée")
                    .setMessage(message + "\n\nAction refusée : le blocage des options payantes/cloud est activé. Aucun coût ne peut être lancé.")
                    .setPositiveButton("Garder le blocage", null)
                    .show();
            costSafetyText.setText("Statut : action bloquée. Aucun coût lancé.");
            return;
        }

        final EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setHint(CostPolicy.CONSENT_PHRASE);
        input.setTextColor(Color.rgb(20, 18, 14));

        new AlertDialog.Builder(this)
                .setTitle("Confirmation obligatoire")
                .setMessage(message + "\n\nPour confirmer volontairement dans une future version cloud, il faudra taper exactement : " + CostPolicy.CONSENT_PHRASE + "\n\nDans cette version, même après confirmation, aucun service payant n'est configuré.")
                .setView(input)
                .setPositiveButton("Confirmer", (dialog, which) -> {
                    String typed = input.getText() == null ? "" : input.getText().toString().trim();
                    if (CostPolicy.CONSENT_PHRASE.equals(typed)) {
                        costSafetyText.setText("Statut : consentement compris, mais aucun module payant n'est configuré dans cette version. Aucun coût lancé.");
                        Toast.makeText(this, "Aucun service payant configuré : coût impossible.", Toast.LENGTH_LONG).show();
                    } else {
                        costSafetyText.setText("Statut : confirmation incorrecte. Aucun coût lancé.");
                        Toast.makeText(this, "Confirmation incorrecte : action annulée.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Annuler", (dialog, which) -> {
                    costSafetyText.setText("Statut : action annulée. Aucun coût lancé.");
                })
                .show();
    }

    private void pickAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_AUDIO);
    }

    private void pickImages() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_IMAGES);
    }

    private void pickVideoToCorrect() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_CORRECTION_VIDEO);
    }

    private void pickCorrectionAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_CORRECTION_AUDIO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        final int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        if (requestCode == REQ_AUDIO && data.getData() != null) {
            audioUri = data.getData();
            persistReadPermission(audioUri, flags);
            updateSelectionText();
        } else if (requestCode == REQ_IMAGES) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    imageUris.add(uri);
                    persistReadPermission(uri, flags);
                }
            } else if (data.getData() != null) {
                Uri uri = data.getData();
                imageUris.add(uri);
                persistReadPermission(uri, flags);
            }
            updateSelectionText();
        } else if (requestCode == REQ_CORRECTION_VIDEO && data.getData() != null) {
            videoToCorrectUri = data.getData();
            persistReadPermission(videoToCorrectUri, flags);
            updateCorrectionSelectionText();
        } else if (requestCode == REQ_CORRECTION_AUDIO && data.getData() != null) {
            correctionAudioUri = data.getData();
            persistReadPermission(correctionAudioUri, flags);
            useReplacementAudioCheck.setChecked(true);
            updateCorrectionSelectionText();
        }
    }

    private void persistReadPermission(Uri uri, int flags) {
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
    }

    private void updateSelectionText() {
        String audio = audioUri == null ? "aucune" : "sélectionnée";
        selectionText.setText("Musique : " + audio + " • Images : " + imageUris.size());
    }

    private void updateCorrectionSelectionText() {
        String video = videoToCorrectUri == null ? "aucune" : "sélectionnée";
        String audio = correctionAudioUri == null ? "aucune" : "sélectionnée";
        correctionSelectionText.setText("Vidéo à corriger : " + video + " • Nouvelle musique : " + audio);
    }

    private void startRender() {
        if (audioUri == null) {
            Toast.makeText(this, "Choisis d'abord une musique.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        setBusy(true, "Préparation…");

        List<Uri> images = new ArrayList<>(imageUris);
        new Thread(() -> {
            try {
                Uri output = VideoComposer.compose(MainActivity.this, audioUri, images, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startVideoCorrection() {
        if (videoToCorrectUri == null) {
            Toast.makeText(this, "Choisis d'abord une vidéo à corriger.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (useReplacementAudioCheck.isChecked() && correctionAudioUri == null) {
            Toast.makeText(this, "Choisis une nouvelle musique ou décoche le remplacement audio.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.correctionPreset = String.valueOf(correctionSpinner.getSelectedItem());
        Uri audioForCorrection = useReplacementAudioCheck.isChecked() ? correctionAudioUri : null;

        setBusy(true, "Préparation de la correction…");
        new Thread(() -> {
            try {
                Uri output = VideoCorrector.correct(MainActivity.this, videoToCorrectUri, audioForCorrection, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo corrigée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private ProjectOptions readOptions() {
        ProjectOptions o = new ProjectOptions();
        o.format = String.valueOf(formatSpinner.getSelectedItem());
        o.style = String.valueOf(styleSpinner.getSelectedItem());
        o.motion = String.valueOf(motionSpinner.getSelectedItem());
        o.visualizer = String.valueOf(visualizerSpinner.getSelectedItem());
        o.simpleLipSync = lipSyncCheck.isChecked();
        o.testMode = testModeCheck.isChecked();
        o.blockPaidOptions = blockPaidOptionsCheck == null || blockPaidOptionsCheck.isChecked();
        o.allowCloudAi = !o.blockPaidOptions;
        o.requireExplicitCostConsent = true;
        if (aiCostSpinner != null) {
            o.selectedAdvancedAiFeature = String.valueOf(aiCostSpinner.getSelectedItem());
        }

        if (o.format.contains("16:9")) {
            o.width = 1280; o.height = 720; o.bitrate = 4_500_000;
        } else if (o.format.contains("1:1")) {
            o.width = 1080; o.height = 1080; o.bitrate = 5_000_000;
        } else {
            o.width = 720; o.height = 1280; o.bitrate = 4_500_000;
        }
        return o;
    }

    private void setBusy(boolean busy, String message) {
        generateButton.setEnabled(!busy);
        correctVideoButton.setEnabled(!busy);
        openButton.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        statusText.setText(message);
    }

    private void finishJob(Uri output, String message) {
        lastOutputUri = output;
        statusText.setText(message);
        progressBar.setProgress(100);
        generateButton.setEnabled(true);
        correctVideoButton.setEnabled(true);
        openButton.setVisibility(View.VISIBLE);
    }

    private void failJob(Exception e) {
        statusText.setText("Erreur : " + e.getMessage());
        generateButton.setEnabled(true);
        correctVideoButton.setEnabled(true);
        progressBar.setVisibility(View.GONE);
    }

    private void openLastVideo() {
        if (lastOutputUri == null) return;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(lastOutputUri, "video/mp4");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(intent); } catch (Exception e) { Toast.makeText(this, "Vidéo créée, mais aucune app vidéo trouvée.", Toast.LENGTH_SHORT).show(); }
    }

    private TextView sectionTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(244, 241, 232));
        v.setTextSize(20);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(24), 0, dp(8));
        return v;
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(216, 180, 93));
        v.setTextSize(14);
        v.setPadding(0, dp(14), 0, dp(4));
        return v;
    }

    private TextView smallText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(190, 188, 180));
        v.setTextSize(13);
        v.setLineSpacing(2, 1.08f);
        return v;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private Button primaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(20, 18, 14));
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(216, 180, 93));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(8), 0, dp(8));
        b.setLayoutParams(lp);
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(244, 241, 232));
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(38, 40, 50));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(8), 0, dp(8));
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class UiProgress implements ProgressCallback {
        @Override public void onStep(String message) {
            runOnUiThread(() -> statusText.setText(message));
        }
        @Override public void onProgress(int percent) {
            runOnUiThread(() -> progressBar.setProgress(Math.max(0, Math.min(100, percent))));
        }
    }
}
