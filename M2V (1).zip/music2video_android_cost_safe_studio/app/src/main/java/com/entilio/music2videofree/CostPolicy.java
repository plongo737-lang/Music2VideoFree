package com.entilio.music2videofree;

/**
 * Centralise la politique de coûts.
 * Important : aucune fonction listée ici ne lance un appel réseau ou un paiement.
 * Les options payantes restent bloquées tant qu'un futur module cloud/API n'est pas
 * ajouté volontairement avec une confirmation explicite utilisateur.
 */
public final class CostPolicy {
    public static final String CONSENT_PHRASE = "J'ACCEPTE LE COUT";

    private CostPolicy() {}

    public static String[] featureLabels() {
        return new String[]{
                "Transcription paroles depuis audio existant",
                "Karaoké synchronisé mot par mot",
                "Séparation voix / instrumental",
                "Lip-sync réaliste sur visage/photo",
                "Génération vidéo IA réaliste",
                "Texte -> chanson avec vraie voix chantée"
        };
    }

    public static CostInfo infoFor(String label) {
        if (label == null) label = "";
        if (label.startsWith("Transcription")) {
            return new CostInfo(
                    "Transcription paroles depuis audio existant",
                    "GRATUIT recommandé : transcription locale/offline avec Vosk ou Whisper local si le téléphone le supporte. Aucun paiement, mais résultat moins parfait sur musique avec bruit ou voix chantée.",
                    "PAYANT possible : API de transcription facturée à la minute. Exemple indicatif au 15/06/2026 : OpenAI gpt-4o-mini-transcribe environ 0,003 $/min, gpt-4o-transcribe environ 0,006 $/min ; Google Speech-to-Text V2 standard environ 0,016 $/min selon volume et conditions. Vérifier le tarif officiel avant activation.",
                    "Données envoyées si cloud : audio complet de la chanson. Ne jamais envoyer une chanson sans droits ou des voix privées sans consentement.");
        }
        if (label.startsWith("Karaoké")) {
            return new CostInfo(
                    "Karaoké synchronisé mot par mot",
                    "GRATUIT : synchronisation approximative par phrase ou par rythme, sans IA cloud. Suffisant pour une vidéo simple.",
                    "PAYANT possible : transcription avec alignement temporel mot par mot, généralement facturée à la minute audio ou incluse dans une API IA.",
                    "Données envoyées si cloud : audio + paroles. Vérifier les droits de la chanson.");
        }
        if (label.startsWith("Séparation")) {
            return new CostInfo(
                    "Séparation voix / instrumental",
                    "GRATUIT : conserver le mix original, baisser/monter le volume global, ou utiliser plus tard un modèle local si l'appareil est assez puissant.",
                    "PAYANT possible : séparation par serveur GPU. La facturation se fait souvent au temps de calcul ou à la minute traitée. Coût exact à confirmer avant chaque traitement.",
                    "Données envoyées si cloud : fichier audio complet. Attention aux œuvres protégées.");
        }
        if (label.startsWith("Lip-sync")) {
            return new CostInfo(
                    "Lip-sync réaliste sur visage/photo",
                    "GRATUIT : avatar simple offline déjà inclus, bouche animée par intensité audio.",
                    "PAYANT possible : modèle IA vidéo/visage sur serveur GPU, souvent facturé par seconde de vidéo ou temps GPU. Toujours demander estimation avant rendu.",
                    "Données envoyées si cloud : visage/photo + audio. Utiliser uniquement des visages avec autorisation explicite.");
        }
        if (label.startsWith("Génération vidéo")) {
            return new CostInfo(
                    "Génération vidéo IA réaliste",
                    "GRATUIT : mode film stylisé offline avec photos personnelles, décors importés, motions et timeline multipiste.",
                    "PAYANT possible : génération vidéo par IA facturée à la seconde. Exemple indicatif au 15/06/2026 : certains modèles publics indiquent des tarifs autour de 0,09 $/s à 0,25 $/s selon résolution/fournisseur ; OpenAI liste aussi des modèles vidéo facturés à la seconde. Vérifier le tarif officiel avant activation.",
                    "Données envoyées si cloud : prompts, images, visages, décors, audio. Risque de coût élevé sur vidéos longues.");
        }
        return new CostInfo(
                "Texte -> chanson avec vraie voix chantée",
                "GRATUIT : générateur simple offline avec paroles, mélodie synthétique, TTS Android ou instrumental basique.",
                "PAYANT possible : service de chant IA ou voix réaliste par abonnement/crédits/API. Le prix dépend du fournisseur, de la durée et des droits d'utilisation commerciale.",
                "Données envoyées si cloud : texte, voix de référence éventuelle, musique. Ne pas cloner une voix sans autorisation.");
    }

    public static String buildHumanMessage(CostInfo info) {
        return info.title + "\n\n"
                + info.freeAlternative + "\n\n"
                + info.paidWarning + "\n\n"
                + info.dataWarning + "\n\n"
                + "Sécurité intégrée : cette application ne lance aucun coût automatiquement. Pour une future version cloud, l'utilisateur devra voir le coût estimé, décocher le blocage, puis taper exactement : " + CONSENT_PHRASE;
    }

    public static final class CostInfo {
        public final String title;
        public final String freeAlternative;
        public final String paidWarning;
        public final String dataWarning;

        public CostInfo(String title, String freeAlternative, String paidWarning, String dataWarning) {
            this.title = title;
            this.freeAlternative = freeAlternative;
            this.paidWarning = paidWarning;
            this.dataWarning = dataWarning;
        }
    }
}
