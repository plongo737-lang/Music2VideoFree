# Options IA : coûts possibles et alternatives gratuites

Document de conception pour garder l'application gratuite par défaut.

## Transcription des paroles d'une chanson existante

- **Gratuit/offline conseillé** : Vosk local ou Whisper local/whisper.cpp si l'appareil est assez puissant.
- **Limite gratuite** : moins précis sur les chansons chantées, les voix avec effets, les chœurs et les mix très chargés.
- **Payant possible** : API de transcription facturée à la minute.
- **Sécurité** : ne jamais envoyer l'audio au cloud sans confirmation.

## Karaoké mot par mot

- **Gratuit/offline conseillé** : synchronisation approximative par phrase ou par rythme.
- **Payant possible** : transcription + alignement mot par mot sur serveur.
- **Sécurité** : afficher coût/minute et fichier envoyé.

## Séparation voix / instrumental

- **Gratuit/offline possible** : futur modèle local si téléphone assez puissant ; sinon mixer le fichier original.
- **Payant possible** : serveur GPU facturé au temps de traitement.
- **Sécurité** : mode test court obligatoire avant chanson complète.

## Lip-sync réaliste visage/photo

- **Gratuit/offline inclus** : avatar simple dont la bouche suit l'intensité audio.
- **Payant possible** : IA vidéo/visage sur GPU ou service externe.
- **Sécurité** : consentement visage obligatoire, coût estimé par seconde, pas de lancement automatique.

## Génération vidéo IA réaliste

- **Gratuit/offline conseillé** : film stylisé avec photos importées, personnages, décor, motions et timeline multipiste.
- **Payant possible** : génération vidéo IA facturée à la seconde de sortie ou par crédits.
- **Sécurité** : avertissement de coût élevé pour vidéos longues.

## Texte -> chanson avec vraie voix chantée

- **Gratuit/offline inclus** : mélodie synthétique, TTS Android ou instrumental simple.
- **Payant possible** : service externe de chant IA, abonnement ou crédits.
- **Sécurité** : pas de clonage de voix sans autorisation.
