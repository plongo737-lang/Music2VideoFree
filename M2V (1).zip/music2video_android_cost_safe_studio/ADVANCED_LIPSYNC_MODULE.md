# Module avancé lip-sync / IA lourde

Le lip-sync réaliste sur visage/photo n'est pas activé dans la version gratuite/offline.

## Ce qui est inclus gratuitement

- Avatar simple offline.
- Bouche animée par intensité audio.
- Aucun cloud.
- Aucun coût.

## Ce qui demanderait une IA lourde

- Faire chanter une photo réaliste.
- Remplacer un visage dans une vidéo.
- Générer des expressions faciales réalistes.
- Synchroniser précisément lèvres, phonèmes et émotions.

## Sécurité obligatoire avant une future intégration

Toute future intégration IA cloud doit respecter `COST_SAFETY_POLICY.md` :

- prix affiché avant traitement ;
- estimation totale ;
- fichiers envoyés clairement listés ;
- consentement visage/personne ;
- bouton annuler ;
- phrase obligatoire : `J'ACCEPTE LE COUT` ;
- aucun lancement automatique ;
- limite de coût par opération.

## Recommandation

Pour garder l'application gratuite, privilégier :

1. avatar simple offline ;
2. personnages stylisés ;
3. photos importées avec motion ;
4. montage multipiste local.
