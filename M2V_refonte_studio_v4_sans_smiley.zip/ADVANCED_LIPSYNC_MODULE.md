# Module avancé lip-sync / IA lourde

L’ancien avatar/smiley lip-sync simple a été supprimé, car il ne correspond pas à l’objectif professionnel du projet.

La direction V4 privilégie un lip-sync plus utile :

- intégrer une vraie vidéo du chanteur dans une vidéo narrative ;
- synchroniser cette vidéo avec l’audio final ;
- proposer fond vert/chroma key, adoucissement des bords, placement par timecode ;
- préparer une connexion future à des modules optionnels comme SadTalker, Wav2Lip, ComfyUI ou autres workflows installés volontairement.

## Ce qui reste gratuit/local

- Fusion vidéo dans vidéo.
- Placement par timecode.
- Pistes séparées dans le studio.
- Synchronisation simple avec l’audio sélectionné.
- Aucun cloud lancé automatiquement.
- Aucun coût automatique.

## Ce qui demanderait une IA lourde

- Faire chanter une photo réaliste.
- Remplacer précisément un visage dans une vidéo.
- Générer des expressions faciales réalistes.
- Synchroniser précisément lèvres, phonèmes et émotions.

## Sécurité obligatoire avant une future intégration

Toute future intégration IA cloud doit respecter `COST_SAFETY_POLICY.md` :

- prix affiché avant traitement ;
- estimation totale ;
- fichiers envoyés clairement listés ;
- consentement visage/personne ;
- bouton annuler ;
- phrase obligatoire : `J'ACCEPTE LE COUT` ;
- aucun lancement automatique ;
- limite de coût par opération.
