package com.entilio.music2videofree;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideoCorrector {
    public static Uri correct(Context context, Uri videoUri, Uri replacementAudioUri, List<Uri> replacementImageUris,
                              ProjectOptions options, ProgressCallback callback) throws Exception {
        String preset = options == null || options.correctionPreset == null ? "" : options.correctionPreset;
        boolean noReplacementImages = replacementImageUris == null || replacementImageUris.isEmpty();
        boolean preserveOriginal = preset.contains("Préserver") || preset.contains("copie non destructive");
        if (preserveOriginal && replacementAudioUri == null && noReplacementImages) {
            callback.onStep("Copie non destructive de la vidéo originale…");
            Uri copy = MediaMuxerTools.copyVideoUriToGallery(context, videoUri, "video_original_copy", callback);
            callback.onProgress(100);
            return copy;
        }

        callback.onStep("Lecture de la vidéo à corriger…");
        long fullDurationUs = MediaMuxerTools.getDurationUs(context, videoUri);
        if (fullDurationUs <= 0) fullDurationUs = 20_000_000L;
        long durationUs = options.maxDurationUs(fullDurationUs);
        int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));
        float[] levels = VideoEncoder.syntheticLevels(frameCount);

        callback.onStep("Chargement des images de remplacement…");
        List<Bitmap> replacements = replacementImageUris == null ? new ArrayList<>() : ImageLoader.loadBitmaps(context, replacementImageUris, 1800);
        File tempVideo = new File(context.getCacheDir(), "corrected_video_" + System.currentTimeMillis() + ".mp4");
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, videoUri);
            CorrectionFrameDrawer drawer = new CorrectionFrameDrawer(retriever, replacements, options);
            callback.onStep(replacements.isEmpty() ? "Correction image par image…" : "Remplacement des plans avec motion…");
            VideoEncoder.encodeVideoOnly(tempVideo, durationUs, options, levels, drawer, callback, 8, 86);
            callback.onStep(replacementAudioUri == null ? "Conservation de l'audio d'origine…" : "Remplacement de l'audio…");
            Uri audioSource = replacementAudioUri == null ? videoUri : replacementAudioUri;
            Uri output = MediaMuxerTools.muxVideoAndAudioToGallery(context, tempVideo, audioSource, durationUs, "video_corrected", callback);
            callback.onProgress(100);
            return output;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
            ImageLoader.recycle(replacements);
            if (tempVideo.exists()) tempVideo.delete();
        }
    }

    private static class CorrectionFrameDrawer implements VideoEncoder.FrameDrawer {
        private final MediaMetadataRetriever retriever;
        private final List<Bitmap> replacements;
        private final ProjectOptions options;
        private final ProjectOptions replacementOptions;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final BitmapFrameRenderer replacementRenderer;

        CorrectionFrameDrawer(MediaMetadataRetriever retriever, List<Bitmap> replacements, ProjectOptions options) {
            this.retriever = retriever;
            this.replacements = replacements;
            this.options = options;
            this.replacementOptions = copyOptions(options);
            String rm = options.replacementMotion == null ? "" : options.replacementMotion;
            if (rm.contains("fixe") || rm.contains("source")) replacementOptions.motion = "Image fixe sans mouvement";
            if (rm.contains("corrigée")) replacementOptions.motion = "Ken Burns";
            if (rm.contains("dynamique")) replacementOptions.motion = "Slide dynamique";
            if (rm.contains("douce")) replacementOptions.motion = "Rotation douce";
            if (rm.contains("pulse")) replacementOptions.motion = "Pulse audio";
            this.replacementRenderer = replacements == null || replacements.isEmpty() ? null
                    : new BitmapFrameRenderer(options.width, options.height, replacements, replacementOptions);
        }

        @Override
        public void render(Bitmap target, float timeSec, int frameIndex, float level) throws Exception {
            boolean useReplacement = shouldUseReplacement(timeSec);
            if (useReplacement && replacementRenderer != null) {
                replacementRenderer.render(target, timeSec, frameIndex, level);
                applyCorrectionOverlay(target, timeSec, level);
            } else {
                drawOriginalFrame(target, timeSec, level);
            }
        }

        private boolean shouldUseReplacement(float timeSec) {
            if (replacements == null || replacements.isEmpty()) return false;
            if (!options.hasImageReplacement()) return false;
            if (options.shouldReplaceAllScenes()) return true;
            float startSec = Math.max(0f, options.replacementStartTimeUs / 1_000_000f);
            float segmentSec = Math.max(0.5f, options.replacementSegmentDurationUs / 1_000_000f);
            if (timeSec < startSec) return false;
            int segment = Math.max(0, (int) ((timeSec - startSec) / segmentSec));
            if (options.shouldUseTimecodedReplacement()) return segment < replacements.size();
            if (options.shouldAlternateReplacement()) return segment % 2 == 0;
            return segment < replacements.size();
        }

        private void drawOriginalFrame(Bitmap target, float timeSec, float level) {
            Canvas c = new Canvas(target);
            c.drawColor(Color.BLACK);
            Bitmap frame = null;
            try {
                frame = retriever.getFrameAtTime((long) (timeSec * 1_000_000L), MediaMetadataRetriever.OPTION_CLOSEST);
            } catch (Exception ignored) {}
            if (frame == null) {
                paint.setColor(Color.rgb(18, 18, 22));
                c.drawRect(0, 0, target.getWidth(), target.getHeight(), paint);
                return;
            }
            try {
                paint.setColorFilter(colorFilterForPreset(options.correctionPreset));
                float cover = options.noCropZoom ? Math.min(target.getWidth() / (float) frame.getWidth(), target.getHeight() / (float) frame.getHeight()) : Math.max(target.getWidth() / (float) frame.getWidth(), target.getHeight() / (float) frame.getHeight());
                float zoom = correctionZoom(timeSec, level);
                float w = frame.getWidth() * cover * zoom;
                float h = frame.getHeight() * cover * zoom;
                float dx = options.lockSourceMotion ? 0f : (float) Math.sin(timeSec * 0.28f) * target.getWidth() * 0.01f;
                float dy = options.lockSourceMotion ? 0f : (float) Math.cos(timeSec * 0.22f) * target.getHeight() * 0.008f;
                RectF dst = new RectF(target.getWidth() / 2f - w / 2f + dx,
                        target.getHeight() / 2f - h / 2f + dy,
                        target.getWidth() / 2f + w / 2f + dx,
                        target.getHeight() / 2f + h / 2f + dy);
                c.drawBitmap(frame, null, dst, paint);
                paint.setColorFilter(null);
                applyCorrectionOverlay(target, timeSec, level);
            } finally {
                if (!frame.isRecycled()) frame.recycle();
                paint.setColorFilter(null);
            }
        }

        private void applyCorrectionOverlay(Bitmap target, float timeSec, float level) {
            String preset = options.correctionPreset == null ? "" : options.correctionPreset;
            if (options.preserveOriginalAmbience || preset.contains("Préserver") || preset.contains("timecodé") || preset.contains("ambiance")) return;
            Canvas c = new Canvas(target);
            paint.setStyle(Paint.Style.FILL);
            if (preset.contains("Noir")) {
                paint.setColor(Color.argb(36, 216, 180, 93));
                c.drawRect(0, 0, target.getWidth(), target.getHeight(), paint);
            } else if (preset.contains("Éclaircir")) {
                paint.setColor(Color.argb(24, 255, 244, 220));
                c.drawRect(0, 0, target.getWidth(), target.getHeight(), paint);
            } else if (preset.contains("Couleurs")) {
                paint.setColor(Color.argb(20, 255, 210, 170));
                c.drawRect(0, 0, target.getWidth(), target.getHeight(), paint);
            }
            paint.setColor(Color.argb(90, 0, 0, 0));
            c.drawRect(0, 0, target.getWidth(), target.getHeight() * 0.08f, paint);
            c.drawRect(0, target.getHeight() * 0.92f, target.getWidth(), target.getHeight(), paint);
        }

        private float correctionZoom(float timeSec, float level) {
            if (options.lockSourceMotion || options.noCropZoom) return 1.0f;
            String preset = options.correctionPreset == null ? "" : options.correctionPreset;
            if (preset.contains("Stabilisation")) return 1.06f;
            if (preset.contains("Auto")) return 1.02f + 0.015f * level;
            return 1.0f;
        }

        private ColorMatrixColorFilter colorFilterForPreset(String preset) {
            String p = preset == null ? "" : preset;
            if (options.preserveOriginalAmbience || p.contains("Préserver") || p.contains("timecodé") || p.contains("ambiance")) return null;
            ColorMatrix matrix = new ColorMatrix();
            if (p.contains("Noir")) {
                matrix.setSaturation(0f);
                ColorMatrix contrast = contrastMatrix(1.18f, 4f);
                matrix.postConcat(contrast);
            } else if (p.contains("Éclaircir")) {
                matrix.set(contrastArray(1.03f, 22f));
            } else if (p.contains("Contraste")) {
                matrix.set(contrastArray(1.28f, -8f));
            } else if (p.contains("Couleurs")) {
                matrix.setSaturation(0.86f);
                matrix.postConcat(contrastMatrix(1.06f, 8f));
            } else {
                matrix.setSaturation(1.05f);
                matrix.postConcat(contrastMatrix(1.08f, 5f));
            }
            return new ColorMatrixColorFilter(matrix);
        }

        private ColorMatrix contrastMatrix(float contrast, float brightness) {
            ColorMatrix m = new ColorMatrix();
            m.set(contrastArray(contrast, brightness));
            return m;
        }

        private float[] contrastArray(float contrast, float brightness) {
            float translate = (-0.5f * contrast + 0.5f) * 255f + brightness;
            return new float[]{
                    contrast, 0, 0, 0, translate,
                    0, contrast, 0, 0, translate,
                    0, 0, contrast, 0, translate,
                    0, 0, 0, 1, 0
            };
        }

        private ProjectOptions copyOptions(ProjectOptions in) {
            ProjectOptions out = new ProjectOptions();
            out.width = in.width;
            out.height = in.height;
            out.fps = in.fps;
            out.bitrate = in.bitrate;
            out.maxSeconds = in.maxSeconds;
            out.testMode = in.testMode;
            out.simpleLipSync = false;
            out.format = in.format;
            out.style = in.style;
            out.motion = in.motion;
            out.visualizer = in.visualizer;
            out.exportQuality = in.exportQuality;
            out.correctionPreset = in.correctionPreset;
            out.replacementMode = in.replacementMode;
            out.replacementMotion = in.replacementMotion;
            out.lockSourceQuality = in.lockSourceQuality;
            out.lockSourceMotion = in.lockSourceMotion;
            out.noCropZoom = in.noCropZoom;
            out.preserveOriginalAmbience = in.preserveOriginalAmbience;
            out.preserveOriginalDuration = in.preserveOriginalDuration;
            out.replacementStartTimeUs = in.replacementStartTimeUs;
            out.replacementSegmentDurationUs = in.replacementSegmentDurationUs;
            out.textPrompt = in.textPrompt;
            out.textSongMood = in.textSongMood;
            out.textVideoSeconds = in.textVideoSeconds;
            out.songSeconds = in.songSeconds;
            return out;
        }
    }
}
