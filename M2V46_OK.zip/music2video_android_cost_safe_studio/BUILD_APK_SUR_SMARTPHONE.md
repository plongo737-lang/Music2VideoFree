# Créer l’APK sans Android Studio, depuis un smartphone Android

Cette méthode utilise GitHub Actions : le téléphone sert à envoyer le projet, et GitHub compile l’APK dans le cloud.

## Étapes

1. Crée un compte GitHub si tu n’en as pas.
2. Installe l’application GitHub sur Android, ou ouvre GitHub dans Chrome.
3. Crée un nouveau dépôt GitHub, par exemple `Music2VideoFree`.
4. Envoie tous les fichiers de ce dossier dans le dépôt.
5. Va dans l’onglet **Actions** du dépôt.
6. Lance le workflow **Build Android APK** avec le bouton **Run workflow**.
7. Quand la compilation est terminée, ouvre le résultat de l’action.
8. Télécharge l’artifact **Music2VideoFree-debug-apk**.
9. Dézippe l’artifact : il contient `app-debug.apk`.
10. Envoie/installe `app-debug.apk` sur ton téléphone.

## Remarque

L’APK généré est une version debug. Elle est suffisante pour tester l’application sur ton téléphone.
Pour publier sur Google Play, il faudra générer une version release signée.
