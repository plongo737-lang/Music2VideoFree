# Lip-sync avancé — V4.3 local/open source

L'ancien smiley/avatar lip-sync est supprimé.

La direction retenue est :

1. **Mode Android local simple**
   - vidéo dans vidéo ;
   - synchronisation audio ;
   - placement timecode ;
   - fondu / PiP / plein écran ;
   - export non destructif.

2. **Mode PC local open source futur**
   - SadTalker ;
   - Wav2Lip ;
   - VideoReTalking ou équivalent ;
   - ComfyUI si nécessaire.

Aucune API payante/cloud ne doit être proposée depuis l'application.
Le PC de l'utilisateur servira de moteur de calcul sur le réseau local.
