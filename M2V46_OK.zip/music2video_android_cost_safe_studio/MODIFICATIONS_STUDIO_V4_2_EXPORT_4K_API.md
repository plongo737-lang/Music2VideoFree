# V4.2 — export 4K réel + ressources gratuites

Cette version clarifie et renforce la logique d’export :

- le titre de l’application affiche **Music2Video Free Studio V4.2** pour vérifier la bonne installation ;
- **Qualité source** garde la logique non destructive et évite le réencodage inutile ;
- **720p / 1080p / 4K** force un export MP4 réel avec réencodage local ;
- **4K UHD** cible une sortie 3840 × 2160 quand l’appareil le supporte ;
- après export, le bouton **Partager / télécharger le MP4 exporté** sert à récupérer le fichier final ;
- l’application indique le fichier, la durée et la résolution détectée après export.

## Rôle des API gratuites

Les API gratuites ne créent pas le 4K. Elles servent à enrichir les créations :

- **Pexels / Pixabay** : images et vidéos libres pour texte → vidéo ou musique → vidéo ;
- **Jamendo** : musiques libres ;
- **Freesound** : bruitages, ambiances, boucles courtes.

L’export 4K reste local sur le téléphone. Une vraie amélioration IA/upscale avancée demandera plus tard un module optionnel séparé.

## Limite honnête

Si la source est 720p ou 1080p, l’export 4K produit un fichier 3840 × 2160, mais il s’agit d’un agrandissement local. Pour une amélioration réelle de netteté, il faudra ajouter plus tard un module d’upscale IA optionnel.
