# Ressources gratuites et précautions de droits

Cette application est construite pour fonctionner sans API payante ni service cloud obligatoire.

## Ressources visuelles gratuites possibles

- **Pexels** : photos et vidéos gratuites, mais vérifier les conditions exactes de chaque ressource.
- **Pixabay** : photos, vidéos et musiques gratuites, mais vérifier les restrictions.
- **Unsplash** : photos gratuites, mais attention aux marques, personnes et usages sensibles.
- **Openverse** : moteur de recherche de contenus sous licences ouvertes, notamment Creative Commons.

## À vérifier avant une vidéo publique ou commerciale

Même si une image ou vidéo est gratuite, il faut vérifier :

- présence d'une personne identifiable,
- accord du modèle,
- logo ou marque visible,
- bâtiment privé ou lieu reconnaissable,
- œuvre d'art visible,
- licence commerciale autorisée,
- obligation d'attribution.

## Musique

Utilise uniquement :

- tes propres chansons,
- une musique libre de droits compatible avec ton usage,
- ou une musique pour laquelle tu as une autorisation claire.

## IA et lip-sync

Pour tout lip-sync réaliste sur visage réel, assure-toi d'avoir l'accord de la personne représentée et de respecter les lois locales sur l'image, la voix, la vie privée et la création de contenu synthétique.

## Politique locale

Les ressources gratuites restent le choix par défaut. Les traitements IA lourds doivent passer par un futur PC Companion local/open source, pas par une API payante.
