# Modifications appliquées — refonte interface et sécurité vidéo

Cette version corrige les problèmes signalés pendant les tests sur smartphone.

## Interface

- Séparation claire en 3 modes :
  - Créer une vidéo depuis une chanson
  - Créer une vidéo depuis un texte
  - Corriger / améliorer une vidéo existante
- Ajout d'une zone visible de fichiers importés avec nom et durée quand la durée est disponible.
- Ajout d'un aperçu vidéo direct pour la vidéo source et pour la dernière vidéo exportée.
- Ajout de boutons pour écouter/ouvrir les fichiers, supprimer les sélections et relancer un import.
- Ajout d'une zone de progression plus visible et d'une zone résultat dédiée.

## Durée et export

- Le mode test 20 secondes est maintenant désactivé par défaut.
- Les vidéos créées depuis une chanson utilisent la durée complète de l'audio, sauf si l'utilisateur active volontairement le mode test.
- La correction vidéo conserve la durée complète de la vidéo originale, sauf si l'utilisateur active volontairement le mode test.

## Correction vidéo non destructive

- La vidéo originale n'est jamais remplacée.
- Le réglage par défaut est désormais : `Préserver original — copie non destructive`.
- Ce mode crée une copie de la vidéo originale sans la réencoder quand aucune image et aucune nouvelle musique ne sont demandées.
- Les corrections visuelles, remplacements d'images et remplacements audio créent toujours une nouvelle vidéo exportée.

## Lip-sync / smiley

- L’ancien avatar lip-sync simple / smiley est supprimé.
- Le lip-sync se concentre maintenant sur le module avancé : vidéo dans vidéo, synchronisation audio, timecode, fond vert/chroma key et futures options IA volontaires.
- Il ne sera utilisé que si l'utilisateur coche volontairement l'option correspondante.

## Build

- Correction de l'erreur Java `illegal escape character` dans `LyricsEngine.java`.
- Correction de l'appel à `VideoCorrector.correct(...)` dans `MainActivity.java`.
- Ajout d'une fonction de copie non destructive dans `MediaMuxerTools.java`.

## Version Studio v2 — timecode, qualité source et multipiste

Corrections ajoutées après test sur téléphone :

- Nouvelle page **Accueil studio** avec accès rapide aux modes et bibliothèque locale.
- Ajout d'un vrai mode **Studio d'arrangement multipiste / timecode** dans la correction vidéo.
- Ajout de timecodes visibles pour chaque image de remplacement : entrée / sortie au format `HH:MM:SS.mmm`.
- Ajout d'un champ pour définir le **timecode de départ** du premier remplacement.
- Ajout d'un champ pour définir la **durée de chaque photo / séquence**.
- Ajout de verrous activés par défaut :
  - verrouiller qualité source ;
  - verrouiller motion originale ;
  - ne pas recadrer / ne pas zoomer la vidéo source.
- Ajout du choix de qualité : **Qualité source / auto**, **720p HD**, **1080p Full HD**, **4K UHD**.
- Ajout d'une bulle d'aide pour les motions : source conservée, image fixe, Ken Burns, slide, pulse audio, rotation, shake.
- Ajout d'une bulle d'aide pour les formats/qualités d'export.
- Ajout d'une bulle d'aide timecode pour replacer les photos sans erreur.
- Le mode correction évite désormais les filtres, recadrages et mouvements si le mode préserver/timecodé est choisi.
- Le mode texte propose maintenant des durées plus longues : 2, 3 et 4 minutes.

Note : les fonctions avancées restent locales et gratuites. Les options cloud/paiement restent verrouillées.
