# Music2Video Free Studio — V4 fonctionnelle

Cette V4 se concentre sur les demandes fonctionnelles validées après les tests V3.

## Ajouts principaux

- Correction du champ Texte → Vidéo : bouton dédié pour ouvrir le clavier et EditText configuré pour saisie multiligne.
- Génération de paroles structurées depuis un prompt : titre, couplets, pré-refrain, refrain, pont, refrain final.
- Génération d'une boucle instrumentale locale gratuite via le moteur interne `TextSongComposer`.
- Lecteur audio intégré simple : lecture / pause des musiques importées ou générées localement.
- Import multi-images pour Texte → Vidéo, avec miniatures visibles.
- Recherche externe guidée vers ressources libres : Pexels/Pixabay pour images/vidéos, Jamendo/Freesound pour musiques/sons.
- Studio correction avec vignettes timecodées extraites de la vidéo source.
- Clic sur une vignette de la vidéo pour placer le timecode de remplacement.
- Options ajoutées : garder ambiance originale, préserver durée originale.
- Rangées de miniatures pour images importées et images de remplacement.
- Nouveau module Fusion : ajouter une vidéo dans une vidéo, par exemple intégrer une vidéo chanteur dans une vidéo narrative.
- Fusion locale avec modes : picture-in-picture, plein écran temporaire, fondu cinématographique, superposition douce, écran partagé.
- Options de fusion : timecode d'entrée, durée, position, adoucissement des bords, chroma key simple, audio final optionnel.

## Important

Cette V4 reste une application Android locale. Elle ne contient aucune clé API payante et ne lance aucun paiement.
Les ressources libres s'ouvrent dans le navigateur pour import manuel.
Les modules IA lourds comme ComfyUI, MusicGen avancé, SadTalker/Wav2Lip ou RIFE restent prévus comme options futures, car ils demandent un PC/serveur ou une API séparée.

## Réglages recommandés pour correction vidéo

- Qualité source / auto
- Garder ambiance originale
- Conserver motion source
- Ne pas recadrer / ne pas zoomer
- Préserver durée originale
- Export non destructif

## Réglages recommandés pour fusion chanteur

- Vidéo principale : récit / clip narratif
- Vidéo secondaire : chanteur avec fond uni ou fond vert si possible
- Mode : picture-in-picture pour le plus sûr, fondu pour un rendu musical
- Timecode : choisir depuis une vignette de la vidéo principale
- Audio final : chanson complète si disponible

## Ajustement V4 — suppression ancien lip-sync smiley

- Suppression du bouton visible “avatar lip-sync simple / smiley”.
- Désactivation forcée du rendu avatar/smiley dans les options de projet.
- Le prompt automatique indique maintenant de ne jamais générer d’avatar/smiley.
- La direction lip-sync reste le module avancé : vidéo dans vidéo, synchronisation audio, fond vert/chroma key, timecode, et futures connexions optionnelles type SadTalker/Wav2Lip/ComfyUI.
