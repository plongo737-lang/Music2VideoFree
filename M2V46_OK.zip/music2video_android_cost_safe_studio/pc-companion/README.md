# Music2Video PC Companion — prototype local

Ce dossier prépare la future version PC.

Objectif : utiliser un PC comme moteur local pour les tâches lourdes :

- export 4K ;
- upscale IA local ;
- interpolation RIFE ;
- lip-sync SadTalker/Wav2Lip ;
- MusicGen/AudioCraft ;
- ComfyUI ;
- rendu vidéo final.

Aucun service cloud payant n'est requis. Le futur compagnon PC devra tourner sur le réseau local.
