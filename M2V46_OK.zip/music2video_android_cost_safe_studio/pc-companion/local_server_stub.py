#!/usr/bin/env python3
"""Prototype local minimal pour Music2Video PC Companion.

Lance un petit serveur HTTP local sur le PC :
    python local_server_stub.py

Ce prototype ne fait pas encore le rendu. Il sert à tester l'idée de connexion locale.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/status"):
            body = json.dumps({
                "app": "Music2Video PC Companion",
                "status": "ready",
                "mode": "local-only",
                "paid_api": False,
                "modules": ["4k_export", "upscale_local", "rife", "sadtalker", "wav2lip", "musicgen", "comfyui"]
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 7860), Handler)
    print("Music2Video PC Companion prototype: http://0.0.0.0:7860/status")
    server.serve_forever()
