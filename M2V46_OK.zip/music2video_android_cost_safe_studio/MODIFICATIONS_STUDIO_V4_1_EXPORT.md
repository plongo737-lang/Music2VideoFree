# Music2Video Free Studio V4.1 — correctif export réel

Correctifs ajoutés après test utilisateur :

- Titre visible dans l'application : **V4.1** afin d'éviter de réinstaller une ancienne version par erreur.
- Le bouton correction devient **Exporter la vidéo corrigée en MP4** au lieu de “Créer une copie corrigée”.
- Après rendu, la zone résultat affiche :
  - nom du fichier exporté ;
  - durée ;
  - résolution réelle détectée ;
  - emplacement Galerie > Movies > Music2VideoFree.
- Ajout d’un bouton **Partager / télécharger le MP4 exporté** pour envoyer ou sauvegarder le fichier ailleurs.
- En mode correction, si 720p/1080p/4K est sélectionné, la simple copie est évitée : l’application force un nouvel export MP4 réencodé pour respecter la résolution demandée.
- En mode qualité source, l’application conserve la copie non destructive sans réencodage quand il n’y a aucune modification.

Limite importante :
- Le 4K sur smartphone peut être lent et lourd. Il faut tester sur un petit extrait avant une vidéo longue.
