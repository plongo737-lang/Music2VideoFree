# Music2Video Free Studio V4.4 audio prioritaire

Correctifs ciblés sur les retours utilisateur du 16/06 :

1. Dernière création
- Le dernier export MP4 est mémorisé via SharedPreferences.
- Le bouton “Ouvrir la dernière vidéo créée” peut rouvrir le dernier export connu après fermeture de l'application, si Android conserve l'accès au fichier.

2. Temps de rendu
- La barre de progression indique un temps estimé dès le lancement.
- Les boucles locales sont limitées à une durée courte pour éviter les rendus interminables sur téléphone.
- Message clair : les rendus longs/4K/IA sont prévus pour le moteur PC Linux local.

3. Cohérence paroles/prompt
- Génération de paroles plus cohérente avec l'histoire fournie.
- Cas spécifique amélioré : paysan/Portugal/femme/15 ans/50 ans/remerciement/soutien.
- Structure complète : intro, couplet 1, pré-refrain, refrain, couplet 2, pont, refrain final, production.

4. Boucle locale / sons libres
- Le bouton “Boucle locale” ouvre un choix : créer une boucle locale ou chercher des sons libres.
- Liens sans API payante vers Jamendo/Freesound.

5. Production automatique musique + voix
- Ajout des sélections : style musical, tonalité, type de voix, mastering.
- La génération Android reste une maquette instrumentale locale.
- Les voix réalistes, auto-tune et alignement avancé sont prévus pour le moteur PC Linux local.

6. Bouton Musiques/Sons
- Le bouton d'accueil “Musiques” ouvre les sources audio libres.
- Recherche Jamendo/Freesound sans redirection payante.

7. Type de voix
- Ajout des choix : voix exemple homme, voix exemple femme, ma voix – piste séparée, instrumental seul.

8. Voix utilisateur
- Préparation logique du workflow : voix exemple + instrumentale + piste utilisateur.
- La vraie prise de voix, correction de justesse/temps et auto-tune avancés restent côté PC Linux/open source.

9. Mastering
- Ajout de présélections de mastering : streaming propre, radio fort, cinéma large, voix claire, doux acoustique, rap/club.

Important : aucune API payante/cloud n'est proposée. Les sources gratuites servent aux contenus libres ; les traitements IA lourds passent par le futur PC Companion Linux.
