# Music2Video Free Studio — V4.2 complète consolidée

Cette version regroupe les éléments validés avec l'utilisateur afin d'éviter une version partielle limitée à l'export 4K.

## Interface
- Titre visible : Music2Video Free Studio V4.2 complète.
- Aides compactes avec boutons « Voir plus » et « ? » au lieu de longs textes visibles partout.
- Checklist V4.2 complète disponible depuis l'accueil.
- Ancien avatar / smiley lip-sync supprimé et désactivé.

## Texte → vidéo
- Champ texte avec bouton pour forcer l'ouverture du clavier.
- Génération de paroles structurées : intro implicite, couplets, pré-refrain, refrain, pont, refrain final.
- Styles musicaux : pop, rock, reggae, rap mélodique, piano émotionnel, électro, orchestral, sport chic.
- Génération locale d'une boucle instrumentale gratuite.
- Import de plusieurs images avec miniatures.
- Recherche guidée de médias libres de droits.

## Chanson → vidéo
- Import audio.
- Import multi-images.
- Prompt automatique musique → vidéo.
- Mode test 20 secondes désactivé par défaut.
- Rendu prévu sur la durée complète de l'audio.

## Correction vidéo / timeline
- Vidéo source affichée dans le studio.
- Lecteur vidéo intégré pour l'aperçu source.
- Vignettes de la vidéo source avec timecode visible.
- Clic sur une vignette pour remplir le timecode de remplacement.
- Remplacement d'image / séquence par timecode.
- Validation de placement sécurisé.
- Réglages -0,5 s / +0,5 s.
- Import multi-images de remplacement avec miniatures.
- Options par défaut : verrouiller qualité source, verrouiller motion source, ne pas recadrer / ne pas zoomer, garder ambiance originale, préserver durée originale.

## Export
- Séparation entre copie non destructive et export MP4 réel.
- Choix : qualité source, 720p, 1080p, 4K UHD.
- 4K UHD = export local 3840 x 2160 si l'appareil le supporte.
- Bouton partager / télécharger après export.
- Affichage du résultat et lecteur vidéo intégré.

## Ressources gratuites
- Accès guidé Pexels / Pixabay pour images et vidéos libres.
- Accès guidé Jamendo pour musiques.
- Accès guidé Freesound pour sons et ambiances.
- Les API gratuites fournissent des médias libres, mais ne créent pas l'upscale 4K.

## Vidéo dans vidéo / fusion chanteur
- Import vidéo principale narrative.
- Import vidéo secondaire chanteur.
- Placement par timecode.
- Durée d'apparition configurable.
- Modes : picture-in-picture, plein écran temporaire, fondu, superposition, écran partagé.
- Position : coins, centre, plein cadre.
- Fond vert / chroma key simple.
- Bords adoucis.
- Synchronisation audio final optionnelle.
- Export non destructif.

## Limites assumées
- Les fonctions IA lourdes restent optionnelles : upscale IA, motion IA, lip-sync avancé, détourage parfait.
- L'export 4K local peut créer un fichier 4K, mais si la source est basse résolution, il s'agit d'un upscale local et non d'une amélioration IA magique.
