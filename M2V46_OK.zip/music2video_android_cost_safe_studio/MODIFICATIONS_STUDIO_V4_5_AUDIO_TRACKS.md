# Music2Video Free Studio V4.6 — Texte → Musique prioritaire

Cette version cible uniquement les retours de test sur la section **Texte → Musique / Texte → Vidéo**.

## Corrections ajoutées

- Affichage d'un temps estimé au lancement de la production audio/vidéo.
- Bouton **Production locale** remplaçant la logique de boucle trop vague.
- Recherche Jamendo/Freesound enrichie par le style musical et les instruments choisis.
- Ajout d'un choix d'instruments avant génération :
  - guitare acoustique folk ;
  - guitare acoustique classique ;
  - guitare électrique ;
  - piano ;
  - basse ;
  - batterie ;
  - percussions ;
  - strings / nappes.
- Ajout d'une maquette audio locale plus rythmée : batterie, basse, instruments cochés, voix guide synthétique et choeurs si demandés.
- Si l'utilisateur lance **Créer la vidéo depuis le texte** sans audio importé ni production locale déjà générée, l'application crée d'abord automatiquement une production audio locale puis l'utilise dans la vidéo.
- Le résumé de production affiche maintenant : voix, tonalité, instruments et mastering.

## Limites transparentes

- Android génère une **maquette audio locale** et non une vraie voix chantée réaliste.
- La vraie voix de l'utilisateur avec auto-tune, correction temporelle et pistes séparées éditables est prévue pour le moteur **PC Linux local/open source**.
- Aucune API payante/cloud n'est ajoutée.
