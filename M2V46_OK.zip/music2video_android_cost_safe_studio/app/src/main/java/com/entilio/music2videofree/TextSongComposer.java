package com.entilio.music2videofree;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.nio.ByteBuffer;
import java.util.Locale;

/**
 * V4.6 — moteur audio local Android.
 *
 * Important : ce moteur crée une maquette musicale locale, rythmée et respectant mieux
 * style / tonalité / instruments cochés. Il ne prétend pas remplacer un vrai moteur IA
 * de voix chantée. La voix réaliste, l'auto-tune et les stems séparés éditables seront
 * réservés au moteur PC Linux local/open source.
 */
public class TextSongComposer {
    private static final int TIMEOUT_US = 10_000;

    public static Uri compose(Context context, String text, ProjectOptions options, ProgressCallback callback) throws Exception {
        if (options == null) options = new ProjectOptions();
        String clean = text == null || text.trim().isEmpty() ? "maquette chanson" : text.trim();
        long durationUs = options.textSongDurationUs();
        int sampleRate = 44100;
        int channels = 1;
        int bitRate = 192_000;
        long totalSamples = Math.max(1, durationUs * sampleRate / 1_000_000L);

        Uri outUri = MediaMuxerTools.createAudioUri(context, "text_to_song_v46_tracks", ".m4a", "audio/mp4");
        ParcelFileDescriptor pfd = null;
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean success = false;
        try {
            SongPlan plan = new SongPlan(clean, options);
            callback.onStep("V4.6 : maquette locale en cours. Tempo " + plan.tempo + " BPM, tonalité " + plan.keyLabel + ".\n" + plan.trackSummary());
            pfd = context.getContentResolver().openFileDescriptor(outUri, "w");
            if (pfd == null) throw new Exception("Impossible d’ouvrir le fichier audio.");

            MediaFormat format = MediaFormat.createAudioFormat("audio/mp4a-latm", sampleRate, channels);
            format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitRate);
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024);

            encoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            boolean muxerStarted = false;
            int trackIndex = -1;
            long sampleCursor = 0;

            while (!outputDone) {
                if (!inputDone) {
                    int inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US);
                    if (inputIndex >= 0) {
                        ByteBuffer input = encoder.getInputBuffer(inputIndex);
                        if (input == null) continue;
                        input.clear();
                        int maxSamples = Math.max(256, input.remaining() / 2);
                        int samples = (int) Math.min(maxSamples, totalSamples - sampleCursor);
                        long ptsUs = sampleCursor * 1_000_000L / sampleRate;
                        if (samples <= 0) {
                            encoder.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            fillPcm(input, samples, sampleCursor, sampleRate, plan);
                            encoder.queueInputBuffer(inputIndex, 0, samples * 2, ptsUs, 0);
                            sampleCursor += samples;
                            int progress = 5 + Math.round((sampleCursor / (float) totalSamples) * 88f);
                            callback.onProgress(progress);
                        }
                    }
                }

                int outputIndex = encoder.dequeueOutputBuffer(info, TIMEOUT_US);
                if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    // attendre
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new RuntimeException("Format changed twice");
                    trackIndex = muxer.addTrack(encoder.getOutputFormat());
                    muxer.start();
                    muxerStarted = true;
                } else if (outputIndex >= 0) {
                    ByteBuffer output = encoder.getOutputBuffer(outputIndex);
                    if (output == null) throw new RuntimeException("Audio encoder buffer null");
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size != 0) {
                        if (!muxerStarted) throw new RuntimeException("Muxer audio non démarré");
                        output.position(info.offset);
                        output.limit(info.offset + info.size);
                        muxer.writeSampleData(trackIndex, output, info);
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    encoder.releaseOutputBuffer(outputIndex, false);
                }
            }
            callback.onProgress(98);
            success = true;
            return outUri;
        } finally {
            try { if (muxer != null) muxer.stop(); } catch (Exception ignored) {}
            if (muxer != null) muxer.release();
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
            if (pfd != null) pfd.close();
            MediaMuxerTools.finishPendingAudio(context, outUri, success);
        }
    }

    private static void fillPcm(ByteBuffer input, int samples, long startSample, int sampleRate, SongPlan plan) {
        for (int i = 0; i < samples; i++) {
            long s = startSample + i;
            double t = s / (double) sampleRate;
            double beat = t / plan.beatSeconds;
            int beatIndex = (int) Math.floor(beat);
            double beatPhase = beat - beatIndex;
            int barBeat = beatIndex % 4;
            int barIndex = beatIndex / 4;
            double section = (t % plan.sectionSeconds) / plan.sectionSeconds;
            double intensity = section < 0.12 ? 0.52 : section < 0.32 ? 0.76 : section < 0.72 ? 0.96 : 0.84;
            double chord = plan.chords[barIndex % plan.chords.length];
            double value = 0.0;

            if (plan.instrumentDrums) value += drums(t, barBeat, beatPhase, plan) * 1.15 * intensity;
            if (plan.instrumentPercussion) value += percussion(t, beat, s, plan) * 0.90 * intensity;
            if (plan.instrumentBass) value += bass(t, beatIndex, beatPhase, chord, plan) * 1.05 * intensity;
            if (plan.instrumentPiano) value += piano(t, beatIndex, beatPhase, chord, plan) * 0.75 * intensity;
            if (plan.instrumentFolkGuitar) value += guitar(t, beatIndex, beatPhase, chord, plan, 0) * 0.72 * intensity;
            if (plan.instrumentClassicGuitar) value += guitar(t, beatIndex, beatPhase, chord, plan, 1) * 0.68 * intensity;
            if (plan.instrumentElectricGuitar) value += guitar(t, beatIndex, beatPhase, chord, plan, 2) * 0.62 * intensity;
            if (plan.instrumentStrings) value += stringsPad(t, chord, plan) * 0.55;
            if (plan.hasVoiceGuide) value += voiceGuide(t, beatIndex, beatPhase, plan) * plan.voiceGain;
            if (plan.hasChoir) value += choir(t, chord, plan) * 0.38;

            // Mastering très simple : saturation douce + limiteur.
            value *= plan.masterGain;
            value = softClip(value * plan.drive);
            value = clamp(value, -plan.targetPeak, plan.targetPeak);
            short pcm = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, (int) (value * 32767.0)));
            input.put((byte) (pcm & 0xff));
            input.put((byte) ((pcm >> 8) & 0xff));
        }
    }

    private static double drums(double t, int barBeat, double phase, SongPlan plan) {
        double kick = 0.0;
        boolean dance = plan.style.contains("dance") || plan.style.contains("électro") || plan.style.contains("rap");
        boolean reggae = plan.style.contains("reggae");
        boolean rock = plan.style.contains("rock");
        if ((dance || barBeat == 0 || barBeat == 2) && phase < 0.28) {
            kick = Math.sin(2.0 * Math.PI * (42.0 + 85.0 * (1.0 - phase)) * t) * Math.exp(-phase * 11.0);
        }
        if (rock && phase > 0.48 && phase < 0.64 && (barBeat == 0 || barBeat == 2)) {
            kick += Math.sin(2.0 * Math.PI * 55.0 * t) * Math.exp(-(phase - 0.48) * 18.0) * 0.55;
        }
        double snare = 0.0;
        if (((barBeat == 1 || barBeat == 3) || (reggae && barBeat == 2)) && phase < 0.18) {
            snare = noise((long) (t * 44100.0 * 13.0)) * Math.exp(-phase * 15.0);
        }
        double hat = 0.0;
        double eighth = ((t / (plan.beatSeconds / 2.0)) % 1.0);
        if (eighth < 0.11) hat = noise((long) (t * 44100.0 * 31.0)) * Math.exp(-eighth * 24.0);
        return kick * 0.52 + snare * 0.32 + hat * 0.14;
    }

    private static double percussion(double t, double beat, long sample, SongPlan plan) {
        double shakerPhase = (beat * 2.0) % 1.0;
        double shaker = shakerPhase < 0.12 ? noise(sample * 17L) * Math.exp(-shakerPhase * 28.0) : 0.0;
        int slot = ((int) Math.floor(beat * 2.0)) % 8;
        double phase = (beat * 2.0) - Math.floor(beat * 2.0);
        double click = 0.0;
        if ((slot == 0 || slot == 3 || slot == 6) && phase < 0.075) {
            click = Math.sin(2.0 * Math.PI * 1300.0 * t) * Math.exp(-phase * 34.0);
        }
        return shaker * 0.12 + click * 0.16;
    }

    private static double bass(double t, int beatIndex, double phase, double chord, SongPlan plan) {
        int pos = beatIndex % 8;
        double pattern = pos == 0 ? 1.0 : pos == 2 ? 1.5 : pos == 4 ? chord : pos == 6 ? 1.25 : 1.0;
        if (plan.style.contains("reggae") && phase < 0.48) return 0.0;
        double freq = plan.root * 0.5 * pattern;
        double env = 0.62 + 0.38 * Math.exp(-phase * 5.0);
        return (sine(freq, t) * 0.36 + sine(freq * 2.0, t) * 0.10) * env;
    }

    private static double piano(double t, int beatIndex, double phase, double chord, SongPlan plan) {
        int idx = (beatIndex + plan.seedNote(beatIndex)) % plan.scale.length;
        double freq = plan.root * chord * plan.scale[idx];
        double env = Math.exp(-phase * 4.5);
        double hit = (beatIndex % 2 == 0 || plan.style.contains("piano")) ? 1.0 : 0.55;
        return (sine(freq, t) * 0.22 + sine(freq * 1.5, t) * 0.09 + sine(freq * 2.0, t) * 0.06) * env * hit;
    }

    private static double guitar(double t, int beatIndex, double phase, double chord, SongPlan plan, int type) {
        double strum = ((phase + (type == 1 ? 0.05 : 0.0)) % 0.5) / 0.5;
        double env = Math.exp(-strum * (type == 2 ? 3.2 : 6.4));
        double base = plan.root * chord;
        double waveform = sine(base, t) * 0.18 + sine(base * 1.25, t) * 0.14 + sine(base * 1.5, t) * 0.10 + sine(base * 2.0, t) * 0.06;
        double pick = noise((long) (t * 44100.0 * (type + 3))) * (type == 2 ? 0.010 : 0.020);
        if (type == 2) waveform = softClip(waveform * 2.2);
        return (waveform + pick) * env;
    }

    private static double stringsPad(double t, double chord, SongPlan plan) {
        double f = plan.root * chord;
        double swell = 0.62 + 0.38 * Math.sin(2.0 * Math.PI * 0.06 * t);
        return (sine(f, t) * 0.12 + sine(f * 1.5, t) * 0.10 + sine(f * 2.0, t) * 0.07) * swell;
    }

    private static double voiceGuide(double t, int beatIndex, double phase, SongPlan plan) {
        // Voix guide synthétique audible : mélodie de référence, pas une vraie voix chantée.
        int phraseBeat = beatIndex % 16;
        if (phraseBeat == 7 || phraseBeat == 15) return 0.0;
        int idx = (plan.seedNote(beatIndex * 3) + phraseBeat) % plan.scale.length;
        double octave = plan.femaleVoice ? 2.0 : 1.0;
        double freq = plan.root * plan.scale[idx] * octave;
        double vibrato = 1.0 + 0.010 * Math.sin(2.0 * Math.PI * 5.2 * t);
        double env = Math.min(1.0, phase * 8.0) * Math.exp(-phase * 0.72);
        double formant1 = plan.femaleVoice ? 820.0 : 560.0;
        double formant2 = plan.femaleVoice ? 1420.0 : 1020.0;
        double source = sine(freq * vibrato, t) * 0.34 + sine(freq * 2.0 * vibrato, t) * 0.10;
        double color = sine(formant1, t) * 0.030 + sine(formant2, t) * 0.018;
        return (source + color) * env;
    }

    private static double choir(double t, double chord, SongPlan plan) {
        double f = plan.root * chord * (plan.femaleVoice ? 2.0 : 1.0);
        double slow = 0.55 + 0.45 * Math.sin(2.0 * Math.PI * 0.075 * t + 0.4);
        return (sine(f, t) + sine(f * 1.25, t) * 0.7 + sine(f * 1.5, t) * 0.5) * 0.10 * slow;
    }

    private static double sine(double f, double t) { return Math.sin(2.0 * Math.PI * f * t); }
    private static double softClip(double x) { return Math.tanh(x); }
    private static double clamp(double x, double min, double max) { return x < min ? min : (x > max ? max : x); }

    private static double noise(long x) {
        long n = (x << 13) ^ x;
        return 1.0 - ((n * (n * n * 15731L + 789221L) + 1376312589L) & 0x7fffffff) / 1073741824.0;
    }

    private static class SongPlan {
        final String text;
        final String style;
        final String keyLabel;
        final int hash;
        final int tempo;
        final double beatSeconds;
        final double root;
        final double[] scale;
        final double[] chords;
        final double sectionSeconds;
        final double masterGain;
        final double drive;
        final double targetPeak;
        final boolean femaleVoice;
        final boolean hasVoiceGuide;
        final boolean hasChoir;
        final double voiceGain;
        final boolean instrumentFolkGuitar;
        final boolean instrumentClassicGuitar;
        final boolean instrumentElectricGuitar;
        final boolean instrumentPiano;
        final boolean instrumentBass;
        final boolean instrumentDrums;
        final boolean instrumentPercussion;
        final boolean instrumentStrings;

        SongPlan(String text, ProjectOptions options) {
            this.text = text == null ? "" : text.toLowerCase(Locale.ROOT);
            this.hash = Math.abs(this.text.hashCode());
            this.style = options.textSongMood == null ? "pop cinématique" : options.textSongMood.toLowerCase(Locale.ROOT);
            this.keyLabel = options.textSongKey == null ? "Tonalité auto" : options.textSongKey;
            String voice = options.textVoiceType == null ? "Voix guide homme" : options.textVoiceType;
            this.femaleVoice = voice.toLowerCase(Locale.ROOT).contains("femme");
            this.hasVoiceGuide = !voice.toLowerCase(Locale.ROOT).contains("instrumental");
            this.hasChoir = hasVoiceGuide && !voice.toLowerCase(Locale.ROOT).contains("ma voix");
            this.voiceGain = voice.toLowerCase(Locale.ROOT).contains("ma voix") ? 0.18 : 0.50;
            this.instrumentFolkGuitar = options.instrumentFolkGuitar;
            this.instrumentClassicGuitar = options.instrumentClassicGuitar;
            this.instrumentElectricGuitar = options.instrumentElectricGuitar;
            this.instrumentPiano = options.instrumentPiano;
            this.instrumentBass = options.instrumentBass;
            this.instrumentDrums = options.instrumentDrums;
            this.instrumentPercussion = options.instrumentPercussion;
            this.instrumentStrings = options.instrumentStrings;

            int t = 92 + (hash % 12);
            if (style.contains("ballade") || style.contains("émotion") || style.contains("piano")) t = 70 + (hash % 10);
            else if (style.contains("reggae")) t = 76 + (hash % 8);
            else if (style.contains("rock")) t = 104 + (hash % 14);
            else if (style.contains("rap")) t = 92 + (hash % 12);
            else if (style.contains("dance") || style.contains("électro")) t = 120 + (hash % 12);
            else if (style.contains("film") || style.contains("orchestral")) t = 82 + (hash % 12);
            this.tempo = t;
            this.beatSeconds = 60.0 / Math.max(48, tempo);
            this.root = chooseRoot(keyLabel, style);

            if (keyLabel.toLowerCase(Locale.ROOT).contains("mineur") || style.contains("émotion") || style.contains("ballade") || style.contains("rap")) {
                this.scale = new double[]{1.0, 1.12246, 1.18921, 1.33484, 1.49831, 1.58740, 1.78180, 2.0};
                this.chords = new double[]{1.0, 1.33484, 1.49831, 1.12246};
            } else if (style.contains("reggae")) {
                this.scale = new double[]{1.0, 1.12246, 1.25992, 1.33484, 1.49831, 1.68179, 1.88775, 2.0};
                this.chords = new double[]{1.0, 1.33484, 1.49831, 1.25992};
            } else {
                this.scale = new double[]{1.0, 1.12246, 1.25992, 1.33484, 1.49831, 1.68179, 1.88775, 2.0};
                this.chords = new double[]{1.0, 1.25992, 1.49831, 1.33484};
            }
            this.sectionSeconds = Math.max(12.0, options.textSongDurationUs() / 1_000_000.0);
            String master = options.masterPreset == null ? "" : options.masterPreset;
            this.masterGain = master.contains("Radio") ? 0.88 : master.contains("Doux") ? 0.68 : master.contains("Voix") ? 0.78 : 0.76;
            this.drive = master.contains("Radio") ? 1.48 : master.contains("Rap") ? 1.38 : 1.16;
            this.targetPeak = Math.max(0.80, Math.min(0.98, options.targetPeak()));
        }

        String trackSummary() {
            StringBuilder sb = new StringBuilder("Pistes dans le mix local : ");
            if (hasVoiceGuide) sb.append("voix guide synthétique, ");
            if (hasChoir) sb.append("choeurs synthétiques, ");
            if (instrumentDrums) sb.append("batterie, ");
            if (instrumentBass) sb.append("basse, ");
            if (instrumentFolkGuitar) sb.append("guitare folk, ");
            if (instrumentClassicGuitar) sb.append("guitare classique, ");
            if (instrumentElectricGuitar) sb.append("guitare électrique, ");
            if (instrumentPiano) sb.append("piano, ");
            if (instrumentPercussion) sb.append("percussions, ");
            if (instrumentStrings) sb.append("strings, ");
            String out = sb.toString();
            if (out.endsWith(", ")) out = out.substring(0, out.length() - 2);
            return out + ".";
        }

        int seedNote(int beatIndex) {
            if (text.length() == 0) return Math.abs(beatIndex + hash) % 8;
            char c = text.charAt(Math.abs(beatIndex * 7 + hash) % text.length());
            return Math.abs(c + beatIndex + hash) % 8;
        }

        private static double chooseRoot(String key, String style) {
            String k = key == null ? "" : key.toLowerCase(Locale.ROOT);
            if (k.contains("do majeur")) return 261.63;
            if (k.contains("ré majeur")) return 293.66;
            if (k.contains("mi majeur")) return 329.63;
            if (k.contains("fa majeur")) return 349.23;
            if (k.contains("sol majeur")) return 392.00;
            if (k.contains("la majeur")) return 220.00;
            if (k.contains("la mineur")) return 220.00;
            if (k.contains("mi mineur")) return 164.81;
            if (k.contains("ré mineur")) return 293.66;
            if (style.contains("reggae")) return 196.00;
            if (style.contains("rock")) return 164.81;
            if (style.contains("émotion") || style.contains("ballade")) return 220.00;
            return 261.63;
        }
    }
}
