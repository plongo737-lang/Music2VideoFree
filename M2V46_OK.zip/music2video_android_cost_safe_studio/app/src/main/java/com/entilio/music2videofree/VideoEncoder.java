package com.entilio.music2videofree;

import android.graphics.Bitmap;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;

public class VideoEncoder {
    private static final int TIMEOUT_US = 10_000;

    public interface FrameDrawer {
        void render(Bitmap target, float timeSec, int frameIndex, float level) throws Exception;
    }

    public static void encodeVideoOnly(File outputFile, long durationUs, ProjectOptions options,
                                       float[] levels, FrameDrawer drawer,
                                       ProgressCallback callback, int startProgress, int endProgress) throws Exception {
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        InputSurface inputSurface = null;
        TextureRenderer textureRenderer = null;
        Surface surface = null;
        Bitmap frameBitmap = null;
        try {
            MediaFormat format = MediaFormat.createVideoFormat("video/avc", options.width, options.height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            format.setInteger(MediaFormat.KEY_BIT_RATE, options.bitrate);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, options.fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            encoder = MediaCodec.createEncoderByType("video/avc");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = encoder.createInputSurface();
            inputSurface = new InputSurface(surface);
            inputSurface.makeCurrent();
            textureRenderer = new TextureRenderer();
            textureRenderer.init();
            encoder.start();

            muxer = new MediaMuxer(outputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            TrackState state = new TrackState();
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            frameBitmap = Bitmap.createBitmap(options.width, options.height, Bitmap.Config.ARGB_8888);
            int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));

            for (int frame = 0; frame < frameCount; frame++) {
                float timeSec = frame / (float) options.fps;
                float level = frame < levels.length ? levels[frame] : syntheticLevel(frame);
                drawer.render(frameBitmap, timeSec, frame, level);
                textureRenderer.drawBitmap(frameBitmap);
                inputSurface.setPresentationTime((long) frame * 1_000_000_000L / options.fps);
                inputSurface.swapBuffers();
                drainEncoder(encoder, muxer, bufferInfo, state, false);
                if (callback != null && frame % Math.max(1, options.fps / 2) == 0) {
                    int p = startProgress + Math.round((frame / (float) frameCount) * (endProgress - startProgress));
                    callback.onProgress(p);
                }
            }
            drainEncoder(encoder, muxer, bufferInfo, state, true);
        } finally {
            if (frameBitmap != null && !frameBitmap.isRecycled()) frameBitmap.recycle();
            if (textureRenderer != null) textureRenderer.release();
            if (inputSurface != null) inputSurface.release();
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
            if (muxer != null) {
                try { muxer.stop(); } catch (Exception ignored) {}
                muxer.release();
            }
        }
    }

    public static float[] syntheticLevels(int frameCount) {
        float[] levels = new float[Math.max(1, frameCount)];
        for (int i = 0; i < levels.length; i++) levels[i] = syntheticLevel(i);
        return levels;
    }

    private static float syntheticLevel(int frame) {
        double a = Math.abs(Math.sin(frame * 0.15)) * 0.52 + Math.abs(Math.sin(frame * 0.041)) * 0.38;
        return Math.max(0.04f, Math.min(1f, (float) a));
    }

    private static void drainEncoder(MediaCodec encoder, MediaMuxer muxer, MediaCodec.BufferInfo bufferInfo,
                                     TrackState state, boolean endOfStream) {
        if (endOfStream) encoder.signalEndOfInputStream();
        while (true) {
            int encoderStatus = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US);
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (state.muxerStarted) throw new RuntimeException("Format changed twice");
                MediaFormat newFormat = encoder.getOutputFormat();
                state.trackIndex = muxer.addTrack(newFormat);
                muxer.start();
                state.muxerStarted = true;
            } else if (encoderStatus < 0) {
                // Ignore other status codes.
            } else {
                ByteBuffer encodedData = encoder.getOutputBuffer(encoderStatus);
                if (encodedData == null) throw new RuntimeException("encoderOutputBuffer " + encoderStatus + " was null");

                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bufferInfo.size = 0;

                if (bufferInfo.size != 0) {
                    if (!state.muxerStarted) throw new RuntimeException("muxer has not started");
                    encodedData.position(bufferInfo.offset);
                    encodedData.limit(bufferInfo.offset + bufferInfo.size);
                    muxer.writeSampleData(state.trackIndex, encodedData, bufferInfo);
                }

                encoder.releaseOutputBuffer(encoderStatus, false);
                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }

    private static class TrackState {
        int trackIndex = -1;
        boolean muxerStarted = false;
    }
}
