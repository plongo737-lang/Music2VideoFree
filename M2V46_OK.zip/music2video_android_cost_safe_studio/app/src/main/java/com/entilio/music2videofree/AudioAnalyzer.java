package com.entilio.music2videofree;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AudioAnalyzer {
    private static final int TIMEOUT_US = 10_000;

    public static float[] analyze(Context context, Uri audioUri, int frameCount, int fps) {
        if (frameCount <= 0) return new float[0];
        float[] sums = new float[frameCount];
        int[] counts = new int[frameCount];
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec decoder = null;
        try {
            extractor.setDataSource(context, audioUri, null);
            int trackIndex = selectTrack(extractor, true);
            if (trackIndex < 0) return fallback(frameCount);
            MediaFormat format = extractor.getTrackFormat(trackIndex);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime == null) return fallback(frameCount);
            extractor.selectTrack(trackIndex);

            int sampleRate = format.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? format.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            int channels = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;

            decoder = MediaCodec.createDecoderByType(mime);
            decoder.configure(format, null, null, 0);
            decoder.start();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;

            while (!outputDone) {
                if (!inputDone) {
                    int inputIndex = decoder.dequeueInputBuffer(TIMEOUT_US);
                    if (inputIndex >= 0) {
                        ByteBuffer inputBuffer = decoder.getInputBuffer(inputIndex);
                        if (inputBuffer == null) continue;
                        inputBuffer.clear();
                        int sampleSize = extractor.readSampleData(inputBuffer, 0);
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            long sampleTimeUs = extractor.getSampleTime();
                            decoder.queueInputBuffer(inputIndex, 0, sampleSize, sampleTimeUs, 0);
                            extractor.advance();
                        }
                    }
                }

                int outputIndex = decoder.dequeueOutputBuffer(info, TIMEOUT_US);
                if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    // No output yet.
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat out = decoder.getOutputFormat();
                    if (out.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (out.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                } else if (outputIndex >= 0) {
                    ByteBuffer outputBuffer = decoder.getOutputBuffer(outputIndex);
                    if (outputBuffer != null && info.size > 0 && sampleRate > 0 && channels > 0) {
                        outputBuffer.position(info.offset);
                        outputBuffer.limit(info.offset + info.size);
                        processPcm(outputBuffer.slice(), info.presentationTimeUs, sampleRate, channels, fps, sums, counts);
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true;
                    }
                    decoder.releaseOutputBuffer(outputIndex, false);
                }
            }
            return normalize(sums, counts, frameCount);
        } catch (Exception e) {
            return fallback(frameCount);
        } finally {
            if (decoder != null) {
                try { decoder.stop(); } catch (Exception ignored) {}
                decoder.release();
            }
            extractor.release();
        }
    }

    public static int selectTrack(MediaExtractor extractor, boolean audio) {
        int count = extractor.getTrackCount();
        for (int i = 0; i < count; i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime == null) continue;
            if (audio && mime.startsWith("audio/")) return i;
            if (!audio && mime.startsWith("video/")) return i;
        }
        return -1;
    }

    private static void processPcm(ByteBuffer pcm, long startUs, int sampleRate, int channels, int fps,
                                   float[] sums, int[] counts) {
        pcm.order(ByteOrder.LITTLE_ENDIAN);
        int totalShorts = pcm.remaining() / 2;
        int sampleFrames = totalShorts / channels;
        if (sampleFrames <= 0) return;
        int step = Math.max(1, sampleFrames / 1600);
        int frameCount = sums.length;
        for (int i = 0; i < sampleFrames; i += step) {
            double mono = 0.0;
            for (int ch = 0; ch < channels; ch++) {
                int shortIndex = i * channels + ch;
                if (shortIndex >= totalShorts) break;
                short value = pcm.getShort(shortIndex * 2);
                mono += value / 32768.0;
            }
            mono /= Math.max(1, channels);
            float square = (float) (mono * mono);
            long timeUs = startUs + (i * 1_000_000L / sampleRate);
            int videoFrame = (int) ((timeUs * fps) / 1_000_000L);
            if (videoFrame >= 0 && videoFrame < frameCount) {
                sums[videoFrame] += square;
                counts[videoFrame] += 1;
            }
        }
    }

    private static float[] normalize(float[] sums, int[] counts, int frameCount) {
        float[] levels = new float[frameCount];
        float max = 0f;
        for (int i = 0; i < frameCount; i++) {
            if (counts[i] > 0) {
                levels[i] = (float) Math.sqrt(sums[i] / counts[i]);
                max = Math.max(max, levels[i]);
            }
        }
        if (max < 0.0001f) return fallback(frameCount);
        float last = 0f;
        for (int i = 0; i < frameCount; i++) {
            float n = (float) Math.pow(levels[i] / max, 0.62);
            if (i > 0 && n == 0f) n = levels[i - 1] * 0.92f;
            last = n > last ? (last * 0.35f + n * 0.65f) : (last * 0.82f + n * 0.18f);
            levels[i] = clamp(last, 0f, 1f);
        }
        return levels;
    }

    private static float[] fallback(int frameCount) {
        float[] levels = new float[frameCount];
        for (int i = 0; i < frameCount; i++) {
            double a = Math.abs(Math.sin(i * 0.13)) * 0.55 + Math.abs(Math.sin(i * 0.031)) * 0.45;
            levels[i] = clamp((float) a, 0.05f, 1f);
        }
        return levels;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
