package com.entilio.music2videofree;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;

import java.util.ArrayList;
import java.util.List;

public class TextMediaFactory {
    public static List<Bitmap> createTextSceneBitmaps(String text, ProjectOptions options) {
        List<String> scenes = splitScenes(text);
        List<Bitmap> bitmaps = new ArrayList<>();
        for (int i = 0; i < scenes.size(); i++) {
            bitmaps.add(createSceneBitmap(scenes.get(i), i + 1, scenes.size(), options));
        }
        return bitmaps;
    }

    public static List<String> splitScenes(String text) {
        String clean = text == null ? "" : text.trim().replaceAll("\\s+", " ");
        if (clean.isEmpty()) clean = "Écris ton texte ici pour créer une vidéo.";
        String[] raw = clean.split("(?<=[.!?])\\s+|\\n+");
        List<String> scenes = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String part : raw) {
            String p = part.trim();
            if (p.isEmpty()) continue;
            if (current.length() + p.length() > 115 && current.length() > 0) {
                scenes.add(current.toString().trim());
                current.setLength(0);
            }
            if (current.length() > 0) current.append(' ');
            current.append(p);
        }
        if (current.length() > 0) scenes.add(current.toString().trim());
        if (scenes.isEmpty()) scenes.add(clean);
        if (scenes.size() == 1 && clean.length() > 140) {
            scenes.clear();
            for (int i = 0; i < clean.length(); i += 110) {
                scenes.add(clean.substring(i, Math.min(clean.length(), i + 110)).trim());
            }
        }
        return scenes;
    }

    private static Bitmap createSceneBitmap(String sceneText, int index, int total, ProjectOptions options) {
        int w = Math.max(480, options.width);
        int h = Math.max(480, options.height);
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        int[] pal = palette(options.style);

        LinearGradient gradient = new LinearGradient(0, 0, w, h, pal[0], pal[1], Shader.TileMode.CLAMP);
        paint.setShader(gradient);
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        for (int i = 0; i < 5; i++) {
            float x = (float) (w * (0.20 + 0.16 * i));
            float y = (float) (h * (0.18 + 0.10 * Math.sin(i * 1.7 + index)));
            RadialGradient glow = new RadialGradient(x, y, w * 0.28f, alpha(pal[2], 50), alpha(pal[2], 0), Shader.TileMode.CLAMP);
            paint.setShader(glow);
            c.drawCircle(x, y, w * 0.32f, paint);
            paint.setShader(null);
        }

        paint.setColor(alpha(Color.BLACK, 88));
        RectF card = new RectF(w * 0.08f, h * 0.24f, w * 0.92f, h * 0.72f);
        c.drawRoundRect(card, w * 0.035f, w * 0.035f, paint);

        textPaint.setColor(Color.rgb(246, 242, 232));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(Math.max(28f, Math.min(w, h) * 0.047f));
        List<String> lines = wrap(sceneText, textPaint, w * 0.72f, 7);
        float lineHeight = textPaint.getTextSize() * 1.22f;
        float startY = h * 0.48f - ((lines.size() - 1) * lineHeight / 2f);
        paint.setColor(alpha(Color.BLACK, 135));
        for (int i = 0; i < lines.size(); i++) {
            c.drawText(lines.get(i), w / 2f + 3, startY + i * lineHeight + 3, textPaintShadow(textPaint));
            c.drawText(lines.get(i), w / 2f, startY + i * lineHeight, textPaint);
        }

        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(Math.max(18f, Math.min(w, h) * 0.020f));
        textPaint.setColor(alpha(pal[2], 210));
        c.drawText("Scène " + index + " / " + total, w / 2f, h * 0.80f, textPaint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(3f, w * 0.004f));
        paint.setColor(alpha(pal[2], 120));
        c.drawRoundRect(card, w * 0.035f, w * 0.035f, paint);
        paint.setStyle(Paint.Style.FILL);

        RadialGradient vignette = new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.72f,
                alpha(Color.BLACK, 0), alpha(Color.BLACK, 170), Shader.TileMode.CLAMP);
        paint.setShader(vignette);
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);
        return bitmap;
    }

    private static TextPaint textPaintShadow(TextPaint original) {
        TextPaint shadow = new TextPaint(original);
        shadow.setColor(alpha(Color.BLACK, 170));
        return shadow;
    }

    private static List<String> wrap(String text, Paint paint, float maxWidth, int maxLines) {
        List<String> lines = new ArrayList<>();
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(candidate) <= maxWidth || line.length() == 0) {
                line.setLength(0);
                line.append(candidate);
            } else {
                lines.add(line.toString());
                line.setLength(0);
                line.append(word);
                if (lines.size() == maxLines - 1) break;
            }
        }
        if (line.length() > 0 && lines.size() < maxLines) lines.add(line.toString());
        if (lines.size() == maxLines && text.length() > String.join(" ", lines).length()) {
            String last = lines.get(lines.size() - 1);
            if (last.length() > 3) lines.set(lines.size() - 1, last.substring(0, Math.max(1, last.length() - 3)) + "…");
        }
        return lines;
    }

    private static int[] palette(String style) {
        String s = style == null ? "" : style;
        if (s.contains("Rêve")) return new int[]{Color.rgb(80, 63, 112), Color.rgb(234, 181, 196), Color.rgb(255, 224, 184)};
        if (s.contains("Nature")) return new int[]{Color.rgb(24, 62, 49), Color.rgb(141, 174, 112), Color.rgb(231, 218, 156)};
        if (s.contains("Sport")) return new int[]{Color.rgb(17, 20, 27), Color.rgb(60, 64, 72), Color.rgb(218, 181, 91)};
        if (s.contains("néon") || s.contains("Neon")) return new int[]{Color.rgb(10, 8, 30), Color.rgb(74, 17, 100), Color.rgb(65, 214, 232)};
        return new int[]{Color.rgb(13, 15, 22), Color.rgb(58, 45, 41), Color.rgb(216, 180, 93)};
    }

    private static int alpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }
}
