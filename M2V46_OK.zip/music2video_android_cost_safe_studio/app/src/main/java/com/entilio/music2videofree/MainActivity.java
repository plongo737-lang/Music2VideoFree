package com.entilio.music2videofree;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS_NAME = "m2v_state";
    private static final String PREF_LAST_OUTPUT = "last_output_uri";
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_IMAGES = 1002;
    private static final int REQ_CORRECTION_VIDEO = 1003;
    private static final int REQ_CORRECTION_AUDIO = 1004;
    private static final int REQ_REPLACEMENT_IMAGES = 1005;
    private static final int REQ_TEXT_AUDIO = 1006;
    private static final int REQ_TEXT_IMAGES = 1007;
    private static final int REQ_FUSION_MAIN_VIDEO = 1008;
    private static final int REQ_FUSION_SINGER_VIDEO = 1009;
    private static final int REQ_FUSION_AUDIO = 1010;

    private Uri audioUri;
    private Uri textAudioUri;
    private Uri videoToCorrectUri;
    private Uri correctionAudioUri;
    private Uri lastOutputUri;
    private Uri generatedTextAudioUri;
    private Uri fusionMainVideoUri;
    private Uri fusionSingerVideoUri;
    private Uri fusionAudioUri;

    private final ArrayList<Uri> imageUris = new ArrayList<>();
    private final ArrayList<Uri> replacementImageUris = new ArrayList<>();
    private final ArrayList<Uri> textImageUris = new ArrayList<>();

    private LinearLayout modeContainer;
    private LinearLayout outputBox;
    private TextView statusText;
    private TextView songSelectionText;
    private TextView textSelectionText;
    private TextView correctionSelectionText;
    private TextView outputText;
    private ProgressBar progressBar;
    private VideoView sourceVideoPreview;
    private VideoView outputVideoPreview;
    private VideoView fusionMainPreview;
    private VideoView fusionSingerPreview;
    private LinearLayout songImageStripContainer;
    private LinearLayout textImageStripContainer;
    private LinearLayout correctionImageStripContainer;
    private LinearLayout sourceFrameStripContainer;
    private LinearLayout fusionFrameStripContainer;

    private Spinner formatSpinner;
    private Spinner exportQualitySpinner;
    private Spinner styleSpinner;
    private Spinner motionSpinner;
    private Spinner visualizerSpinner;
    private Spinner correctionSpinner;
    private Spinner replacementModeSpinner;
    private Spinner replacementMotionSpinner;
    private Spinner textDurationSpinner;
    private Spinner textMusicStyleSpinner;
    private Spinner textKeySpinner;
    private Spinner textVoiceTypeSpinner;
    private Spinner textMasteringSpinner;
    private Spinner fusionModeSpinner;
    private Spinner fusionPositionSpinner;

    private EditText songStoryEdit;
    private EditText textPromptEdit;

    private CheckBox testModeCheck;
    private CheckBox useReplacementAudioCheck;
    private CheckBox lockSourceQualityCheck;
    private CheckBox lockSourceMotionCheck;
    private CheckBox noCropZoomCheck;
    private CheckBox preserveOriginalAmbienceCheck;
    private CheckBox preserveOriginalDurationCheck;
    private CheckBox fusionChromaKeyCheck;
    private CheckBox fusionFeatherCheck;
    private CheckBox fusionSyncAudioCheck;

    private CheckBox instFolkGuitarCheck;
    private CheckBox instClassicGuitarCheck;
    private CheckBox instElectricGuitarCheck;
    private CheckBox instPianoCheck;
    private CheckBox instBassCheck;
    private CheckBox instDrumsCheck;
    private CheckBox instPercussionCheck;
    private CheckBox instStringsCheck;

    private EditText replacementStartTimeEdit;
    private EditText replacementPlanSecondsEdit;
    private TextView timelineText;
    private TextView libraryText;
    private TextView homeLibraryText;
    private TextView autoPromptText;
    private TextView textSongStructureText;
    private TextView fusionSelectionText;
    private TextView apiResourceText;

    private EditText fusionStartTimeEdit;
    private EditText fusionDurationEdit;

    private Button songGenerateButton;
    private Button textGenerateButton;
    private Button correctionGenerateButton;
    private Button openButton;
    private EditText pcEngineAddressEdit;
    private TextView localEngineText;
    private Button fusionGenerateButton;
    private MediaPlayer audioPlayer;
    private Uri audioPlayerUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 17, 22));
        getWindow().setNavigationBarColor(Color.rgb(16, 17, 22));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16, 17, 22));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Music2Video Free Studio V4.6 audio local + PC");
        title.setTextColor(Color.rgb(244, 241, 232));
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(4), 0, dp(6));
        root.addView(title);

        TextView subtitle = smallText("V4.6 : priorité Texte → Musique. Maquette locale plus claire : tempo, tonalité, batterie, basse et instruments cochés sont appliqués. La voix Android reste une voix guide synthétique ; vrai chant/auto-tune = moteur PC Linux local.");
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        root.addView(tabs);

        Button homeTab = tabButton("Accueil");
        Button songTab = tabButton("Chanson");
        Button textTab = tabButton("Texte");
        Button correctionTab = tabButton("Correction");
        Button fusionTab = tabButton("Fusion");
        tabs.addView(homeTab);
        tabs.addView(songTab);
        tabs.addView(textTab);
        tabs.addView(correctionTab);
        tabs.addView(fusionTab);
        homeTab.setOnClickListener(v -> showHomeMode());
        songTab.setOnClickListener(v -> showSongMode());
        textTab.setOnClickListener(v -> showTextMode());
        correctionTab.setOnClickListener(v -> showCorrectionMode());
        fusionTab.setOnClickListener(v -> showFusionMode());

        modeContainer = new LinearLayout(this);
        modeContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.setPadding(0, dp(8), 0, dp(8));
        root.addView(modeContainer);

        buildProgressAndOutput(root);
        buildLocalPcEngine(root);
        showHomeMode();
        setContentView(scroll);
        loadLastOutputUri();
    }

    private void buildProgressAndOutput(LinearLayout root) {
        root.addView(sectionTitle("Progression et résultat"));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.VISIBLE);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(16));
        barParams.setMargins(0, dp(8), 0, dp(8));
        root.addView(progressBar, barParams);

        statusText = smallText("Prêt. Choisissez un mode ci-dessus.");
        root.addView(statusText);

        outputBox = card();
        outputBox.setVisibility(View.GONE);
        outputText = smallText("Aucune vidéo exportée pour le moment.");
        outputBox.addView(outputText);
        outputVideoPreview = new VideoView(this);
        outputBox.addView(outputVideoPreview, videoLayoutParams());
        openButton = secondaryButton("Lire / vérifier le dernier export");
        openButton.setOnClickListener(v -> openLastVideo());
        outputBox.addView(openButton);
        Button shareExportButton = secondaryButton("Partager / télécharger le MP4 exporté");
        shareExportButton.setOnClickListener(v -> shareLastVideo());
        outputBox.addView(shareExportButton);
        root.addView(outputBox);
    }

    private void buildLocalPcEngine(LinearLayout root) {
        root.addView(sectionTitle("Moteur PC local / open source"));
        TextView intro = smallText("Aucune redirection vers API payante : les fonctions lourdes doivent passer par l'export local Android ou par un PC local gratuit/open source que vous contrôlez.");
        root.addView(intro);

        LinearLayout box = card();
        box.addView(label("Adresse du moteur PC local"));
        pcEngineAddressEdit = new EditText(this);
        pcEngineAddressEdit.setText("http://192.168.1.10:7860");
        pcEngineAddressEdit.setHint("Adresse locale du PC, ex. http://192.168.1.10:7860");
        pcEngineAddressEdit.setSingleLine(true);
        pcEngineAddressEdit.setTextColor(Color.rgb(244, 241, 232));
        pcEngineAddressEdit.setHintTextColor(Color.rgb(160, 154, 138));
        pcEngineAddressEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        box.addView(pcEngineAddressEdit);

        Button helpButton = secondaryButton("? Comprendre le moteur PC local");
        helpButton.setOnClickListener(v -> showPcEngineHelpDialog());
        box.addView(helpButton);

        Button testButton = secondaryButton("Préparer connexion PC local");
        testButton.setOnClickListener(v -> {
            String address = pcEngineAddressEdit == null || pcEngineAddressEdit.getText() == null ? "" : pcEngineAddressEdit.getText().toString().trim();
            if (address.length() == 0) address = "adresse non renseignée";
            if (localEngineText != null) localEngineText.setText("Moteur PC local préparé : " + address + "\nAucun appel cloud/payant lancé. La connexion réelle sera activée quand le compagnon PC sera installé.");
            Toast.makeText(this, "Préparation PC local enregistrée. Aucun service payant lancé.", Toast.LENGTH_LONG).show();
        });
        box.addView(testButton);

        localEngineText = smallText("Mode actuel : Android local. Le PC Companion sera utilisé uniquement sur votre réseau local pour les tâches lourdes : 4K, upscale, lip-sync, RIFE, MusicGen, ComfyUI.");
        box.addView(localEngineText);
        root.addView(box);
    }

    private void showHomeMode() {
        modeContainer.removeAllViews();
        LinearLayout hero = premiumCard();
        TextView h1 = sectionTitle("Accueil studio moderne");
        TextView h2 = smallText("Tableau de bord local : derniers rendus, accès rapide, bibliothèque par catégorie et retour direct vers correction/timeline. L'original reste toujours protégé.");
        hero.addView(h1);
        hero.addView(h2);
        modeContainer.addView(hero);

        Button checklist = secondaryButton("✅ Voir la checklist V4.6 audio local + PC");
        checklist.setOnClickListener(v -> showCompleteChecklistDialog());
        modeContainer.addView(checklist);

        LinearLayout grid1 = new LinearLayout(this);
        grid1.setOrientation(LinearLayout.HORIZONTAL);
        modeContainer.addView(grid1);
        grid1.addView(dashboardCard("🎬", "Vidéos", "Derniers exports MP4", v -> openLastVideo()));
        grid1.addView(dashboardCard("🎵", "Musiques", "Boucles / sons libres", v -> showAudioSourcesDialog(textPromptEdit)));

        LinearLayout grid2 = new LinearLayout(this);
        grid2.setOrientation(LinearLayout.HORIZONTAL);
        modeContainer.addView(grid2);
        grid2.addView(dashboardCard("🖼", "Images", "Plans et photos", v -> showCorrectionMode()));
        grid2.addView(dashboardCard("🕒", "Timecode", "Studio multipiste", v -> showCorrectionMode()));

        LinearLayout grid3 = new LinearLayout(this);
        grid3.setOrientation(LinearLayout.HORIZONTAL);
        modeContainer.addView(grid3);
        grid3.addView(dashboardCard("🎤", "Fusion", "Chanteur dans vidéo", v -> showFusionMode()));
        grid3.addView(dashboardCard("🌍", "Ressources", "Pexels / Pixabay / Jamendo", v -> showFreeResourceDialog()));

        homeLibraryText = smallText(
                "Bibliothèque locale prévue en accès direct :\n" +
                "• vidéos créées par chanson ;\n" +
                "• vidéos créées par texte ;\n" +
                "• corrections non destructives ;\n" +
                "• musiques, images et séquences classées par catégorie.\n\n" +
                "Le bouton ci-dessous garde maintenant en mémoire le dernier export connu, même après fermeture de l’application, si Android conserve l’accès au fichier. Les rendus restent dans Galerie > Movies > Music2VideoFree.");
        modeContainer.addView(fileCard("Bibliothèque / dernières créations", homeLibraryText));

        Button openLast = primaryButton("Ouvrir la dernière vidéo créée");
        openLast.setOnClickListener(v -> openLastVideo());
        modeContainer.addView(openLast);

        Button qSong = secondaryButton("Créer depuis une chanson");
        qSong.setOnClickListener(v -> showSongMode());
        Button qText = secondaryButton("Créer depuis un texte");
        qText.setOnClickListener(v -> showTextMode());
        Button qCorrection = secondaryButton("Studio correction / timeline multipiste");
        qCorrection.setOnClickListener(v -> showCorrectionMode());
        Button qFusion = secondaryButton("Vidéo dans vidéo / fusion chanteur");
        qFusion.setOnClickListener(v -> showFusionMode());
        modeContainer.addView(qSong);
        modeContainer.addView(qText);
        modeContainer.addView(qCorrection);
        modeContainer.addView(qFusion);
    }

    private void showSongMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Créer une vidéo depuis une chanson"));
        modeContainer.addView(smallText("Importez la chanson, ajoutez des images si vous en avez, puis exportez une vidéo de la durée complète de la musique. Le mode 20 secondes est désactivé par défaut."));

        Button pickAudio = primaryButton("Choisir la musique");
        pickAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_AUDIO));
        modeContainer.addView(pickAudio);

        Button addImages = secondaryButton("Ajouter des images pour la vidéo");
        addImages.setOnClickListener(v -> pickMultiple("image/*", REQ_IMAGES));
        modeContainer.addView(addImages);

        LinearLayout fileActions = new LinearLayout(this);
        fileActions.setOrientation(LinearLayout.HORIZONTAL);
        Button openAudio = compactButton("Lire/Pause intégré");
        openAudio.setOnClickListener(v -> playPauseAudio(audioUri));
        Button openExternalAudio = compactButton("Lecteur téléphone");
        openExternalAudio.setOnClickListener(v -> openUri(audioUri, "audio/*"));
        Button clearSong = compactButton("Supprimer fichiers");
        clearSong.setOnClickListener(v -> { audioUri = null; imageUris.clear(); updateSongSelectionText(); });
        fileActions.addView(openAudio);
        fileActions.addView(openExternalAudio);
        fileActions.addView(clearSong);
        modeContainer.addView(fileActions);

        songSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers importés", songSelectionText));
        songImageStripContainer = new LinearLayout(this);
        songImageStripContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.addView(songImageStripContainer);
        updateSongSelectionText();

        modeContainer.addView(label("Histoire ou intention visuelle"));
        songStoryEdit = editText("Exemple : clip cinématographique noir et blanc dans un village portugais, scènes cohérentes avec la chanson, sans texte à l'écran…", 4);
        modeContainer.addView(songStoryEdit);

        LinearLayout promptCard = fileCard("Prompt automatique musique → vidéo", smallText("Générez une base de storyboard automatiquement, puis ajustez-la avant l'export. Aucun texte n'est incrusté dans la vidéo sauf si vous l'écrivez explicitement."));
        autoPromptText = smallText("Prompt auto : non généré.");
        promptCard.addView(autoPromptText);
        modeContainer.addView(promptCard);
        Button autoPromptButton = secondaryButton("✨ Remplir un prompt automatique cinématographique");
        autoPromptButton.setOnClickListener(v -> fillAutomaticSongPrompt());
        modeContainer.addView(autoPromptButton);
        Button promptHelp = secondaryButton("? Aide : comment utiliser le prompt automatique");
        promptHelp.setOnClickListener(v -> showPromptHelpDialog());
        modeContainer.addView(promptHelp);
        addFreeResourceButtons(modeContainer, songStoryEdit);

        addCommonVideoControls(modeContainer);

        addTestModeCheck(modeContainer);

        songGenerateButton = primaryButton("Générer la vidéo MP4 complète");
        songGenerateButton.setOnClickListener(v -> startSongRender());
        modeContainer.addView(songGenerateButton);
    }

    private void showTextMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Créer une vidéo depuis un texte"));
        modeContainer.addView(smallText("V4.6 : génération locale corrigée : tonalité appliquée, rythme plus marqué, instruments cochés plus audibles, temps estimé affiché. Voix réaliste et auto-tune : moteur PC Linux local."));
        addExpandableInfoButton(modeContainer, "Comment utiliser Texte → Musique", "1. Écrivez une idée courte ou une histoire.\n2. Vous pouvez générer automatiquement une structure de chanson : intro, couplet, refrain, pont, outro.\n3. Créez une maquette locale rythmée avec les instruments sélectionnés, ou connectez le futur moteur PC Linux pour une vraie voix chantée.\n4. Ajoutez vos images, ou cherchez des médias libres via Pexels/Pixabay/Jamendo.\n5. Lancez la vidéo : l'application crée un MP4 local sans coût obligatoire.");

        textPromptEdit = editText("Touchez ici et écrivez votre idée, votre histoire ou le thème de la chanson…", 7);
        modeContainer.addView(textPromptEdit);
        Button focusText = secondaryButton("Écrire / ouvrir le clavier");
        focusText.setOnClickListener(v -> focusAndShowKeyboard(textPromptEdit));
        modeContainer.addView(focusText);

        modeContainer.addView(label("Style musical / ambiance chanson"));
        textMusicStyleSpinner = spinner(new String[]{"Pop cinématique", "Ballade portugaise", "Rock émotionnel", "Reggae solaire", "Rap mélodique", "Émotion piano", "Dance / électro", "Film orchestral", "Sport chic"});
        modeContainer.addView(textMusicStyleSpinner);

        modeContainer.addView(label("Tonalité"));
        textKeySpinner = spinner(new String[]{"Tonalité auto", "Do majeur (C)", "Ré majeur (D)", "Mi majeur (E)", "Fa majeur (F)", "Sol majeur (G)", "La majeur (A)", "La mineur (Am)", "Mi mineur (Em)", "Ré mineur (Dm)"});
        modeContainer.addView(textKeySpinner);

        modeContainer.addView(label("Type de voix / production"));
        textVoiceTypeSpinner = spinner(new String[]{"Voix guide homme synthétique", "Voix guide femme synthétique", "Ma voix - piste PC séparée", "Instrumental seul"});
        modeContainer.addView(textVoiceTypeSpinner);
        modeContainer.addView(buildInstrumentSelectionCard());

        modeContainer.addView(label("Mastering final"));
        textMasteringSpinner = spinner(new String[]{"Streaming propre", "Radio fort", "Cinéma large", "Voix claire", "Doux acoustique", "Rap / club"});
        modeContainer.addView(textMasteringSpinner);

        LinearLayout textTools = new LinearLayout(this);
        textTools.setOrientation(LinearLayout.HORIZONTAL);
        Button generateLyrics = compactButton("Paroles auto");
        generateLyrics.setOnClickListener(v -> generateStructuredLyricsFromPrompt());
        Button generateMusic = compactButton("Maquette locale");
        generateMusic.setOnClickListener(v -> showLocalLoopChoiceDialog());
        textTools.addView(generateLyrics);
        textTools.addView(generateMusic);
        modeContainer.addView(textTools);

        Button productionPlan = secondaryButton("🎚 Plan pistes / voix / moteur PC");
        productionPlan.setOnClickListener(v -> showProductionPlanDialog());
        modeContainer.addView(productionPlan);

        textSongStructureText = smallText("Structure chanson : non générée. Utilisez Paroles auto puis Maquette locale. L'app générera une maquette audio avec pistes mixées selon les instruments sélectionnés.");
        modeContainer.addView(fileCard("Paroles / structure musicale / pistes", textSongStructureText));

        Button pickTextAudio = secondaryButton("Ajouter une musique optionnelle");
        pickTextAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_TEXT_AUDIO));
        modeContainer.addView(pickTextAudio);

        Button pickTextImages = secondaryButton("Ajouter plusieurs images de scène");
        pickTextImages.setOnClickListener(v -> pickMultiple("image/*", REQ_TEXT_IMAGES));
        modeContainer.addView(pickTextImages);

        LinearLayout audioRow = new LinearLayout(this);
        audioRow.setOrientation(LinearLayout.HORIZONTAL);
        Button playTextAudio = compactButton("Lire/Pause audio");
        playTextAudio.setOnClickListener(v -> playPauseAudio(textAudioUri != null ? textAudioUri : generatedTextAudioUri));
        Button clearTextAudio = compactButton("Supprimer audio/images");
        clearTextAudio.setOnClickListener(v -> { textAudioUri = null; generatedTextAudioUri = null; textImageUris.clear(); updateTextSelectionText(); });
        audioRow.addView(playTextAudio);
        audioRow.addView(clearTextAudio);
        modeContainer.addView(audioRow);

        textSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers du mode texte", textSelectionText));
        textImageStripContainer = new LinearLayout(this);
        textImageStripContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.addView(textImageStripContainer);
        updateTextSelectionText();

        addFreeResourceButtons(modeContainer, textPromptEdit);

        modeContainer.addView(label("Durée si aucune musique n'est ajoutée"));
        textDurationSpinner = spinner(new String[]{"15 secondes", "30 secondes", "60 secondes", "90 secondes", "2 minutes", "3 minutes", "4 minutes", "Durée libre via musique"});
        modeContainer.addView(textDurationSpinner);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        textGenerateButton = primaryButton("Créer la vidéo depuis le texte");
        textGenerateButton.setOnClickListener(v -> startTextRender());
        modeContainer.addView(textGenerateButton);
    }


    private LinearLayout buildInstrumentSelectionCard() {
        LinearLayout box = card();
        box.addView(label("Instruments à utiliser"));
        box.addView(smallText("Cochez les instruments à entendre dans la maquette locale. Android mixe ces couches dans un seul fichier audio témoin. Les vraies pistes séparées éditables, chant réaliste et auto-tune seront générés par le moteur PC Linux local."));
        instFolkGuitarCheck = makeCheckBox("Guitare acoustique folk", true);
        instClassicGuitarCheck = makeCheckBox("Guitare acoustique classique", false);
        instElectricGuitarCheck = makeCheckBox("Guitare électrique", false);
        instPianoCheck = makeCheckBox("Piano", true);
        instBassCheck = makeCheckBox("Basse", true);
        instDrumsCheck = makeCheckBox("Batterie", true);
        instPercussionCheck = makeCheckBox("Percussions", true);
        instStringsCheck = makeCheckBox("Strings / nappes", false);
        box.addView(instFolkGuitarCheck);
        box.addView(instClassicGuitarCheck);
        box.addView(instElectricGuitarCheck);
        box.addView(instPianoCheck);
        box.addView(instBassCheck);
        box.addView(instDrumsCheck);
        box.addView(instPercussionCheck);
        box.addView(instStringsCheck);
        return box;
    }

    private void showCorrectionMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Corriger / améliorer une vidéo existante"));
        modeContainer.addView(smallText("Mode non destructif : la vidéo originale reste intacte. Importez une vidéo déjà créée, placez vos images au timecode exact, verrouillez la qualité et conservez la motion source."));

        Button pickVideo = primaryButton("Importer vidéo / clip dans le studio multipiste");
        pickVideo.setOnClickListener(v -> pickSingle("video/*", REQ_CORRECTION_VIDEO));
        modeContainer.addView(pickVideo);

        sourceVideoPreview = new VideoView(this);
        sourceVideoPreview.setVisibility(videoToCorrectUri == null ? View.GONE : View.VISIBLE);
        modeContainer.addView(sourceVideoPreview, videoLayoutParams());
        if (videoToCorrectUri != null) prepareVideoPreview(sourceVideoPreview, videoToCorrectUri, false);
        LinearLayout sourceVideoControls = new LinearLayout(this);
        sourceVideoControls.setOrientation(LinearLayout.HORIZONTAL);
        Button playSource = compactButton("Lire aperçu");
        playSource.setOnClickListener(v -> { if (sourceVideoPreview != null) sourceVideoPreview.start(); });
        Button pauseSource = compactButton("Pause");
        pauseSource.setOnClickListener(v -> { if (sourceVideoPreview != null) sourceVideoPreview.pause(); });
        sourceVideoControls.addView(playSource);
        sourceVideoControls.addView(pauseSource);
        modeContainer.addView(sourceVideoControls);
        sourceFrameStripContainer = new LinearLayout(this);
        sourceFrameStripContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.addView(sourceFrameStripContainer);
        populateVideoFrameStrip(sourceFrameStripContainer, videoToCorrectUri, true);

        Button pickReplacementImages = secondaryButton("Ajouter image(s) de remplacement optionnelle(s)");
        pickReplacementImages.setOnClickListener(v -> pickMultiple("image/*", REQ_REPLACEMENT_IMAGES));
        modeContainer.addView(pickReplacementImages);

        Button pickCorrectionAudio = secondaryButton("Ajouter nouvelle musique optionnelle");
        pickCorrectionAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_CORRECTION_AUDIO));
        modeContainer.addView(pickCorrectionAudio);

        Button clearCorrectionFiles = secondaryButton("Supprimer les fichiers de correction sélectionnés");
        clearCorrectionFiles.setOnClickListener(v -> {
            videoToCorrectUri = null;
            correctionAudioUri = null;
            replacementImageUris.clear();
            if (useReplacementAudioCheck != null) useReplacementAudioCheck.setChecked(false);
            updateCorrectionSelectionText();
            showCorrectionMode();
        });
        modeContainer.addView(clearCorrectionFiles);

        correctionSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers importés pour correction", correctionSelectionText));
        correctionImageStripContainer = new LinearLayout(this);
        correctionImageStripContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.addView(correctionImageStripContainer);
        updateCorrectionSelectionText();

        buildTimelineEditor(modeContainer);

        modeContainer.addView(label("Type de correction"));
        correctionSpinner = spinner(new String[]{
                "Préserver original — copie non destructive",
                "Garder ambiance originale — aucun filtre",
                "Montage timecodé sans altérer source",
                "Auto léger sans détruire",
                "Éclaircir",
                "Contraste fort",
                "Couleurs douces",
                "Noir et blanc cinéma",
                "Stabilisation visuelle légère"
        });
        modeContainer.addView(correctionSpinner);
        preserveOriginalAmbienceCheck = new CheckBox(this);
        preserveOriginalAmbienceCheck.setText("Garder l'ambiance originale — recommandé");
        preserveOriginalAmbienceCheck.setTextColor(Color.rgb(244, 241, 232));
        preserveOriginalAmbienceCheck.setChecked(true);
        modeContainer.addView(preserveOriginalAmbienceCheck);

        modeContainer.addView(label("Remplacement d'image"));
        replacementModeSpinner = spinner(new String[]{
                "Garder la vidéo originale",
                "Remplacer scènes au timecode",
                "Remplacer quelques scènes par les images",
                "Alterner vidéo originale et images",
                "Remplacer toute la vidéo par les images"
        });
        modeContainer.addView(replacementModeSpinner);

        modeContainer.addView(label("Motion des images remplacées"));
        replacementMotionSpinner = spinner(new String[]{
                "Conserver motion source / aucun zoom",
                "Image fixe timecodée",
                "Garder motion similaire",
                "Motion corrigée douce",
                "Motion dynamique",
                "Motion pulse audio"
        });
        modeContainer.addView(replacementMotionSpinner);
        Button motionHelp = secondaryButton("? Expliquer les motions et le verrouillage");
        motionHelp.setOnClickListener(v -> showMotionHelpDialog());
        modeContainer.addView(motionHelp);

        useReplacementAudioCheck = new CheckBox(this);
        useReplacementAudioCheck.setText("Remplacer l'audio par la nouvelle musique sélectionnée");
        useReplacementAudioCheck.setTextColor(Color.rgb(244, 241, 232));
        useReplacementAudioCheck.setChecked(false);
        modeContainer.addView(useReplacementAudioCheck);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        correctionGenerateButton = primaryButton("Exporter la vidéo corrigée en MP4");
        correctionGenerateButton.setOnClickListener(v -> startVideoCorrection());
        modeContainer.addView(correctionGenerateButton);
    }

    private void showFusionMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Vidéo dans vidéo / fusion chanteur"));
        modeContainer.addView(smallText("Intégrez une vidéo où vous chantez dans une vidéo narrative, en piste séparée et sans remplacer l'original."));
        addExpandableInfoButton(modeContainer, "Principe de la fusion", "1. Importez la vidéo narrative principale.\n2. Importez la vidéo secondaire, par exemple vous en train de chanter.\n3. Choisissez le timecode d'entrée, la durée et le mode d'incrustation.\n4. Gardez la qualité, l'ambiance et la motion de la vidéo principale verrouillées.\n5. L'export crée une nouvelle vidéo MP4 non destructive.");

        Button pickMain = primaryButton("Importer vidéo principale narrative");
        pickMain.setOnClickListener(v -> pickSingle("video/*", REQ_FUSION_MAIN_VIDEO));
        modeContainer.addView(pickMain);
        fusionMainPreview = new VideoView(this);
        fusionMainPreview.setVisibility(fusionMainVideoUri == null ? View.GONE : View.VISIBLE);
        modeContainer.addView(fusionMainPreview, videoLayoutParams());
        if (fusionMainVideoUri != null) prepareVideoPreview(fusionMainPreview, fusionMainVideoUri, false);

        fusionFrameStripContainer = new LinearLayout(this);
        fusionFrameStripContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.addView(fusionFrameStripContainer);
        populateVideoFrameStrip(fusionFrameStripContainer, fusionMainVideoUri, false);

        Button pickSinger = secondaryButton("Importer vidéo secondaire chanteur");
        pickSinger.setOnClickListener(v -> pickSingle("video/*", REQ_FUSION_SINGER_VIDEO));
        modeContainer.addView(pickSinger);
        fusionSingerPreview = new VideoView(this);
        fusionSingerPreview.setVisibility(fusionSingerVideoUri == null ? View.GONE : View.VISIBLE);
        modeContainer.addView(fusionSingerPreview, videoLayoutParams());
        if (fusionSingerVideoUri != null) prepareVideoPreview(fusionSingerPreview, fusionSingerVideoUri, false);

        LinearLayout fusionPreviewControls = new LinearLayout(this);
        fusionPreviewControls.setOrientation(LinearLayout.HORIZONTAL);
        Button playMain = compactButton("Lire récit");
        playMain.setOnClickListener(v -> { if (fusionMainPreview != null) fusionMainPreview.start(); });
        Button playSinger = compactButton("Lire chanteur");
        playSinger.setOnClickListener(v -> { if (fusionSingerPreview != null) fusionSingerPreview.start(); });
        fusionPreviewControls.addView(playMain);
        fusionPreviewControls.addView(playSinger);
        modeContainer.addView(fusionPreviewControls);

        Button pickFusionAudio = secondaryButton("Audio final optionnel / chanson complète");
        pickFusionAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_FUSION_AUDIO));
        modeContainer.addView(pickFusionAudio);
        Button playFusionAudio = secondaryButton("Lire/Pause audio final intégré");
        playFusionAudio.setOnClickListener(v -> playPauseAudio(fusionAudioUri));
        modeContainer.addView(playFusionAudio);

        fusionSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers fusion", fusionSelectionText));
        updateFusionSelectionText();

        modeContainer.addView(label("Timecode d'entrée de la vidéo chanteur"));
        fusionStartTimeEdit = editText("00:00:20.000", 1);
        fusionStartTimeEdit.setText("00:00:20.000");
        modeContainer.addView(fusionStartTimeEdit);
        LinearLayout fusionTimeAdjust = new LinearLayout(this);
        fusionTimeAdjust.setOrientation(LinearLayout.HORIZONTAL);
        Button minus = compactButton("-0,5 s");
        minus.setOnClickListener(v -> adjustFusionStart(-0.5));
        Button plus = compactButton("+0,5 s");
        plus.setOnClickListener(v -> adjustFusionStart(0.5));
        fusionTimeAdjust.addView(minus);
        fusionTimeAdjust.addView(plus);
        modeContainer.addView(fusionTimeAdjust);

        modeContainer.addView(label("Durée d'apparition de la vidéo chanteur"));
        fusionDurationEdit = editText("20", 1);
        fusionDurationEdit.setText("20");
        modeContainer.addView(fusionDurationEdit);

        modeContainer.addView(label("Mode d'intégration"));
        fusionModeSpinner = spinner(new String[]{"Incrustation picture-in-picture", "Plein écran temporaire", "Fondu cinématographique", "Superposition douce", "Écran partagé"});
        modeContainer.addView(fusionModeSpinner);
        modeContainer.addView(label("Position"));
        fusionPositionSpinner = spinner(new String[]{"Bas droite", "Bas gauche", "Haut droite", "Haut gauche", "Centre", "Plein cadre"});
        modeContainer.addView(fusionPositionSpinner);

        fusionChromaKeyCheck = new CheckBox(this);
        fusionChromaKeyCheck.setText("Fond vert / chroma key simple si disponible");
        fusionChromaKeyCheck.setTextColor(Color.rgb(244, 241, 232));
        fusionChromaKeyCheck.setChecked(false);
        modeContainer.addView(fusionChromaKeyCheck);

        fusionFeatherCheck = new CheckBox(this);
        fusionFeatherCheck.setText("Adoucir les bords / fusion douce");
        fusionFeatherCheck.setTextColor(Color.rgb(244, 241, 232));
        fusionFeatherCheck.setChecked(true);
        modeContainer.addView(fusionFeatherCheck);

        fusionSyncAudioCheck = new CheckBox(this);
        fusionSyncAudioCheck.setText("Synchroniser avec l'audio final sélectionné");
        fusionSyncAudioCheck.setTextColor(Color.rgb(244, 241, 232));
        fusionSyncAudioCheck.setChecked(true);
        modeContainer.addView(fusionSyncAudioCheck);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        Button helpFusion = secondaryButton("? Conseils pour une fusion propre");
        helpFusion.setOnClickListener(v -> showFusionHelpDialog());
        modeContainer.addView(helpFusion);

        fusionGenerateButton = primaryButton("Créer la vidéo fusionnée");
        fusionGenerateButton.setOnClickListener(v -> startFusionRender());
        modeContainer.addView(fusionGenerateButton);
    }

    private void addCommonVideoControls(LinearLayout parent) {
        parent.addView(label("Format d'export"));
        formatSpinner = spinner(new String[]{"YouTube 16:9", "TikTok / Reels 9:16", "Carré 1:1"});
        parent.addView(formatSpinner);

        parent.addView(label("Qualité d'export"));
        exportQualitySpinner = spinner(new String[]{"Qualité source / auto", "720p HD", "1080p Full HD", "4K UHD", "Garder qualité source si vidéo importée"});
        parent.addView(exportQualitySpinner);
        parent.addView(smallText("V4.2 complète : Qualité source = copie non destructive. 720p/1080p/4K = export MP4 réel avec réencodage local. Les API gratuites servent aux médias libres, pas à créer le 4K."));
        Button qualityHelp = secondaryButton("? Expliquer 720p / 1080p / 4K / qualité source");
        qualityHelp.setOnClickListener(v -> showQualityHelpDialog());
        parent.addView(qualityHelp);
        Button apiExportHelp = secondaryButton("? Export 4K réel + API gratuites");
        apiExportHelp.setOnClickListener(v -> showExportApiHelpDialog());
        parent.addView(apiExportHelp);

        parent.addView(label("Ambiance visuelle"));
        styleSpinner = spinner(new String[]{"Garder ambiance originale", "Cinématique sombre", "Rêve lumineux", "Nature douce", "Sport chic", "Abstrait néon", "Documentaire réaliste", "Clip musical moderne"});
        parent.addView(styleSpinner);

        parent.addView(label("Motion"));
        motionSpinner = spinner(new String[]{"Conserver motion source", "Ken Burns", "Slide dynamique", "Pulse audio", "Rotation douce", "Shake dramatique", "Image fixe sans mouvement"});
        parent.addView(motionSpinner);
        Button commonMotionHelp = secondaryButton("? Quelle motion choisir ?");
        commonMotionHelp.setOnClickListener(v -> showSelectedMotionHelpDialog());
        parent.addView(commonMotionHelp);

        parent.addView(label("Visualiseur audio"));
        visualizerSpinner = spinner(new String[]{"Minimal", "Barres audio", "Anneau audio"});
        parent.addView(visualizerSpinner);
    }

    private void buildTimelineEditor(LinearLayout parent) {
        parent.addView(sectionTitle("Studio d'arrangement multipiste / timecode"));
        parent.addView(smallText("Placez chaque photo avec un timecode précis. La piste vidéo source reste verrouillée par défaut pour éviter toute perte de qualité ou changement de motion."));

        lockSourceQualityCheck = new CheckBox(this);
        lockSourceQualityCheck.setText("Verrouiller qualité source — recommandé");
        lockSourceQualityCheck.setTextColor(Color.rgb(244, 241, 232));
        lockSourceQualityCheck.setChecked(true);
        parent.addView(lockSourceQualityCheck);

        lockSourceMotionCheck = new CheckBox(this);
        lockSourceMotionCheck.setText("Verrouiller motion originale de la vidéo");
        lockSourceMotionCheck.setTextColor(Color.rgb(244, 241, 232));
        lockSourceMotionCheck.setChecked(true);
        parent.addView(lockSourceMotionCheck);

        noCropZoomCheck = new CheckBox(this);
        noCropZoomCheck.setText("Ne pas recadrer / ne pas zoomer la vidéo source");
        noCropZoomCheck.setTextColor(Color.rgb(244, 241, 232));
        noCropZoomCheck.setChecked(true);
        parent.addView(noCropZoomCheck);

        preserveOriginalDurationCheck = new CheckBox(this);
        preserveOriginalDurationCheck.setText("Préserver la durée originale — recommandé");
        preserveOriginalDurationCheck.setTextColor(Color.rgb(244, 241, 232));
        preserveOriginalDurationCheck.setChecked(true);
        parent.addView(preserveOriginalDurationCheck);

        parent.addView(label("Timecode de départ du premier remplacement"));
        replacementStartTimeEdit = editText("00:00:00.000", 1);
        replacementStartTimeEdit.setText("00:00:00.000");
        parent.addView(replacementStartTimeEdit);

        LinearLayout timeAdjust = new LinearLayout(this);
        timeAdjust.setOrientation(LinearLayout.HORIZONTAL);
        Button minusHalf = compactButton("-0,5 s");
        minusHalf.setOnClickListener(v -> adjustReplacementStart(-0.5));
        Button plusHalf = compactButton("+0,5 s");
        plusHalf.setOnClickListener(v -> adjustReplacementStart(0.5));
        timeAdjust.addView(minusHalf);
        timeAdjust.addView(plusHalf);
        parent.addView(timeAdjust);
        Button seekTime = secondaryButton("Aller au timecode dans l'aperçu source");
        seekTime.setOnClickListener(v -> seekSourcePreviewToReplacementStart());
        parent.addView(seekTime);

        parent.addView(label("Durée de chaque photo / séquence de photos"));
        replacementPlanSecondsEdit = editText("4.5 secondes", 1);
        replacementPlanSecondsEdit.setText("4.5");
        parent.addView(replacementPlanSecondsEdit);

        Button recalc = secondaryButton("Recalculer / afficher les timecodes des photos");
        recalc.setOnClickListener(v -> updateTimelineText());
        parent.addView(recalc);
        Button validate = secondaryButton("Valider le placement sécurisé");
        validate.setOnClickListener(v -> validateSafePlacement());
        parent.addView(validate);

        Button help = secondaryButton("? Aide timecode : placer une image sans erreur");
        help.setOnClickListener(v -> showTimecodeHelpDialog());
        parent.addView(help);

        timelineText = smallText("");
        parent.addView(fileCard("Timeline des photos et séquences", timelineText));
        updateTimelineText();
    }

    private void addTestModeCheck(LinearLayout parent) {
        testModeCheck = new CheckBox(this);
        testModeCheck.setText("Mode test : limiter à 20 secondes — désactivé par défaut");
        testModeCheck.setTextColor(Color.rgb(244, 241, 232));
        testModeCheck.setChecked(false);
        parent.addView(testModeCheck);
    }

    private void pickSingle(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    private void pickMultiple(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        final int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;

        if (requestCode == REQ_AUDIO && data.getData() != null) {
            audioUri = data.getData();
            persistReadPermission(audioUri, flags);
            updateSongSelectionText();
        } else if (requestCode == REQ_TEXT_AUDIO && data.getData() != null) {
            textAudioUri = data.getData();
            persistReadPermission(textAudioUri, flags);
            updateTextSelectionText();
        } else if (requestCode == REQ_IMAGES) {
            addReturnedUris(data, imageUris, flags);
            updateSongSelectionText();
        } else if (requestCode == REQ_TEXT_IMAGES) {
            addReturnedUris(data, textImageUris, flags);
            updateTextSelectionText();
        } else if (requestCode == REQ_REPLACEMENT_IMAGES) {
            addReturnedUris(data, replacementImageUris, flags);
            updateCorrectionSelectionText();
        } else if (requestCode == REQ_CORRECTION_VIDEO && data.getData() != null) {
            videoToCorrectUri = data.getData();
            persistReadPermission(videoToCorrectUri, flags);
            updateCorrectionSelectionText();
            showCorrectionMode();
        } else if (requestCode == REQ_CORRECTION_AUDIO && data.getData() != null) {
            correctionAudioUri = data.getData();
            persistReadPermission(correctionAudioUri, flags);
            if (useReplacementAudioCheck != null) useReplacementAudioCheck.setChecked(true);
            updateCorrectionSelectionText();
        } else if (requestCode == REQ_FUSION_MAIN_VIDEO && data.getData() != null) {
            fusionMainVideoUri = data.getData();
            persistReadPermission(fusionMainVideoUri, flags);
            showFusionMode();
        } else if (requestCode == REQ_FUSION_SINGER_VIDEO && data.getData() != null) {
            fusionSingerVideoUri = data.getData();
            persistReadPermission(fusionSingerVideoUri, flags);
            showFusionMode();
        } else if (requestCode == REQ_FUSION_AUDIO && data.getData() != null) {
            fusionAudioUri = data.getData();
            persistReadPermission(fusionAudioUri, flags);
            updateFusionSelectionText();
        }
    }

    private void addReturnedUris(Intent data, ArrayList<Uri> list, int flags) {
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < count; i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                list.add(uri);
                persistReadPermission(uri, flags);
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            list.add(uri);
            persistReadPermission(uri, flags);
        }
    }

    private void persistReadPermission(Uri uri, int flags) {
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
    }

    private void updateSongSelectionText() {
        if (songSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Musique : ").append(describeMedia(audioUri)).append("\n");
        sb.append("Images : ").append(imageUris.size()).append(imageUris.isEmpty() ? "" : " image(s) sélectionnée(s)").append("\n");
        if (!imageUris.isEmpty()) sb.append("Première image : ").append(nameOf(imageUris.get(0))).append("\n");
        sb.append("Contrôle : vous pouvez écouter la musique, supprimer les fichiers et relancer un import.");
        songSelectionText.setText(sb.toString());
        refreshImageStrip(songImageStripContainer, imageUris, "Aperçu des images importées");
    }

    private void updateTextSelectionText() {
        if (textSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Musique optionnelle : ").append(describeMedia(textAudioUri)).append("\n");
        sb.append("Boucle locale générée : ").append(describeMedia(generatedTextAudioUri)).append("\n");
        sb.append("Images de scène : ").append(textImageUris.size()).append(textImageUris.isEmpty() ? "" : " image(s)").append("\n");
        sb.append("Conseil : si aucune image n'est ajoutée, l'app utilise des cartes visuelles locales. Pour un résultat réaliste, importez des images ou cherchez des médias libres.");
        textSelectionText.setText(sb.toString());
        refreshImageStrip(textImageStripContainer, textImageUris, "Aperçu des images de scène");
    }

    private void updateCorrectionSelectionText() {
        if (correctionSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Vidéo originale : ").append(describeMedia(videoToCorrectUri)).append("\n");
        sb.append("Images de remplacement : ").append(replacementImageUris.size()).append("\n");
        sb.append("Nouvelle musique : ").append(describeMedia(correctionAudioUri)).append("\n");
        sb.append("Règle : la vidéo source reste intacte ; l'export crée une nouvelle copie.");
        correctionSelectionText.setText(sb.toString());
        refreshImageStrip(correctionImageStripContainer, replacementImageUris, "Aperçu des images de remplacement");
        populateVideoFrameStrip(sourceFrameStripContainer, videoToCorrectUri, true);
        updateTimelineText();
    }

    private void startSongRender() {
        if (audioUri == null) {
            Toast.makeText(this, "Choisissez d'abord une musique.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageUris.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Aucune image ajoutée")
                    .setMessage("Sans images importées, le rendu local sera abstrait. Pour obtenir une histoire réaliste, ajoutez vos photos/images ou utilisez plus tard un module IA visuel explicitement activé.")
                    .setPositiveButton("Continuer", (d, w) -> renderSongNow())
                    .setNegativeButton("Ajouter des images", null)
                    .show();
        } else {
            renderSongNow();
        }
    }

    private void renderSongNow() {
        ProjectOptions options = readOptions();
        String story = songStoryEdit == null || songStoryEdit.getText() == null ? "" : songStoryEdit.getText().toString().trim();
        options.filmPrompt = story;
        setBusy(true, "Préparation de la vidéo depuis la chanson…");
        List<Uri> images = new ArrayList<>(imageUris);
        new Thread(() -> {
            try {
                Uri output = VideoComposer.compose(MainActivity.this, audioUri, images, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startTextRender() {
        String text = textPromptEdit == null || textPromptEdit.getText() == null ? "" : textPromptEdit.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "Écrivez d'abord un texte ou une histoire.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.textPrompt = text;
        if (textMusicStyleSpinner != null) options.textSongMood = String.valueOf(textMusicStyleSpinner.getSelectedItem());
        options.textVideoSeconds = readTextSeconds();
        String estimate = estimateTextProductionTime(options, textAudioUri != null || generatedTextAudioUri != null);
        Toast.makeText(this, estimate, Toast.LENGTH_LONG).show();
        setBusy(true, "Maquette Texte → Musique → Vidéo en cours…\n" + estimate + "\nPistes prévues : " + currentProductionSummary());
        Uri startingAudio = textAudioUri != null ? textAudioUri : generatedTextAudioUri;
        List<Uri> textImages = new ArrayList<>(textImageUris);
        new Thread(() -> {
            try {
                Uri audioForTextVideo = startingAudio;
                if (audioForTextVideo == null) {
                    UiProgress p = new UiProgress();
                    p.onStep("Création automatique de la maquette audio locale…\n" + currentProductionSummary());
                    Uri autoAudio = TextSongComposer.compose(MainActivity.this, text, options, p);
                    generatedTextAudioUri = autoAudio;
                    audioForTextVideo = autoAudio;
                }
                Uri output = ImageVideoComposer.composeTextToVideo(MainActivity.this, text, audioForTextVideo, options, new UiProgress(), textImages);
                runOnUiThread(() -> {
                    updateTextSelectionText();
                    finishJob(output, "Vidéo texte + musique créée dans Galerie > Movies > Music2VideoFree.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startVideoCorrection() {
        if (videoToCorrectUri == null) {
            Toast.makeText(this, "Choisissez d'abord une vidéo à corriger.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (useReplacementAudioCheck != null && useReplacementAudioCheck.isChecked() && correctionAudioUri == null) {
            Toast.makeText(this, "Choisissez une nouvelle musique ou décochez le remplacement audio.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.correctionPreset = correctionSpinner == null ? "Préserver original — copie non destructive" : String.valueOf(correctionSpinner.getSelectedItem());
        options.replacementMode = replacementModeSpinner == null ? "Garder la vidéo originale" : String.valueOf(replacementModeSpinner.getSelectedItem());
        options.replacementMotion = replacementMotionSpinner == null ? "Garder motion similaire" : String.valueOf(replacementMotionSpinner.getSelectedItem());
        Uri audioForCorrection = useReplacementAudioCheck != null && useReplacementAudioCheck.isChecked() ? correctionAudioUri : null;
        List<Uri> replacements = new ArrayList<>(replacementImageUris);

        setBusy(true, "Préparation de l’export MP4 corrigé…");
        new Thread(() -> {
            try {
                Uri output = VideoCorrector.correct(MainActivity.this, videoToCorrectUri, audioForCorrection, replacements, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Export MP4 corrigé créé dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private ProjectOptions readOptions() {
        ProjectOptions o = new ProjectOptions();
        o.format = formatSpinner == null ? "YouTube 16:9" : String.valueOf(formatSpinner.getSelectedItem());
        o.exportQuality = exportQualitySpinner == null ? "Qualité source / auto" : String.valueOf(exportQualitySpinner.getSelectedItem());
        o.style = styleSpinner == null ? "Cinématique sombre" : String.valueOf(styleSpinner.getSelectedItem());
        o.motion = motionSpinner == null ? "Ken Burns" : String.valueOf(motionSpinner.getSelectedItem());
        o.visualizer = visualizerSpinner == null ? "Minimal" : String.valueOf(visualizerSpinner.getSelectedItem());
        if (textMusicStyleSpinner != null) o.textSongMood = String.valueOf(textMusicStyleSpinner.getSelectedItem());
        if (textKeySpinner != null) o.textSongKey = String.valueOf(textKeySpinner.getSelectedItem());
        if (textVoiceTypeSpinner != null) o.textVoiceType = String.valueOf(textVoiceTypeSpinner.getSelectedItem());
        if (textMasteringSpinner != null) o.masterPreset = String.valueOf(textMasteringSpinner.getSelectedItem());
        o.instrumentFolkGuitar = instFolkGuitarCheck == null || instFolkGuitarCheck.isChecked();
        o.instrumentClassicGuitar = instClassicGuitarCheck != null && instClassicGuitarCheck.isChecked();
        o.instrumentElectricGuitar = instElectricGuitarCheck != null && instElectricGuitarCheck.isChecked();
        o.instrumentPiano = instPianoCheck == null || instPianoCheck.isChecked();
        o.instrumentBass = instBassCheck == null || instBassCheck.isChecked();
        o.instrumentDrums = instDrumsCheck == null || instDrumsCheck.isChecked();
        o.instrumentPercussion = instPercussionCheck == null || instPercussionCheck.isChecked();
        o.instrumentStrings = instStringsCheck != null && instStringsCheck.isChecked();
        o.lockSourceQuality = lockSourceQualityCheck != null && lockSourceQualityCheck.isChecked();
        o.lockSourceMotion = lockSourceMotionCheck != null && lockSourceMotionCheck.isChecked();
        o.noCropZoom = noCropZoomCheck != null && noCropZoomCheck.isChecked();
        o.preserveOriginalAmbience = preserveOriginalAmbienceCheck == null || preserveOriginalAmbienceCheck.isChecked();
        o.preserveOriginalDuration = preserveOriginalDurationCheck == null || preserveOriginalDurationCheck.isChecked();
        o.fusionMode = fusionModeSpinner == null ? "Incrustation picture-in-picture" : String.valueOf(fusionModeSpinner.getSelectedItem());
        o.fusionPosition = fusionPositionSpinner == null ? "Bas droite" : String.valueOf(fusionPositionSpinner.getSelectedItem());
        o.fusionChromaKey = fusionChromaKeyCheck != null && fusionChromaKeyCheck.isChecked();
        o.fusionFeather = fusionFeatherCheck == null || fusionFeatherCheck.isChecked();
        o.fusionSyncAudio = fusionSyncAudioCheck != null && fusionSyncAudioCheck.isChecked();
        o.fusionStartTimeUs = parseTimecodeUs(fusionStartTimeEdit == null ? "00:00:00.000" : fusionStartTimeEdit.getText().toString());
        o.fusionDurationUs = parseSecondsToUs(fusionDurationEdit == null ? "20" : fusionDurationEdit.getText().toString());
        o.replacementStartTimeUs = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        o.replacementSegmentDurationUs = parseSecondsToUs(replacementPlanSecondsEdit == null ? "4.5" : replacementPlanSecondsEdit.getText().toString());
        if (o.preserveOriginalDuration && videoToCorrectUri != null && !replacementImageUris.isEmpty()) {
            long sourceDuration = MediaMuxerTools.getDurationUs(this, videoToCorrectUri);
            long remaining = Math.max(500_000L, sourceDuration - o.replacementStartTimeUs);
            if (sourceDuration > 0) o.replacementSegmentDurationUs = Math.max(500_000L, remaining / Math.max(1, replacementImageUris.size()));
        }
        o.simpleLipSync = false; // ancien avatar/smiley retiré : le lip-sync avancé reste un module séparé.
        o.testMode = testModeCheck != null && testModeCheck.isChecked();
        o.usePcLocalEngine = pcEngineAddressEdit != null && pcEngineAddressEdit.getText() != null && pcEngineAddressEdit.getText().toString().trim().length() > 0;
        o.pcEngineAddress = pcEngineAddressEdit == null || pcEngineAddressEdit.getText() == null ? "" : pcEngineAddressEdit.getText().toString().trim();

        applyExportQuality(o);
        return o;
    }

    private void applyExportQuality(ProjectOptions o) {
        String q = o.exportQuality == null ? "" : o.exportQuality;
        boolean square = o.format != null && o.format.contains("1:1");
        boolean vertical = o.format != null && o.format.contains("9:16");

        int longSide = 1280;
        int shortSide = 720;
        int bitrate = 4_500_000;
        if (q.contains("1080")) { longSide = 1920; shortSide = 1080; bitrate = 9_000_000; }
        if (q.contains("4K")) { longSide = 3840; shortSide = 2160; bitrate = 35_000_000; }

        Uri sourceForQuality = videoToCorrectUri != null ? videoToCorrectUri : fusionMainVideoUri;
        if ((q.contains("source") || q.contains("Source")) && sourceForQuality != null && o.lockSourceQuality) {
            int[] size = MediaMuxerTools.getVideoSize(this, sourceForQuality);
            if (size[0] > 0 && size[1] > 0) {
                o.width = size[0];
                o.height = size[1];
                o.bitrate = Math.max(6_000_000, Math.min(40_000_000, size[0] * size[1] * 4));
                return;
            }
        }

        if (square) {
            o.width = shortSide;
            o.height = shortSide;
        } else if (vertical) {
            o.width = shortSide;
            o.height = longSide;
        } else {
            o.width = longSide;
            o.height = shortSide;
        }
        o.bitrate = bitrate;
    }

    private int readTextSeconds() {
        String v = textDurationSpinner == null ? "30 secondes" : String.valueOf(textDurationSpinner.getSelectedItem());
        if (v.startsWith("15")) return 15;
        if (v.startsWith("60")) return 60;
        if (v.startsWith("90")) return 90;
        if (v.startsWith("2")) return 120;
        if (v.startsWith("3")) return 180;
        if (v.startsWith("4")) return 240;
        return 30;
    }

    private long parseTimecodeUs(String raw) {
        if (raw == null) return 0L;
        String s = raw.trim().replace(',', '.');
        if (s.isEmpty()) return 0L;
        try {
            String[] parts = s.split(":");
            double seconds;
            if (parts.length == 3) {
                seconds = Integer.parseInt(parts[0].trim()) * 3600.0 + Integer.parseInt(parts[1].trim()) * 60.0 + Double.parseDouble(parts[2].trim());
            } else if (parts.length == 2) {
                seconds = Integer.parseInt(parts[0].trim()) * 60.0 + Double.parseDouble(parts[1].trim());
            } else {
                seconds = Double.parseDouble(s);
            }
            return Math.max(0L, (long) (seconds * 1_000_000L));
        } catch (Exception e) {
            return 0L;
        }
    }

    private long parseSecondsToUs(String raw) {
        if (raw == null) return 4_500_000L;
        String s = raw.trim().replace(',', '.').replace("secondes", "").replace("seconde", "").replace("s", "").trim();
        try { return Math.max(500_000L, (long) (Double.parseDouble(s) * 1_000_000L)); }
        catch (Exception e) { return 4_500_000L; }
    }

    private String formatTimecode(long us) {
        long ms = Math.max(0L, us / 1000L);
        long h = ms / 3_600_000L;
        ms %= 3_600_000L;
        long m = ms / 60_000L;
        ms %= 60_000L;
        long sec = ms / 1000L;
        long milli = ms % 1000L;
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, sec, milli);
    }

    private void updateTimelineText() {
        if (timelineText == null) return;
        StringBuilder sb = new StringBuilder();
        long videoDuration = MediaMuxerTools.getDurationUs(this, videoToCorrectUri);
        sb.append("Piste 1 — vidéo source : ").append(describeMedia(videoToCorrectUri)).append("\n");
        if (videoDuration > 0) {
            sb.append("Timecode source : 00:00:00.000 → ").append(formatTimecode(videoDuration)).append("\n");
            sb.append("Repères rapides : ").append(buildRuler(videoDuration)).append("\n");
        } else {
            sb.append("Importez une vidéo : les timecodes apparaîtront automatiquement ici.\n");
        }
        sb.append("Verrous : qualité source ").append(lockSourceQualityCheck != null && lockSourceQualityCheck.isChecked() ? "ON" : "OFF")
                .append(" • motion source ").append(lockSourceMotionCheck != null && lockSourceMotionCheck.isChecked() ? "ON" : "OFF")
                .append(" • recadrage/zoom ").append(noCropZoomCheck != null && noCropZoomCheck.isChecked() ? "bloqué" : "autorisé").append("\n\n");
        long start = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        long seg = parseSecondsToUs(replacementPlanSecondsEdit == null ? "4.5" : replacementPlanSecondsEdit.getText().toString());
        if (preserveOriginalDurationCheck != null && preserveOriginalDurationCheck.isChecked() && videoDuration > 0 && !replacementImageUris.isEmpty()) {
            long remaining = Math.max(500_000L, videoDuration - start);
            seg = Math.max(500_000L, remaining / Math.max(1, replacementImageUris.size()));
            sb.append("Durée originale préservée : chaque image occupe automatiquement sa portion restante.\n");
        }
        if (replacementImageUris.isEmpty()) {
            sb.append("Piste 2 — images : aucune image de remplacement.\n");
            sb.append("Après import, chaque photo aura un timecode d'entrée/sortie pour éviter les erreurs de placement.");
        } else {
            sb.append("Piste 2 — images de remplacement timecodées :\n");
            for (int i = 0; i < replacementImageUris.size(); i++) {
                long in = start + i * seg;
                long out = in + seg;
                sb.append(String.format(Locale.US, "Plan %02d • %s → %s • %s", i + 1, formatTimecode(in), formatTimecode(out), nameOf(replacementImageUris.get(i)))).append("\n");
            }
        }
        timelineText.setText(sb.toString());
    }

    private void fillAutomaticSongPrompt() {
        String style = styleSpinner == null ? "Cinématique sombre" : String.valueOf(styleSpinner.getSelectedItem());
        String format = formatSpinner == null ? "YouTube 16:9" : String.valueOf(formatSpinner.getSelectedItem());
        String motion = motionSpinner == null ? "Conserver motion source" : String.valueOf(motionSpinner.getSelectedItem());
        String prompt = "Créer un clip vidéo cinématographique cohérent avec la chanson. " +
                "Style visuel : " + style + ". Format : " + format + ". Motion : " + motion + ". " +
                "Construire une histoire en plusieurs scènes, sans texte incrusté à l'écran. " +
                "Garder une continuité de personnages, de lieux, de lumière et d'émotion. " +
                "Respecter la durée complète de la musique. Utiliser les images importées comme références visuelles si elles existent. " +
                "Ne jamais générer d'avatar/smiley. Utiliser uniquement des images, vidéos ou ressources cohérentes. Le lip-sync avancé réel reste réservé au module dédié. Rendu final : MP4 propre, fluide, avec ambiance cinématographique.";
        if (songStoryEdit != null) songStoryEdit.setText(prompt);
        if (autoPromptText != null) autoPromptText.setText("Prompt auto généré :\n" + prompt);
        Toast.makeText(this, "Prompt automatique ajouté. Vous pouvez le modifier avant export.", Toast.LENGTH_LONG).show();
    }

    private void showPromptHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Prompt automatique musique → vidéo")
                .setMessage("Le prompt automatique sert de base de storyboard. Il décrit le style, le format, la motion et les règles de continuité. Vous pouvez ensuite ajouter vos détails : lieu, époque, personnage, émotion, couleurs, scènes interdites ou obligatoires. Pour une chanson complète, gardez le mode test 20 secondes désactivé.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showSelectedMotionHelpDialog() {
        String selected = motionSpinner == null ? "Conserver motion source" : String.valueOf(motionSpinner.getSelectedItem());
        String advice;
        if (selected.contains("source")) {
            advice = "Recommandé pour une vidéo déjà créée : ne modifie pas la motion, ne rajoute pas de zoom, protège la stabilité.";
        } else if (selected.contains("Ken")) {
            advice = "Bon pour transformer des photos en vidéo. Moins adapté si vous voulez préserver une vidéo source intacte.";
        } else if (selected.contains("Slide")) {
            advice = "Effet dynamique pour montage depuis texte ou images. À utiliser si vous voulez un mouvement visible.";
        } else if (selected.contains("Pulse")) {
            advice = "Effet lié au son. Adapté aux clips musicaux ou visualiseurs, pas aux corrections réalistes.";
        } else if (selected.contains("Rotation")) {
            advice = "Effet doux et cinématique pour images fixes. Peut donner du style, mais change la sensation originale.";
        } else if (selected.contains("Shake")) {
            advice = "Effet dramatique. À éviter si la priorité est la qualité, la stabilité et le réalisme.";
        } else {
            advice = "Sans mouvement artificiel : adapté aux remplacements précis au timecode.";
        }
        new AlertDialog.Builder(this)
                .setTitle("Motion : " + selected)
                .setMessage(advice + "\n\nRègle simple : pour remplacer des images dans une vidéo existante sans altérer la motion, choisissez toujours “Conserver motion source” ou “Image fixe timecodée”.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void adjustReplacementStart(double deltaSeconds) {
        long current = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        long delta = (long) (deltaSeconds * 1_000_000L);
        long next = Math.max(0L, current + delta);
        if (replacementStartTimeEdit != null) replacementStartTimeEdit.setText(formatTimecode(next));
        updateTimelineText();
    }

    private void seekSourcePreviewToReplacementStart() {
        if (sourceVideoPreview == null || videoToCorrectUri == null) {
            Toast.makeText(this, "Importez d'abord une vidéo source.", Toast.LENGTH_SHORT).show();
            return;
        }
        long startUs = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        try {
            sourceVideoPreview.seekTo((int) Math.max(0L, startUs / 1000L));
            Toast.makeText(this, "Aperçu placé au timecode " + formatTimecode(startUs), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Impossible de déplacer l'aperçu.", Toast.LENGTH_SHORT).show();
        }
    }

    private void validateSafePlacement() {
        long start = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        long seg = parseSecondsToUs(replacementPlanSecondsEdit == null ? "4.5" : replacementPlanSecondsEdit.getText().toString());
        long duration = MediaMuxerTools.getDurationUs(this, videoToCorrectUri);
        boolean locksOk = (lockSourceQualityCheck == null || lockSourceQualityCheck.isChecked())
                && (lockSourceMotionCheck == null || lockSourceMotionCheck.isChecked())
                && (noCropZoomCheck == null || noCropZoomCheck.isChecked());
        StringBuilder msg = new StringBuilder();
        msg.append("Début remplacement : ").append(formatTimecode(start)).append("\n");
        msg.append("Durée par image : ").append(String.format(Locale.US, "%.2f s", seg / 1_000_000.0)).append("\n");
        msg.append("Images sélectionnées : ").append(replacementImageUris.size()).append("\n");
        if (duration > 0) msg.append("Durée vidéo source : ").append(formatTimecode(duration)).append("\n");
        msg.append("Verrous sécurité : ").append(locksOk ? "OK" : "attention, un verrou est désactivé").append("\n\n");
        msg.append("Conseil : pour ne pas altérer la vidéo, gardez qualité source, motion source et recadrage/zoom bloqué.");
        new AlertDialog.Builder(this)
                .setTitle("Validation timecode")
                .setMessage(msg.toString())
                .setPositiveButton("Compris", null)
                .show();
    }

    private String buildRuler(long durationUs) {
        if (durationUs <= 0) return "aucune durée détectée";
        StringBuilder r = new StringBuilder();
        for (int i = 0; i <= 4; i++) {
            long t = durationUs * i / 4L;
            if (i > 0) r.append(" | ");
            r.append(formatTimecode(t));
        }
        return r.toString();
    }

    private void showTimecodeHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Aide timecode")
                .setMessage("Le timecode permet de placer une photo à l'endroit exact dans la vidéo. Format conseillé : HH:MM:SS.mmm. Exemple : 00:01:12.500 commence à 1 minute 12 secondes et 500 ms. La durée de chaque photo détermine son point de sortie. Chaque image importée est listée avec entrée et sortie pour éviter les erreurs.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showMotionHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Motions expliquées")
                .setMessage("Conserver motion source : recommandé pour corriger une vidéo déjà créée. La vidéo garde son mouvement, son cadrage et sa stabilité.\n\nImage fixe timecodée : remplace une séquence par une photo sans zoom. Idéal si vous devez respecter précisément un moment.\n\nGarder motion similaire : applique un mouvement doux aux images remplacées sans changer la vidéo source.\n\nKen Burns : zoom/panoramique lent, utile pour photos seules, moins conseillé si vous voulez préserver une vidéo existante.\n\nSlide dynamique : déplacement latéral visible, utile pour une création depuis texte.\n\nPulse audio : mouvement lié au son, utile pour clip musical abstrait.\n\nRotation douce : effet cinématique léger.\n\nShake dramatique : tremblement volontaire, à éviter pour une correction réaliste ou familiale.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showQualityHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Qualité d'export")
                .setMessage("Qualité source : garde les dimensions de la vidéo importée et peut faire une copie non destructive. Recommandé pour ne pas abîmer l’original.\n\n720p HD : export réel en 1280x720.\n\n1080p Full HD : export réel en 1920x1080.\n\n4K UHD : export réel en 3840x2160 si le téléphone le supporte. C’est plus lourd et plus lent.\n\nImportant : si la vidéo source est en 720p/1080p, le 4K est un upscale local, pas une amélioration IA magique. Les API gratuites servent à trouver des médias libres, pas à transformer la qualité.")
                .setPositiveButton("Compris", null)
                .show();
    }


    private void showExportApiHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("V4.2 complète — Export 4K réel + API gratuites")
                .setMessage("Le choix 4K force un nouvel export MP4 local en 3840x2160 quand le téléphone le permet. Après l’export, utilisez le bouton Partager / télécharger pour récupérer le fichier final.\n\nLes API gratuites comme Pexels, Pixabay, Jamendo et Freesound servent à chercher des images, vidéos, musiques et ambiances libres de droits pour construire le projet. Elles ne font pas l’upscale 4K.\n\nRègle recommandée :\n• correction simple : Qualité source ;\n• export final YouTube : 1080p ou 4K ;\n• téléphone ancien : 720p/1080p ;\n• conserver l’original : garder les verrous qualité, motion, ambiance et durée activés.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void setBusy(boolean busy, String message) {
        if (busy && message != null) {
            message = message + "\nTemps estimé : 30 secondes à 4 minutes selon durée/qualité. Pour 4K ou vidéo longue, utilisez de préférence le moteur PC Linux local.";
        }
        if (songGenerateButton != null) songGenerateButton.setEnabled(!busy);
        if (textGenerateButton != null) textGenerateButton.setEnabled(!busy);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(!busy);
        if (fusionGenerateButton != null) fusionGenerateButton.setEnabled(!busy);
        if (openButton != null) openButton.setEnabled(!busy);
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        if (progressBar != null) progressBar.setProgress(0);
        if (statusText != null) statusText.setText(message);
        if (outputBox != null) outputBox.setVisibility(View.GONE);
    }

    private void finishJob(Uri output, String message) {
        lastOutputUri = output;
        saveLastOutputUri(output);
        statusText.setText(message);
        progressBar.setProgress(100);
        if (songGenerateButton != null) songGenerateButton.setEnabled(true);
        if (textGenerateButton != null) textGenerateButton.setEnabled(true);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
        if (fusionGenerateButton != null) fusionGenerateButton.setEnabled(true);
        if (openButton != null) openButton.setEnabled(true);
        if (outputBox != null) outputBox.setVisibility(View.VISIBLE);
        if (outputText != null) outputText.setText(message + "\nFichier exporté : " + describeMedia(output) + "\n" + exportLocationHint());
        if (outputVideoPreview != null && output != null) prepareVideoPreview(outputVideoPreview, output, false);
    }

    private void failJob(Exception e) {
        String msg = e == null || e.getMessage() == null ? "erreur inconnue" : e.getMessage();
        statusText.setText("Erreur : " + msg);
        if (songGenerateButton != null) songGenerateButton.setEnabled(true);
        if (textGenerateButton != null) textGenerateButton.setEnabled(true);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
        if (fusionGenerateButton != null) fusionGenerateButton.setEnabled(true);
        progressBar.setVisibility(View.GONE);
        new AlertDialog.Builder(this)
                .setTitle("Erreur de rendu")
                .setMessage(msg)
                .setPositiveButton("Compris", null)
                .show();
    }

    private void shareLastVideo() {
        if (lastOutputUri == null) {
            Toast.makeText(this, "Aucun export disponible.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("video/mp4");
        intent.putExtra(Intent.EXTRA_STREAM, lastOutputUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(intent, "Partager / télécharger le MP4 exporté"));
        } catch (Exception e) {
            Toast.makeText(this, "Impossible d'ouvrir le partage.", Toast.LENGTH_SHORT).show();
        }
    }

    private String exportLocationHint() {
        return "Emplacement : Galerie > Movies > Music2VideoFree. Le bouton Partager permet de l'envoyer ou le sauvegarder ailleurs.";
    }

    private void openLastVideo() {
        if (lastOutputUri == null) loadLastOutputUri();
        if (lastOutputUri == null) {
            Toast.makeText(this, "Aucun dernier export mémorisé. Ouvrez Galerie > Movies > Music2VideoFree.", Toast.LENGTH_LONG).show();
            return;
        }
        openUri(lastOutputUri, "video/mp4");
    }

    private void saveLastOutputUri(Uri uri) {
        if (uri == null) return;
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putString(PREF_LAST_OUTPUT, uri.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void loadLastOutputUri() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String raw = prefs.getString(PREF_LAST_OUTPUT, null);
            if (raw != null && raw.trim().length() > 0) lastOutputUri = Uri.parse(raw);
        } catch (Exception ignored) {}
    }

    private void openUri(Uri uri, String mimeType) {
        if (uri == null) {
            Toast.makeText(this, "Aucun fichier sélectionné.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, mimeType);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(intent); } catch (Exception e) { Toast.makeText(this, "Aucune application compatible trouvée.", Toast.LENGTH_SHORT).show(); }
    }

    private void prepareVideoPreview(VideoView view, Uri uri, boolean autoplay) {
        if (view == null || uri == null) return;
        view.setVisibility(View.VISIBLE);
        MediaController controller = new MediaController(this);
        controller.setAnchorView(view);
        view.setMediaController(controller);
        view.setVideoURI(uri);
        view.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            try { view.seekTo(autoplay ? 0 : 250); } catch (Exception ignored) {}
            if (autoplay) view.start();
        });
    }

    private String describeMedia(Uri uri) {
        if (uri == null) return "aucun fichier";
        long durationUs = MediaMuxerTools.getDurationUs(this, uri);
        String duration = durationUs > 0 ? " • durée " + formatDuration(durationUs) : "";
        int[] size = MediaMuxerTools.getVideoSize(this, uri);
        String dimensions = size[0] > 0 && size[1] > 0 ? " • " + size[0] + "x" + size[1] : "";
        return nameOf(uri) + duration + dimensions;
    }

    private String nameOf(Uri uri) {
        if (uri == null) return "";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.trim().length() > 0) return name;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "fichier sélectionné" : last;
    }

    private String formatDuration(long durationUs) {
        long total = Math.max(0L, durationUs / 1_000_000L);
        long minutes = total / 60L;
        long seconds = total % 60L;
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private void focusAndShowKeyboard(EditText editText) {
        if (editText == null) return;
        editText.requestFocus();
        editText.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
        }, 120);
    }

    private void playPauseAudio(Uri uri) {
        if (uri == null) {
            Toast.makeText(this, "Aucun audio sélectionné.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (audioPlayer != null && uri.equals(audioPlayerUri)) {
                if (audioPlayer.isPlaying()) {
                    audioPlayer.pause();
                    if (statusText != null) statusText.setText("Audio en pause.");
                } else {
                    audioPlayer.start();
                    if (statusText != null) statusText.setText("Lecture audio intégrée…");
                }
                return;
            }
            stopAudioPlayer();
            audioPlayer = new MediaPlayer();
            audioPlayerUri = uri;
            audioPlayer.setDataSource(this, uri);
            audioPlayer.setOnPreparedListener(mp -> {
                mp.start();
                if (statusText != null) statusText.setText("Lecture audio intégrée…");
            });
            audioPlayer.setOnCompletionListener(mp -> {
                if (statusText != null) statusText.setText("Lecture audio terminée.");
            });
            audioPlayer.prepareAsync();
            if (statusText != null) statusText.setText("Préparation du lecteur audio intégré…");
        } catch (Exception e) {
            Toast.makeText(this, "Lecture audio impossible dans l'application.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopAudioPlayer() {
        if (audioPlayer != null) {
            try { audioPlayer.stop(); } catch (Exception ignored) {}
            try { audioPlayer.release(); } catch (Exception ignored) {}
            audioPlayer = null;
            audioPlayerUri = null;
        }
    }

    @Override
    protected void onDestroy() {
        stopAudioPlayer();
        super.onDestroy();
    }

    private void refreshImageStrip(LinearLayout container, ArrayList<Uri> uris, String title) {
        if (container == null) return;
        container.removeAllViews();
        if (uris == null || uris.isEmpty()) return;
        TextView t = label(title + " — " + uris.size() + " fichier(s)");
        container.addView(t);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(row);
        int max = Math.min(uris.size(), 12);
        for (int i = 0; i < max; i++) {
            Uri uri = uris.get(i);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(4), dp(4), dp(4), dp(4));
            item.setBackground(roundedBg(Color.rgb(36, 38, 48), 1, Color.rgb(68, 70, 82), 12));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(118), LinearLayout.LayoutParams.WRAP_CONTENT);
            ip.setMargins(dp(4), dp(4), dp(4), dp(4));
            item.setLayoutParams(ip);
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setImageURI(uri);
            item.addView(img, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(82)));
            TextView name = smallText(String.format(Locale.US, "%02d • %s", i + 1, shortName(nameOf(uri), 14)));
            name.setGravity(Gravity.CENTER);
            item.addView(name);
            row.addView(item);
        }
        container.addView(scroll);
    }

    private void populateVideoFrameStrip(LinearLayout container, Uri videoUri, boolean updateReplacementTime) {
        if (container == null) return;
        container.removeAllViews();
        if (videoUri == null) {
            container.addView(fileCard("Vignettes timecode", smallText("Importez une vidéo : les vignettes timecodées apparaîtront ici.")));
            return;
        }
        long durationUs = MediaMuxerTools.getDurationUs(this, videoUri);
        LinearLayout card = fileCard("Vignettes timecode de la vidéo", smallText(durationUs > 0 ? "Touchez une vignette pour placer le timecode." : "Durée non détectée : aperçu limité."));
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(row);
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, videoUri);
            int count = durationUs > 0 ? 8 : 4;
            for (int i = 0; i < count; i++) {
                long tUs = durationUs > 0 ? (durationUs * i / Math.max(1, count - 1)) : i * 2_000_000L;
                Bitmap frame = null;
                Bitmap thumb = null;
                try {
                    frame = retriever.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (frame != null) thumb = Bitmap.createScaledBitmap(frame, dp(110), dp(72), true);
                } catch (Exception ignored) {}
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setPadding(dp(4), dp(4), dp(4), dp(4));
                item.setBackground(roundedBg(Color.rgb(36, 38, 48), 1, Color.rgb(216, 180, 93), 12));
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(122), LinearLayout.LayoutParams.WRAP_CONTENT);
                ip.setMargins(dp(4), dp(4), dp(4), dp(4));
                item.setLayoutParams(ip);
                ImageView img = new ImageView(this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                if (thumb != null) img.setImageBitmap(thumb);
                else img.setBackgroundColor(Color.rgb(20, 20, 24));
                item.addView(img, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));
                TextView tc = smallText(formatTimecode(tUs));
                tc.setGravity(Gravity.CENTER);
                item.addView(tc);
                final long selectedUs = tUs;
                item.setOnClickListener(v -> {
                    if (updateReplacementTime && replacementStartTimeEdit != null) {
                        replacementStartTimeEdit.setText(formatTimecode(selectedUs));
                        updateTimelineText();
                    }
                    if (!updateReplacementTime && fusionStartTimeEdit != null) {
                        fusionStartTimeEdit.setText(formatTimecode(selectedUs));
                    }
                    if (updateReplacementTime && sourceVideoPreview != null) sourceVideoPreview.seekTo((int) (selectedUs / 1000L));
                    if (!updateReplacementTime && fusionMainPreview != null) fusionMainPreview.seekTo((int) (selectedUs / 1000L));
                });
                row.addView(item);
                if (frame != null && !frame.isRecycled()) frame.recycle();
            }
        } catch (Exception e) {
            row.addView(smallText("Vignettes indisponibles pour cette vidéo."));
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
        card.addView(scroll);
        container.addView(card);
    }

    private String shortName(String name, int max) {
        if (name == null) return "fichier";
        return name.length() <= max ? name : name.substring(0, Math.max(1, max - 1)) + "…";
    }

    private void addExpandableInfoButton(LinearLayout parent, String title, String message) {
        Button b = secondaryButton("Voir plus — " + title);
        b.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Compris", null)
                .show());
        parent.addView(b);
    }

    private void addFreeResourceButtons(LinearLayout parent, EditText promptSource) {
        LinearLayout box = card();
        box.addView(label("Ressources gratuites libres de droits"));
        box.addView(smallText("Dépliez seulement si vous avez besoin d'images, vidéos, musiques ou ambiances libres. Les recherches s'ouvrent dans le navigateur."));
        Button explain = secondaryButton("Voir plus — Pexels / Pixabay / Jamendo / Freesound");
        explain.setOnClickListener(v -> showFreeResourceDialog());
        box.addView(explain);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button searchVisuals = compactButton("Images/Vidéos");
        searchVisuals.setOnClickListener(v -> openFreeMediaSearch(promptSource, true));
        Button searchMusic = compactButton("Musiques/Sons");
        searchMusic.setOnClickListener(v -> showAudioSourcesDialog(promptSource));
        row.addView(searchVisuals);
        row.addView(searchMusic);
        box.addView(row);
        parent.addView(box);
    }

    private void showLocalLoopChoiceDialog() {
        String msg = "Choisissez l'action :\n\n" +
                "• Maquette locale : génère une maquette selon votre style, tonalité, type de voix et instruments cochés.\n" +
                "• Chercher des sons libres : ouvre Jamendo/Freesound avec une recherche enrichie par votre style et vos instruments.\n\n" +
                "La voix réaliste chantée, l'auto-tune précis et le remplacement par votre voix sont prévus pour le moteur PC Linux local.";
        new AlertDialog.Builder(this)
                .setTitle("Maquette locale / sons libres")
                .setMessage(msg)
                .setPositiveButton("Créer production locale", (d, w) -> generateLocalInstrumentalLoop())
                .setNegativeButton("Chercher sons libres", (d, w) -> showAudioSourcesDialog(textPromptEdit))
                .setNeutralButton("Fermer", null)
                .show();
    }

    private void showAudioSourcesDialog(EditText promptSource) {
        String q = promptSource == null || promptSource.getText() == null ? "instrumental" : promptSource.getText().toString().trim();
        String style = textMusicStyleSpinner == null ? "instrumental cinematic" : String.valueOf(textMusicStyleSpinner.getSelectedItem());
        String instruments = selectedInstrumentsSummary();
        if (q.length() == 0) q = style;
        q = q + " " + style + " " + instruments;
        if (q.length() > 110) q = q.substring(0, 110);
        final String query = q;
        new AlertDialog.Builder(this)
                .setTitle("Musiques / sons libres")
                .setMessage("Choisissez une source gratuite/libre. Vérifiez toujours la licence et les crédits demandés avant publication.\n\n" +
                        "Jamendo : musiques/instrumentales complètes.\n" +
                        "Freesound : bruitages, ambiances, loops courtes.\n\n" +
                        "Aucune API payante n'est lancée.")
                .setPositiveButton("Jamendo", (d, w) -> openUrl("https://www.jamendo.com/search?qs=q=" + Uri.encode(query)))
                .setNegativeButton("Freesound", (d, w) -> openUrl("https://freesound.org/search/?q=" + Uri.encode(query)))
                .setNeutralButton("Annuler", null)
                .show();
    }

    private void showProductionPlanDialog() {
        String mood = textMusicStyleSpinner == null ? "Pop cinématique" : String.valueOf(textMusicStyleSpinner.getSelectedItem());
        String key = textKeySpinner == null ? "Tonalité auto" : String.valueOf(textKeySpinner.getSelectedItem());
        String voice = textVoiceTypeSpinner == null ? "Voix guide homme synthétique" : String.valueOf(textVoiceTypeSpinner.getSelectedItem());
        String master = textMasteringSpinner == null ? "Streaming propre" : String.valueOf(textMasteringSpinner.getSelectedItem());
        String msg = "Plan de production automatique :\n\n" +
                "Style : " + mood + "\n" +
                "Tonalité : " + key + "\n" +
                "Voix : " + voice + "\n" +
                "Instruments : " + selectedInstrumentsSummary() + "\n" +
                "Mastering : " + master + "\n\n" +
                "Android local génère une maquette témoin avec tempo, tonalité, batterie, basse et instruments cochés. La voix Android est seulement un guide synthétique. Pour vraie voix chantée, choeurs réalistes, auto-tune, correction temporelle, stems séparés et mastering avancé, il faut le moteur PC Linux local. Aucune API payante n'est lancée.";
        new AlertDialog.Builder(this)
                .setTitle("Production chanson")
                .setMessage(msg)
                .setPositiveButton("Compris", null)
                .show();
    }


    private String selectedInstrumentsSummary() {
        ArrayList<String> names = new ArrayList<>();
        if (instFolkGuitarCheck == null || instFolkGuitarCheck.isChecked()) names.add("guitare folk");
        if (instClassicGuitarCheck != null && instClassicGuitarCheck.isChecked()) names.add("guitare classique");
        if (instElectricGuitarCheck != null && instElectricGuitarCheck.isChecked()) names.add("guitare électrique");
        if (instPianoCheck == null || instPianoCheck.isChecked()) names.add("piano");
        if (instBassCheck == null || instBassCheck.isChecked()) names.add("basse");
        if (instDrumsCheck == null || instDrumsCheck.isChecked()) names.add("batterie");
        if (instPercussionCheck == null || instPercussionCheck.isChecked()) names.add("percussions");
        if (instStringsCheck != null && instStringsCheck.isChecked()) names.add("strings");
        if (names.isEmpty()) return "instrumental minimal";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < names.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(names.get(i));
        }
        return sb.toString();
    }

    private String currentProductionSummary() {
        String voice = textVoiceTypeSpinner == null ? "Voix guide homme synthétique" : String.valueOf(textVoiceTypeSpinner.getSelectedItem());
        String key = textKeySpinner == null ? "Tonalité auto" : String.valueOf(textKeySpinner.getSelectedItem());
        String master = textMasteringSpinner == null ? "Streaming propre" : String.valueOf(textMasteringSpinner.getSelectedItem());
        return voice + " • " + key + " • " + selectedInstrumentsSummary() + " • mastering " + master;
    }

    private String estimateTextProductionTime(ProjectOptions options, boolean audioAlreadyReady) {
        int seconds = options == null ? readTextSeconds() : Math.max(readTextSeconds(), options.songSeconds);
        int base = audioAlreadyReady ? 25 : 35;
        int extra = Math.min(90, Math.max(10, seconds / 2));
        if (options != null && options.instrumentDrums) extra += 5;
        if (options != null && options.instrumentStrings) extra += 5;
        if (options != null && options.textVoiceType != null && !options.textVoiceType.contains("Instrumental")) extra += 8;
        return "Temps estimé : environ " + base + " à " + (base + extra) + " secondes sur téléphone récent. Si le téléphone est lent, utilisez le moteur PC Linux local.";
    }

    private CheckBox makeCheckBox(String text, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextColor(Color.rgb(244, 241, 232));
        c.setTextSize(13);
        c.setChecked(checked);
        c.setPadding(0, dp(2), 0, dp(2));
        c.setOnCheckedChangeListener((buttonView, isChecked) -> updateTextSelectionText());
        return c;
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Impossible d'ouvrir la page.", Toast.LENGTH_SHORT).show(); }
    }

    private void showCompleteChecklistDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Checklist V4.6 audio local + PC")
                .setMessage("Cette version regroupe les demandes prioritaires, sans redirection vers API payante :\n\n" +
                        "• interface compacte avec aides Voir plus / ? ;\n" +
                        "• suppression définitive de l'ancien smiley lip-sync ;\n" +
                        "• Texte → Vidéo avec clavier, paroles structurées et boucle instrumentale locale ;\n" +
                        "• lecteurs audio/vidéo intégrés ;\n" +
                        "• import multi-images avec miniatures ;\n" +
                        "• ressources libres gratuites : Pexels, Pixabay, Jamendo, Freesound ;\n" +
                        "• studio correction avec vidéo source, vignettes timecodées et clic sur image ;\n" +
                        "• remplacement sécurisé par timecode ;\n" +
                        "• verrous par défaut : qualité source, motion source, ambiance originale, durée originale, pas de zoom/recadrage ;\n" +
                        "• séparation copie non destructive / export MP4 réel ;\n" +
                        "• export source, 720p, 1080p ou 4K local selon capacité du téléphone ;\n" +
                        "• bouton partager / télécharger après export ;\n" +
                        "• module vidéo dans vidéo / fusion chanteur avec piste séparée, timecode, PiP, plein écran, fondu, superposition, écran partagé et chroma key simple ;\n" +
                        "• préparation PC Companion local pour upscale, motion IA, lip-sync open source, MusicGen/ComfyUI/RIFE/Real-ESRGAN.\n\n" +
                        "Important : aucune API payante/cloud n'est proposée. Les API gratuites fournissent des médias libres. L'export 4K est local Android ou futur PC local.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showFreeResourceDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Sources gratuites conseillées")
                .setMessage("Pexels et Pixabay : images/vidéos libres à chercher puis importer.\n\nJamendo : musiques complètes libres selon licence.\n\nFreesound : bruitages et ambiances, attention aux crédits/licences.\n\nV4.6 prépare l'accès à ces sources libres sans API payante. Les générations IA lourdes sont prévues via PC local/open source, pas via service cloud payant.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void openFreeMediaSearch(EditText promptSource, boolean visuals) {
        String q = promptSource == null || promptSource.getText() == null ? "cinematic video" : promptSource.getText().toString().trim();
        if (q.length() == 0) q = visuals ? "cinematic video" : "cinematic instrumental music";
        if (q.length() > 80) q = q.substring(0, 80);
        String url = visuals
                ? "https://www.pexels.com/search/videos/" + Uri.encode(q) + "/"
                : "https://www.jamendo.com/search?qs=q=" + Uri.encode(q);
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Impossible d'ouvrir la recherche.", Toast.LENGTH_SHORT).show(); }
    }

    private void generateStructuredLyricsFromPrompt() {
        String seed = textPromptEdit == null || textPromptEdit.getText() == null ? "" : textPromptEdit.getText().toString().trim();
        if (seed.length() == 0) seed = "espoir, courage et renaissance";
        String mood = textMusicStyleSpinner == null ? "Pop cinématique" : String.valueOf(textMusicStyleSpinner.getSelectedItem());
        String key = textKeySpinner == null ? "Tonalité auto" : String.valueOf(textKeySpinner.getSelectedItem());
        String voice = textVoiceTypeSpinner == null ? "Voix guide homme synthétique" : String.valueOf(textVoiceTypeSpinner.getSelectedItem());
        String lyrics = LyricsEngine.generateOriginalLyrics(seed, mood + " • " + key + " • " + voice);
        if (textPromptEdit != null) textPromptEdit.setText(lyrics);
        if (textSongStructureText != null) textSongStructureText.setText("Paroles cohérentes générées : intro/couplets/pré-refrain/refrain/pont/refrain final. Style : " + mood + " • Tonalité : " + key + " • Voix : " + voice + ".");
        Toast.makeText(this, "Paroles structurées générées.", Toast.LENGTH_LONG).show();
    }

    private void generateLocalInstrumentalLoop() {
        String text = textPromptEdit == null || textPromptEdit.getText() == null ? "" : textPromptEdit.getText().toString().trim();
        if (text.length() == 0) text = "instrumental cinématique";
        ProjectOptions options = readOptions();
        if (textMusicStyleSpinner != null) options.textSongMood = String.valueOf(textMusicStyleSpinner.getSelectedItem());
        if (textKeySpinner != null) options.textSongKey = String.valueOf(textKeySpinner.getSelectedItem());
        if (textVoiceTypeSpinner != null) options.textVoiceType = String.valueOf(textVoiceTypeSpinner.getSelectedItem());
        if (textMasteringSpinner != null) options.masterPreset = String.valueOf(textMasteringSpinner.getSelectedItem());
        options.songSeconds = Math.max(20, Math.min(75, readTextSeconds()));
        String estimate = estimateTextProductionTime(options, false);
        Toast.makeText(this, estimate, Toast.LENGTH_LONG).show();
        setBusy(true, "Génération de la maquette audio locale…\n" + estimate + "\nPistes prévues : " + currentProductionSummary());
        String finalText = text;
        new Thread(() -> {
            try {
                Uri output = TextSongComposer.compose(MainActivity.this, finalText, options, new UiProgress());
                runOnUiThread(() -> {
                    generatedTextAudioUri = output;
                    updateTextSelectionText();
                    if (statusText != null) statusText.setText("Maquette audio locale créée : " + currentProductionSummary() + ". Vous pouvez l'écouter ou l'utiliser pour Texte → Vidéo.");
                    if (progressBar != null) progressBar.setProgress(100);
                    if (songGenerateButton != null) songGenerateButton.setEnabled(true);
                    if (textGenerateButton != null) textGenerateButton.setEnabled(true);
                    if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
                    if (fusionGenerateButton != null) fusionGenerateButton.setEnabled(true);
                    if (openButton != null) openButton.setEnabled(true);
                    if (textSongStructureText != null) textSongStructureText.setText("Maquette locale générée et mixée : " + currentProductionSummary() + ". Elle sera utilisée automatiquement pour Texte → Vidéo si aucune autre musique n'est sélectionnée.");
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Maquette locale créée")
                            .setMessage("La maquette audio témoin est prête : " + currentProductionSummary() + ". Vous pouvez l'écouter avec Lire/Pause audio ou l'utiliser dans Texte → Vidéo. Pour une vraie voix chantée réaliste, votre propre voix, l'auto-tune et les pistes séparées, le moteur PC Linux local sera nécessaire.")
                            .setPositiveButton("Écouter", (d, w) -> playPauseAudio(generatedTextAudioUri))
                            .setNegativeButton("Fermer", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void updateFusionSelectionText() {
        if (fusionSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Vidéo principale : ").append(describeMedia(fusionMainVideoUri)).append("\n");
        sb.append("Vidéo chanteur : ").append(describeMedia(fusionSingerVideoUri)).append("\n");
        sb.append("Audio final : ").append(describeMedia(fusionAudioUri)).append("\n");
        sb.append("Règle : l'export crée une nouvelle vidéo fusionnée, sans remplacer les sources.");
        fusionSelectionText.setText(sb.toString());
        populateVideoFrameStrip(fusionFrameStripContainer, fusionMainVideoUri, false);
    }

    private void adjustFusionStart(double deltaSeconds) {
        long current = parseTimecodeUs(fusionStartTimeEdit == null ? "00:00:00.000" : fusionStartTimeEdit.getText().toString());
        long delta = (long) (deltaSeconds * 1_000_000L);
        long next = Math.max(0L, current + delta);
        if (fusionStartTimeEdit != null) fusionStartTimeEdit.setText(formatTimecode(next));
    }

    private void startFusionRender() {
        if (fusionMainVideoUri == null) {
            Toast.makeText(this, "Importez d'abord la vidéo principale.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (fusionSingerVideoUri == null) {
            Toast.makeText(this, "Importez la vidéo secondaire/chanteur.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        Uri audio = (fusionSyncAudioCheck != null && fusionSyncAudioCheck.isChecked() && fusionAudioUri != null) ? fusionAudioUri : null;
        setBusy(true, "Préparation de la fusion vidéo dans vidéo…");
        new Thread(() -> {
            try {
                Uri output = VideoFusionComposer.compose(MainActivity.this, fusionMainVideoUri, fusionSingerVideoUri, audio, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo fusionnée créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void showPcEngineHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Moteur PC local gratuit / open source")
                .setMessage("Le téléphone reste le studio mobile. Le PC devient le moteur de calcul pour les tâches lourdes : export 4K plus fiable, upscale IA, interpolation RIFE, lip-sync SadTalker/Wav2Lip, MusicGen/AudioCraft et ComfyUI.\n\n" +
                        "Aucun service cloud payant n'est lancé depuis l'application. Le futur compagnon PC devra tourner sur votre propre ordinateur, sur votre Wi-Fi local.\n\n" +
                        "Étapes prévues :\n" +
                        "1. installer Music2Video PC Companion ;\n" +
                        "2. lancer le moteur sur le PC ;\n" +
                        "3. saisir l'adresse locale dans l'application ;\n" +
                        "4. envoyer le projet au PC ;\n" +
                        "5. récupérer le MP4 final dans l'application.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showFusionHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Fusion propre chanteur + vidéo narrative")
                .setMessage("Pour une fusion plus propre, filmez la vidéo chanteur avec un fond uni ou vert, une lumière stable et un cadrage net.\n\nPicture-in-picture : le plus sûr.\nPlein écran temporaire : coupe narrative propre.\nFondu cinématographique : mélange doux.\nSuperposition : effet clip musical.\n\nLe détourage parfait nécessite un moteur PC local/open source ; la version Android garde une fusion locale simple, non destructive.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private LinearLayout premiumCard() {
        LinearLayout box = card();
        box.setBackground(roundedBg(Color.rgb(30, 32, 42), 2, Color.rgb(216, 180, 93), 18));
        return box;
    }

    private LinearLayout dashboardCard(String icon, String title, String desc, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        box.setGravity(Gravity.CENTER);
        box.setBackground(roundedBg(Color.rgb(38, 40, 52), 1, Color.rgb(62, 64, 76), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), dp(6), dp(4), dp(6));
        box.setLayoutParams(lp);
        TextView i = new TextView(this);
        i.setText(icon);
        i.setTextSize(24);
        i.setGravity(Gravity.CENTER);
        box.addView(i);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.rgb(244, 241, 232));
        t.setTextSize(16);
        t.setGravity(Gravity.CENTER);
        box.addView(t);
        TextView d = smallText(desc);
        d.setGravity(Gravity.CENTER);
        box.addView(d);
        box.setOnClickListener(listener);
        return box;
    }

    private GradientDrawable roundedBg(int color, int strokeDp, int strokeColor, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private LinearLayout fileCard(String title, TextView body) {
        LinearLayout box = card();
        TextView t = label(title);
        t.setPadding(0, 0, 0, dp(6));
        box.addView(t);
        box.addView(body);
        return box;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackground(roundedBg(Color.rgb(28, 30, 38), 1, Color.rgb(48, 50, 62), 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(244, 241, 232));
        v.setTextSize(20);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(18), 0, dp(8));
        return v;
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(216, 180, 93));
        v.setTextSize(14);
        v.setPadding(0, dp(12), 0, dp(4));
        return v;
    }

    private TextView smallText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(190, 188, 180));
        v.setTextSize(13);
        v.setLineSpacing(2, 1.08f);
        return v;
    }

    private EditText editText(String hint, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(Color.rgb(244, 241, 232));
        e.setHintTextColor(Color.rgb(150, 150, 145));
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setSingleLine(false);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setFocusable(true);
        e.setFocusableInTouchMode(true);
        e.setOnClickListener(v -> focusAndShowKeyboard(e));
        e.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) focusAndShowKeyboard(e);
            return false;
        });
        e.setBackgroundColor(Color.rgb(38, 40, 50));
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private Button primaryButton(String text) {
        Button b = baseButton(text);
        b.setTextColor(Color.rgb(20, 18, 14));
        b.setBackground(roundedBg(Color.rgb(216, 180, 93), 0, Color.TRANSPARENT, 14));
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = baseButton(text);
        b.setTextColor(Color.rgb(244, 241, 232));
        b.setBackground(roundedBg(Color.rgb(38, 40, 50), 1, Color.rgb(55, 57, 68), 14));
        return b;
    }

    private Button compactButton(String text) {
        Button b = secondaryButton(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), dp(6), dp(3), dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private Button tabButton(String text) {
        Button b = secondaryButton(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private Button baseButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout.LayoutParams videoLayoutParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        lp.setMargins(0, dp(8), 0, dp(8));
        return lp;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class UiProgress implements ProgressCallback {
        @Override public void onStep(String message) {
            runOnUiThread(() -> statusText.setText(message));
        }
        @Override public void onProgress(int percent) {
            runOnUiThread(() -> progressBar.setProgress(Math.max(0, Math.min(100, percent))));
        }
    }
}
