package com.entilio.music2videofree;

public interface ProgressCallback {
    void onStep(String message);
    void onProgress(int percent);
}
