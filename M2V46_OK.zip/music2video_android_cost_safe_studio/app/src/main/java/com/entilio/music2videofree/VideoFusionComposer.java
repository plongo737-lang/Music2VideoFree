package com.entilio.music2videofree;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.io.File;

public class VideoFusionComposer {
    public static Uri compose(Context context, Uri mainVideoUri, Uri singerVideoUri, Uri optionalFinalAudioUri,
                              ProjectOptions options, ProgressCallback callback) throws Exception {
        if (mainVideoUri == null) throw new Exception("Vidéo principale manquante.");
        if (singerVideoUri == null) throw new Exception("Vidéo secondaire/chanteur manquante.");

        callback.onStep("Analyse des deux vidéos…");
        long mainDurationUs = MediaMuxerTools.getDurationUs(context, mainVideoUri);
        if (mainDurationUs <= 0) mainDurationUs = 20_000_000L;
        long durationUs = options.maxDurationUs(mainDurationUs);
        int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));
        float[] levels = VideoEncoder.syntheticLevels(frameCount);
        File tempVideo = new File(context.getCacheDir(), "video_fusion_" + System.currentTimeMillis() + ".mp4");
        MediaMetadataRetriever mainRetriever = new MediaMetadataRetriever();
        MediaMetadataRetriever singerRetriever = new MediaMetadataRetriever();
        try {
            mainRetriever.setDataSource(context, mainVideoUri);
            singerRetriever.setDataSource(context, singerVideoUri);
            FusionDrawer drawer = new FusionDrawer(mainRetriever, singerRetriever, options);
            callback.onStep("Fusion vidéo dans vidéo en cours…");
            VideoEncoder.encodeVideoOnly(tempVideo, durationUs, options, levels, drawer, callback, 8, 86);
            callback.onStep("Assemblage audio et export non destructif…");
            Uri audioSource = optionalFinalAudioUri == null ? mainVideoUri : optionalFinalAudioUri;
            Uri output = MediaMuxerTools.muxVideoAndAudioToGallery(context, tempVideo, audioSource, durationUs, "video_fusion", callback);
            callback.onProgress(100);
            return output;
        } finally {
            try { mainRetriever.release(); } catch (Exception ignored) {}
            try { singerRetriever.release(); } catch (Exception ignored) {}
            if (tempVideo.exists()) tempVideo.delete();
        }
    }

    private static class FusionDrawer implements VideoEncoder.FrameDrawer {
        private final MediaMetadataRetriever mainRetriever;
        private final MediaMetadataRetriever singerRetriever;
        private final ProjectOptions options;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        FusionDrawer(MediaMetadataRetriever mainRetriever, MediaMetadataRetriever singerRetriever, ProjectOptions options) {
            this.mainRetriever = mainRetriever;
            this.singerRetriever = singerRetriever;
            this.options = options;
        }

        @Override
        public void render(Bitmap target, float timeSec, int frameIndex, float level) throws Exception {
            Canvas c = new Canvas(target);
            c.drawColor(Color.BLACK);
            Bitmap mainFrame = null;
            Bitmap singerFrame = null;
            try {
                mainFrame = mainRetriever.getFrameAtTime((long) (timeSec * 1_000_000L), MediaMetadataRetriever.OPTION_CLOSEST);
                if (mainFrame != null) drawFrame(c, mainFrame, fullRect(target), options.noCropZoom, 255);

                float start = options.fusionStartTimeUs / 1_000_000f;
                float len = Math.max(0.5f, options.fusionDurationUs / 1_000_000f);
                if (timeSec >= start && timeSec <= start + len) {
                    float local = timeSec - start;
                    singerFrame = singerRetriever.getFrameAtTime((long) (local * 1_000_000L), MediaMetadataRetriever.OPTION_CLOSEST);
                    if (singerFrame != null) drawSingerFrame(c, target, singerFrame, timeSec, start, len);
                }
            } finally {
                if (mainFrame != null && !mainFrame.isRecycled()) mainFrame.recycle();
                if (singerFrame != null && !singerFrame.isRecycled()) singerFrame.recycle();
                paint.setAlpha(255);
            }
        }

        private RectF fullRect(Bitmap target) {
            return new RectF(0, 0, target.getWidth(), target.getHeight());
        }

        private void drawSingerFrame(Canvas c, Bitmap target, Bitmap singerFrame, float timeSec, float start, float len) {
            String mode = options.fusionMode == null ? "" : options.fusionMode;
            int alpha = 255;
            if (mode.contains("Fondu") || mode.contains("Superposition")) {
                float fade = Math.min(1f, Math.min((timeSec - start) / 1.0f, (start + len - timeSec) / 1.0f));
                alpha = mode.contains("Superposition") ? (int) (150 + 70 * Math.max(0f, fade)) : (int) (255 * Math.max(0.2f, fade));
            }
            Bitmap displayFrame = singerFrame;
            Bitmap keyedFrame = null;
            if (options.fusionChromaKey) {
                keyedFrame = simpleGreenChromaKey(singerFrame);
                if (keyedFrame != null) displayFrame = keyedFrame;
            }

            RectF dst = singerDestination(target, displayFrame);
            if (options.fusionFeather) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(Math.min(90, alpha / 3), 0, 0, 0));
                RectF shadow = new RectF(dst.left - 8, dst.top - 8, dst.right + 8, dst.bottom + 8);
                c.drawRoundRect(shadow, 20, 20, paint);
            }
            drawFrame(c, displayFrame, dst, true, alpha);
            if (keyedFrame != null && !keyedFrame.isRecycled()) keyedFrame.recycle();
            if (options.fusionFeather) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(3f);
                paint.setColor(Color.argb(150, 216, 180, 93));
                c.drawRoundRect(dst, 18, 18, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }

        private RectF singerDestination(Bitmap target, Bitmap singerFrame) {
            String mode = options.fusionMode == null ? "" : options.fusionMode;
            String pos = options.fusionPosition == null ? "Bas droite" : options.fusionPosition;
            int tw = target.getWidth();
            int th = target.getHeight();
            if (mode.contains("Plein écran") || pos.contains("Plein")) return new RectF(0, 0, tw, th);
            if (mode.contains("Écran partagé")) {
                if (pos.contains("gauche") || pos.contains("gauche")) return new RectF(0, 0, tw / 2f, th);
                return new RectF(tw / 2f, 0, tw, th);
            }
            float boxW = mode.contains("Superposition") ? tw * 0.52f : tw * 0.38f;
            float aspect = singerFrame.getHeight() <= 0 ? 1.4f : singerFrame.getHeight() / (float) Math.max(1, singerFrame.getWidth());
            float boxH = Math.min(th * 0.62f, boxW * aspect);
            float margin = Math.max(18f, tw * 0.04f);
            float left;
            float top;
            if (pos.contains("Haut")) top = margin;
            else if (pos.contains("Centre")) top = th / 2f - boxH / 2f;
            else top = th - boxH - margin;
            if (pos.contains("gauche")) left = margin;
            else if (pos.contains("Centre")) left = tw / 2f - boxW / 2f;
            else left = tw - boxW - margin;
            return new RectF(left, top, left + boxW, top + boxH);
        }


        private Bitmap simpleGreenChromaKey(Bitmap src) {
            try {
                Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
                int w = out.getWidth();
                int h = out.getHeight();
                int[] pixels = new int[w * h];
                out.getPixels(pixels, 0, w, 0, 0, w, h);
                for (int i = 0; i < pixels.length; i++) {
                    int c = pixels[i];
                    int r = Color.red(c);
                    int g = Color.green(c);
                    int b = Color.blue(c);
                    if (g > 92 && g > r * 1.25f && g > b * 1.25f) {
                        int alpha = Math.max(0, 255 - (g - Math.max(r, b)) * 3);
                        pixels[i] = Color.argb(alpha, r, g, b);
                    }
                }
                out.setPixels(pixels, 0, w, 0, 0, w, h);
                return out;
            } catch (Exception e) {
                return null;
            }
        }

        private void drawFrame(Canvas c, Bitmap frame, RectF bounds, boolean fitInside, int alpha) {
            if (frame == null) return;
            float scale = fitInside
                    ? Math.min(bounds.width() / frame.getWidth(), bounds.height() / frame.getHeight())
                    : Math.max(bounds.width() / frame.getWidth(), bounds.height() / frame.getHeight());
            float w = frame.getWidth() * scale;
            float h = frame.getHeight() * scale;
            RectF dst = new RectF(bounds.centerX() - w / 2f, bounds.centerY() - h / 2f, bounds.centerX() + w / 2f, bounds.centerY() + h / 2f);
            paint.setAlpha(alpha);
            c.save();
            c.clipRect(bounds);
            c.drawBitmap(frame, null, dst, paint);
            c.restore();
            paint.setAlpha(255);
        }
    }
}
