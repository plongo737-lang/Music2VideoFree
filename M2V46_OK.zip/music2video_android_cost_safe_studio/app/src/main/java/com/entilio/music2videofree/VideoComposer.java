package com.entilio.music2videofree;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.view.Surface;
import android.graphics.Bitmap;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VideoComposer {
    private static final int TIMEOUT_US = 10_000;

    public static Uri compose(Context context, Uri audioUri, List<Uri> imageUris, ProjectOptions options,
                              ProgressCallback callback) throws Exception {
        callback.onStep("Lecture de la durée audio…");
        long fullDurationUs = getAudioDurationUs(context, audioUri);
        if (fullDurationUs <= 0) fullDurationUs = 20_000_000L;
        long durationUs = options.maxDurationUs(fullDurationUs);
        int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));

        callback.onStep("Analyse du rythme et de la voix…");
        float[] levels = AudioAnalyzer.analyze(context, audioUri, frameCount, options.fps);
        callback.onProgress(8);

        callback.onStep("Chargement des images…");
        List<Bitmap> bitmaps = ImageLoader.loadBitmaps(context, imageUris, 1800);
        callback.onProgress(12);

        File tempVideo = new File(context.getCacheDir(), "m2v_video_only_" + System.currentTimeMillis() + ".mp4");
        try {
            callback.onStep("Création des mouvements vidéo…");
            encodeVideoOnly(tempVideo, bitmaps, levels, durationUs, options, callback);
            callback.onStep("Ajout de la musique au MP4…");
            Uri result = muxVideoAndAudio(context, tempVideo, audioUri, durationUs, callback);
            callback.onProgress(100);
            return result;
        } finally {
            ImageLoader.recycle(bitmaps);
            if (tempVideo.exists()) tempVideo.delete();
        }
    }

    private static long getAudioDurationUs(Context context, Uri audioUri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, audioUri);
            String ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (ms == null) return 0;
            return Long.parseLong(ms) * 1000L;
        } catch (Exception e) {
            return 0;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private static void encodeVideoOnly(File outputFile, List<Bitmap> images, float[] levels, long durationUs,
                                        ProjectOptions options, ProgressCallback callback) throws Exception {
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        InputSurface inputSurface = null;
        TextureRenderer textureRenderer = null;
        Surface surface = null;
        Bitmap frameBitmap = null;
        try {
            MediaFormat format = MediaFormat.createVideoFormat("video/avc", options.width, options.height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            format.setInteger(MediaFormat.KEY_BIT_RATE, options.bitrate);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, options.fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            encoder = MediaCodec.createEncoderByType("video/avc");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = encoder.createInputSurface();
            inputSurface = new InputSurface(surface);
            inputSurface.makeCurrent();
            textureRenderer = new TextureRenderer();
            textureRenderer.init();
            encoder.start();

            muxer = new MediaMuxer(outputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            TrackState state = new TrackState();
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            BitmapFrameRenderer frameRenderer = new BitmapFrameRenderer(options.width, options.height, images, options);
            frameBitmap = Bitmap.createBitmap(options.width, options.height, Bitmap.Config.ARGB_8888);
            int frameCount = Math.max(1, (int) ((durationUs * options.fps) / 1_000_000L));

            for (int frame = 0; frame < frameCount; frame++) {
                float timeSec = frame / (float) options.fps;
                float level = frame < levels.length ? levels[frame] : 0f;
                frameRenderer.render(frameBitmap, timeSec, frame, level);
                textureRenderer.drawBitmap(frameBitmap);
                inputSurface.setPresentationTime((long) frame * 1_000_000_000L / options.fps);
                inputSurface.swapBuffers();
                drainEncoder(encoder, muxer, bufferInfo, state, false);
                if (frame % Math.max(1, options.fps / 2) == 0) {
                    int p = 12 + Math.round((frame / (float) frameCount) * 72f);
                    callback.onProgress(p);
                }
            }
            drainEncoder(encoder, muxer, bufferInfo, state, true);
        } finally {
            if (frameBitmap != null && !frameBitmap.isRecycled()) frameBitmap.recycle();
            if (textureRenderer != null) textureRenderer.release();
            if (inputSurface != null) inputSurface.release();
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
            if (muxer != null) {
                try { muxer.stop(); } catch (Exception ignored) {}
                muxer.release();
            }
        }
    }

    private static void drainEncoder(MediaCodec encoder, MediaMuxer muxer, MediaCodec.BufferInfo bufferInfo,
                                     TrackState state, boolean endOfStream) {
        if (endOfStream) encoder.signalEndOfInputStream();
        while (true) {
            int encoderStatus = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US);
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (state.muxerStarted) throw new RuntimeException("Format changed twice");
                MediaFormat newFormat = encoder.getOutputFormat();
                state.trackIndex = muxer.addTrack(newFormat);
                muxer.start();
                state.muxerStarted = true;
            } else if (encoderStatus < 0) {
                // Ignore other status codes.
            } else {
                ByteBuffer encodedData = encoder.getOutputBuffer(encoderStatus);
                if (encodedData == null) throw new RuntimeException("encoderOutputBuffer " + encoderStatus + " was null");

                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    bufferInfo.size = 0;
                }

                if (bufferInfo.size != 0) {
                    if (!state.muxerStarted) throw new RuntimeException("muxer has not started");
                    encodedData.position(bufferInfo.offset);
                    encodedData.limit(bufferInfo.offset + bufferInfo.size);
                    muxer.writeSampleData(state.trackIndex, encodedData, bufferInfo);
                }

                encoder.releaseOutputBuffer(encoderStatus, false);
                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }

    private static Uri muxVideoAndAudio(Context context, File videoOnlyFile, Uri audioUri, long durationUs,
                                        ProgressCallback callback) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        String name = "music2video_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Music2VideoFree");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri outUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (outUri == null) throw new Exception("Impossible de créer le fichier de sortie.");

        MediaExtractor videoExtractor = new MediaExtractor();
        MediaExtractor audioExtractor = new MediaExtractor();
        ParcelFileDescriptor pfd = null;
        MediaMuxer muxer = null;
        boolean success = false;
        try {
            videoExtractor.setDataSource(videoOnlyFile.getAbsolutePath());
            int videoTrack = AudioAnalyzer.selectTrack(videoExtractor, false);
            if (videoTrack < 0) throw new Exception("Piste vidéo non trouvée.");
            MediaFormat videoFormat = videoExtractor.getTrackFormat(videoTrack);

            audioExtractor.setDataSource(context, audioUri, null);
            int audioTrack = AudioAnalyzer.selectTrack(audioExtractor, true);
            MediaFormat audioFormat = audioTrack >= 0 ? audioExtractor.getTrackFormat(audioTrack) : null;

            pfd = resolver.openFileDescriptor(outUri, "w");
            if (pfd == null) throw new Exception("Impossible d’ouvrir le fichier de sortie.");
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int muxVideo = muxer.addTrack(videoFormat);
            int muxAudio = -1;
            if (audioFormat != null) {
                try {
                    muxAudio = muxer.addTrack(audioFormat);
                } catch (Exception unsupported) {
                    muxAudio = -1;
                }
            }
            muxer.start();

            copyTrack(videoExtractor, videoTrack, muxer, muxVideo, durationUs);
            callback.onProgress(90);
            if (muxAudio >= 0) {
                copyTrack(audioExtractor, audioTrack, muxer, muxAudio, durationUs);
            }
            callback.onProgress(96);
            success = true;
        } finally {
            try { if (muxer != null) muxer.stop(); } catch (Exception ignored) {}
            if (muxer != null) muxer.release();
            if (pfd != null) pfd.close();
            videoExtractor.release();
            audioExtractor.release();
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(outUri, done, null, null);
            if (!success) resolver.delete(outUri, null, null);
        }
        return outUri;
    }

    private static void copyTrack(MediaExtractor extractor, int sourceTrack, MediaMuxer muxer, int muxTrack,
                                  long durationUs) {
        extractor.selectTrack(sourceTrack);
        ByteBuffer buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (true) {
            buffer.clear();
            int sampleSize = extractor.readSampleData(buffer, 0);
            if (sampleSize < 0) break;
            long sampleTimeUs = extractor.getSampleTime();
            if (durationUs > 0 && sampleTimeUs > durationUs) break;
            info.set(0, sampleSize, Math.max(0, sampleTimeUs), extractor.getSampleFlags());
            muxer.writeSampleData(muxTrack, buffer, info);
            extractor.advance();
        }
    }

    private static class TrackState {
        int trackIndex = -1;
        boolean muxerStarted = false;
    }
}
