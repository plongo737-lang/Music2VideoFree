package com.entilio.music2videofree;

import android.content.Context;
import android.net.Uri;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LyricsEngine {
    public static String generateOriginalLyrics(String theme, String mood) {
        SongBrief brief = SongBrief.from(theme, mood);
        StringBuilder sb = new StringBuilder();
        sb.append("[Titre] ").append(brief.title).append("\n\n");
        sb.append("[Intro]\n");
        sb.append(brief.intro).append("\n\n");
        sb.append("[Couplet 1]\n");
        for (String line : brief.verse1) sb.append(line).append("\n");
        sb.append("\n[Pré-refrain]\n");
        for (String line : brief.preChorus) sb.append(line).append("\n");
        sb.append("\n[Refrain]\n");
        for (String line : brief.chorus) sb.append(line).append("\n");
        sb.append("\n[Couplet 2]\n");
        for (String line : brief.verse2) sb.append(line).append("\n");
        sb.append("\n[Pont]\n");
        for (String line : brief.bridge) sb.append(line).append("\n");
        sb.append("\n[Refrain final]\n");
        for (String line : brief.finalChorus) sb.append(line).append("\n");
        sb.append("\n[Production]\n");
        sb.append("Style : ").append(brief.styleLabel).append("\n");
        sb.append("Tonalité : ").append(brief.keyLabel).append("\n");
        sb.append("Voix : ").append(brief.voiceLabel).append("\n");
        return sb.toString().trim();
    }

    private static class SongBrief {
        String title;
        String intro;
        String[] verse1;
        String[] preChorus;
        String[] chorus;
        String[] verse2;
        String[] bridge;
        String[] finalChorus;
        String styleLabel;
        String keyLabel;
        String voiceLabel;

        static SongBrief from(String rawTheme, String rawMood) {
            String theme = rawTheme == null ? "" : rawTheme.trim();
            String lower = theme.toLowerCase(Locale.ROOT);
            String mood = rawMood == null ? "" : rawMood;
            String moodLower = mood.toLowerCase(Locale.ROOT);
            SongBrief b = new SongBrief();
            b.styleLabel = extractPart(mood, 0, "Pop cinématique");
            b.keyLabel = extractContaining(mood, "majeur", "mineur", "Tonalité auto");
            b.voiceLabel = extractContaining(mood, "voix", "instrumental", "Voix exemple homme");

            boolean portugal = containsAny(lower, "portugal", "portugais", "village");
            boolean wife = containsAny(lower, "femme", "épouse", "amour", "ensemble");
            boolean fifty = containsAny(lower, "50 ans", "cinquante", "50");
            boolean fifteen = containsAny(lower, "15 ans", "quinze", "adolescence");
            boolean thanks = containsAny(lower, "remercie", "merci", "soutenue", "soutien", "restée");
            boolean farmer = containsAny(lower, "paysan", "champ", "terre", "ferme");

            if (portugal && wife) {
                b.title = "Toujours avec toi";
                b.intro = portugal ? "Dans un vieux village du Portugal, une voix se souvient" : "Dans le silence du matin, une voix se souvient";
                b.verse1 = new String[]{
                        farmer ? "J'ai porté la terre au creux de mes mains" : "J'ai marché longtemps au bord de mon chemin",
                        portugal ? "Les pierres du village connaissent nos matins" : "Les murs de ma mémoire connaissent nos matins",
                        fifteen ? "Depuis nos quinze ans, ton regard m'accompagne" : "Depuis le premier jour, ton regard m'accompagne",
                        "Et chaque saison me ramène à nous deux"
                };
                b.preChorus = new String[]{
                        "Quand le vent se lève et que le temps nous éprouve",
                        "je retrouve ta main, je retrouve la preuve"
                };
                b.chorus = new String[]{
                        "Merci d'être restée près de moi",
                        "quand la route était longue et que je doutais parfois",
                        fifty ? "Cinquante ans plus tard, je chante encore pour toi" : "Année après année, je chante encore pour toi",
                        "ma maison, ma lumière, mon histoire et ma voix"
                };
                b.verse2 = new String[]{
                        farmer ? "La poussière des champs s'est posée sur nos vies" : "Les années ont laissé leur trace sur nos vies",
                        "mais ton sourire tient debout mes souvenirs",
                        "J'ai connu des hivers, des silences et des nuits",
                        "tu m'as donné la force de toujours revenir"
                };
                b.bridge = new String[]{
                        thanks ? "Je te remercie pour tout ce que tu as porté" : "Je n'oublie rien de ce que tu as porté",
                        "tes pas près des miens quand je croyais tomber",
                        "si le monde change, je garde au fond de moi",
                        "le premier serment que j'ai fait devant toi"
                };
                b.finalChorus = new String[]{
                        "Merci d'être restée près de moi",
                        "dans le village, dans le temps, dans la joie",
                        "si ma voix tremble, elle sait pourquoi",
                        "je chante notre vie, et je la chante pour toi"
                };
                return b;
            }

            String subject = cleanTheme(theme);
            b.title = titleCase(shortSubject(subject));
            b.intro = "Une histoire commence, portée par la mémoire";
            b.verse1 = new String[]{
                    "Je marche avec " + subject + " dans la poitrine",
                    "mais je cherche des mots plus vrais que la routine",
                    "Chaque image revient avec sa couleur",
                    "je garde le fil, je transforme la peur"
            };
            b.preChorus = new String[]{
                    moodLower.contains("dance") ? "La nuit se rallume et le rythme me tient" : "Même quand la nuit veut fermer mes yeux",
                    moodLower.contains("rap") ? "les mots frappent en cadence, je transforme le silence" : "mon cœur garde la lumière au bord de la nuit"
            };
            b.chorus = new String[]{
                    hookFor(subject, moodLower),
                    "Je donne ma voix, je garde ma foi",
                    hookFor(subject, moodLower),
                    "ce film dans mon âme devient plus grand que moi"
            };
            b.verse2 = new String[]{
                    "Les visages défilent comme un vieux cinéma",
                    "je choisis la lumière, même quand elle tremble bas",
                    "Chaque pas raconte ce que je n'ai pas dit",
                    "chaque note dessine une part de ma vie"
            };
            b.bridge = new String[]{
                    "Si le passé revient, je ne baisse plus les bras",
                    "je transforme la peine en force dans ma voix"
            };
            b.finalChorus = new String[]{
                    hookFor(subject, moodLower),
                    "Je donne ma voix, je garde ma foi",
                    hookFor(subject, moodLower),
                    "et la vidéo s'allume autour de moi"
            };
            return b;
        }
    }

    private static boolean containsAny(String text, String... keys) {
        for (String k : keys) if (text.contains(k)) return true;
        return false;
    }

    private static String extractPart(String text, int index, String fallback) {
        if (text == null) return fallback;
        String[] parts = text.split("•");
        if (index >= 0 && index < parts.length) {
            String p = parts[index].trim();
            if (p.length() > 0) return p;
        }
        return fallback;
    }

    private static String extractContaining(String text, String a, String b, String fallback) {
        if (text == null) return fallback;
        String[] parts = text.split("•");
        for (String p : parts) {
            String low = p.toLowerCase(Locale.ROOT);
            if (low.contains(a) || low.contains(b)) return p.trim();
        }
        return fallback;
    }

    private static String shortSubject(String s) {
        if (s == null || s.length() == 0) return "Chanson";
        return s.length() > 38 ? s.substring(0, 38).trim() : s;
    }

    public static String createExistingSongTranscriptionGuide(Context context, Uri audioUri, ProjectOptions options) {
        long durationUs = audioUri == null ? options.textSongDurationUs() : MediaMuxerTools.getDurationUs(context, audioUri);
        if (durationUs <= 0) durationUs = 60_000_000L;
        int seconds = (int) Math.max(8, durationUs / 1_000_000L);
        int lineCount = Math.max(6, Math.min(36, seconds / 7));
        StringBuilder sb = new StringBuilder();
        sb.append("[Transcription paroles existantes]\n");
        sb.append("Mode gratuit/offline : guide de synchronisation créé automatiquement depuis la durée audio.\n");
        sb.append("Pour obtenir les mots exacts automatiquement, ajoute le module IA Whisper/Vosk décrit dans TRANSCRIPTION_AND_AI_MODULES.md, ou colle les paroles exactes ici.\n\n");
        for (int i = 0; i < lineCount; i++) {
            int start = Math.round(i * seconds / (float) lineCount);
            int end = Math.round((i + 1) * seconds / (float) lineCount);
            sb.append("[").append(formatTime(start)).append(" - ").append(formatTime(end)).append("] ");
            sb.append("ligne de paroles à transcrire / remplacer\n");
        }
        return sb.toString();
    }

    public static List<String> splitForTimeline(String text) {
        List<String> lines = new ArrayList<>();
        if (text == null) return lines;
        String[] raw = text.replace("\r", "").split("\n");
        StringBuilder current = new StringBuilder();
        for (String line : raw) {
            String l = line.trim();
            if (l.isEmpty()) continue;
            if (l.startsWith("[Titre") || l.startsWith("[Couplet") || l.startsWith("[Refrain") ||
                    l.startsWith("[Pont") || l.startsWith("[Pré") || l.startsWith("[Transcription")) {
                continue;
            }
            if (l.matches("^\\[[0-9: .–—-]+\\].*")) {
                l = l.replaceFirst("^\\[[^\\]]+\\]", "").trim();
            }
            if (l.length() == 0) continue;
            if (current.length() > 0) current.append("\n");
            current.append(l);
            if (current.length() > 70 || current.toString().contains("\n")) {
                lines.add(current.toString());
                current.setLength(0);
            }
        }
        if (current.length() > 0) lines.add(current.toString());
        if (lines.isEmpty() && text.trim().length() > 0) lines.add(text.trim());
        return lines;
    }

    public static String normalizePrompt(String text) {
        if (text == null) return "";
        return Normalizer.normalize(text.trim(), Normalizer.Form.NFC);
    }

    private static String cleanTheme(String theme) {
        String s = theme == null ? "l'espoir" : theme.trim();
        if (s.length() == 0) s = "l'espoir";
        if (s.length() > 90) s = s.substring(0, 90).trim();
        return s;
    }

    private static String titleCase(String text) {
        if (text == null || text.length() == 0) return "Chanson";
        return text.substring(0, 1).toUpperCase(Locale.ROOT) + text.substring(1);
    }

    private static String hookFor(String subject, String mood) {
        if (mood.contains("rap")) return "Je viens de loin, " + subject + " dans les veines";
        if (mood.contains("emotion") || mood.contains("émotion")) return "Je reste debout, même quand " + subject + " m'appelle";
        if (mood.contains("dance")) return "On danse avec " + subject + ", jusqu'au matin";
        return "Je suis encore là, porté par " + subject;
    }

    private static String formatTime(int seconds) {
        int m = Math.max(0, seconds) / 60;
        int s = Math.max(0, seconds) % 60;
        return String.format(Locale.US, "%02d:%02d", m, s);
    }
}
