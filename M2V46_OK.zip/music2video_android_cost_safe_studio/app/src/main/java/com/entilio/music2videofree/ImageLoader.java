package com.entilio.music2videofree;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;

import java.util.ArrayList;
import java.util.List;

public class ImageLoader {
    public static List<Bitmap> loadBitmaps(Context context, List<Uri> uris, int maxSize) {
        ArrayList<Bitmap> bitmaps = new ArrayList<>();
        if (uris == null) return bitmaps;
        for (Uri uri : uris) {
            try {
                ImageDecoder.Source source = ImageDecoder.createSource(context.getContentResolver(), uri);
                Bitmap bitmap = ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    int w = info.getSize().getWidth();
                    int h = info.getSize().getHeight();
                    int largest = Math.max(w, h);
                    if (largest > maxSize) {
                        float scale = maxSize / (float) largest;
                        decoder.setTargetSize(Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)));
                    }
                });
                bitmaps.add(bitmap);
            } catch (Exception ignored) {
                // Ignore unreadable images so one bad photo does not stop the project.
            }
        }
        return bitmaps;
    }

    public static void recycle(List<Bitmap> bitmaps) {
        if (bitmaps == null) return;
        for (Bitmap b : bitmaps) {
            if (b != null && !b.isRecycled()) b.recycle();
        }
        bitmaps.clear();
    }
}
