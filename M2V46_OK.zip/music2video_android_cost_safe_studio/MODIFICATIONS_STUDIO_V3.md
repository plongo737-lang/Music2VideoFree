# Music2Video Free Studio V3

Modifications ajoutées suite aux retours utilisateur :

- Accueil studio plus clair avec cartes de tableau de bord : Vidéos, Musiques, Images, Timecode.
- Bibliothèque locale structurée par catégories et accès direct aux modes de travail.
- Bouton de prompt automatique pour la création musique -> vidéo.
- Aide dédiée au prompt automatique.
- Bouton d'aide contextualisée : quelle motion choisir ?
- Explications motion renforcées, avec recommandation de conserver la motion source pour les corrections.
- Studio multipiste/timecode renforcé :
  - ajustement du timecode de départ par -0,5 s / +0,5 s ;
  - bouton pour aller au timecode dans l'aperçu source ;
  - validation de placement sécurisé ;
  - repères rapides sur la timeline source ;
  - rappel permanent des verrous qualité source, motion source et recadrage/zoom.
- Style visuel arrondi et cartes plus modernes.

Note : l'application reste locale, gratuite et sans clé API. Les fonctions de bibliothèque avancée restent locales et sans service cloud.
