# Modifications V4.3 — local + PC, sans API payante

- Titre visible passé en **Music2Video Free Studio V4.3 local + PC**.
- Suppression de la section visible **Sécurité coûts / IA avancée**.
- Suppression des boutons liés aux options payantes/cloud.
- Suppression du moteur `CostPolicy` dans le code Android.
- Ajout d'une section **Moteur PC local / open source**.
- Ajout d'un champ d'adresse locale PC.
- Ajout d'une aide expliquant le fonctionnement téléphone + PC.
- Conservation des sources gratuites : Pexels, Pixabay, Jamendo, Freesound.
- Conservation de l'export MP4 local qualité source / 720p / 1080p / 4K.
- Conservation du module fusion vidéo dans vidéo / chanteur intégré.
- Ancien smiley lip-sync toujours supprimé.

Cette version ne lance et ne propose aucune API payante.
