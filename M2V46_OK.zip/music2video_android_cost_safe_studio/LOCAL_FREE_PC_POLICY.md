# Politique V4.3 — local, gratuit, sans API payante

Cette version ne doit pas proposer de bouton ou redirection vers des services IA payants.

## Autorisé

- Traitement local Android.
- Sources de médias libres : Pexels, Pixabay, Jamendo, Freesound.
- Export MP4 local.
- PC Companion local/open source.
- Moteurs installés par l'utilisateur sur son propre PC : ComfyUI, MusicGen/AudioCraft, SadTalker/Wav2Lip, RIFE, Real-ESRGAN.

## Non autorisé dans l'interface

- Bouton vers API payante.
- Bouton "tester une option payante".
- Champ de clé pour service payant.
- Envoi automatique vers cloud payant.
- Estimation de coûts ou validation de paiement.

## Principe

Si une fonction est trop lourde pour Android, l'application doit proposer :

1. un mode local simple ;
2. un mode PC local/open source ;
3. aucune API payante par défaut.
