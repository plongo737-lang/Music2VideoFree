package com.entilio.music2videofree;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.nio.ByteBuffer;
import java.util.Locale;

public class TextSongComposer {
    private static final int TIMEOUT_US = 10_000;

    public static Uri compose(Context context, String text, ProjectOptions options, ProgressCallback callback) throws Exception {
        String clean = text == null || text.trim().isEmpty() ? "Je suis encore là" : text.trim();
        long durationUs = options.textSongDurationUs();
        int sampleRate = 44100;
        int channels = 1;
        int bitRate = 160_000;
        long totalSamples = Math.max(1, durationUs * sampleRate / 1_000_000L);

        Uri outUri = MediaMuxerTools.createAudioUri(context, "text_to_song_v45", ".m4a", "audio/mp4");
        ParcelFileDescriptor pfd = null;
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean success = false;
        try {
            callback.onStep("Création des pistes audio locales : voix guide, choeurs, batterie, basse, instruments…");
            pfd = context.getContentResolver().openFileDescriptor(outUri, "w");
            if (pfd == null) throw new Exception("Impossible d’ouvrir le fichier audio.");

            MediaFormat format = MediaFormat.createAudioFormat("audio/mp4a-latm", sampleRate, channels);
            format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitRate);
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024);

            encoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            boolean muxerStarted = false;
            int trackIndex = -1;
            long sampleCursor = 0;
            SongPlan plan = new SongPlan(clean, options);

            while (!outputDone) {
                if (!inputDone) {
                    int inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US);
                    if (inputIndex >= 0) {
                        ByteBuffer input = encoder.getInputBuffer(inputIndex);
                        if (input == null) continue;
                        input.clear();
                        int maxSamples = Math.max(256, input.remaining() / 2);
                        int samples = (int) Math.min(maxSamples, totalSamples - sampleCursor);
                        long ptsUs = sampleCursor * 1_000_000L / sampleRate;
                        if (samples <= 0) {
                            encoder.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            fillPcm(input, samples, sampleCursor, sampleRate, plan);
                            encoder.queueInputBuffer(inputIndex, 0, samples * 2, ptsUs, 0);
                            sampleCursor += samples;
                            int progress = 8 + Math.round((sampleCursor / (float) totalSamples) * 76f);
                            callback.onProgress(progress);
                        }
                    }
                }

                int outputIndex = encoder.dequeueOutputBuffer(info, TIMEOUT_US);
                if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    // Wait for more output.
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new RuntimeException("Format changed twice");
                    trackIndex = muxer.addTrack(encoder.getOutputFormat());
                    muxer.start();
                    muxerStarted = true;
                } else if (outputIndex >= 0) {
                    ByteBuffer output = encoder.getOutputBuffer(outputIndex);
                    if (output == null) throw new RuntimeException("Audio encoder buffer null");
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size != 0) {
                        if (!muxerStarted) throw new RuntimeException("Muxer audio non démarré");
                        output.position(info.offset);
                        output.limit(info.offset + info.size);
                        muxer.writeSampleData(trackIndex, output, info);
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    encoder.releaseOutputBuffer(outputIndex, false);
                }
            }
            callback.onProgress(96);
            success = true;
            return outUri;
        } finally {
            try { if (muxer != null) muxer.stop(); } catch (Exception ignored) {}
            if (muxer != null) muxer.release();
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
            if (pfd != null) pfd.close();
            MediaMuxerTools.finishPendingAudio(context, outUri, success);
        }
    }

    private static void fillPcm(ByteBuffer input, int samples, long startSample, int sampleRate, SongPlan plan) {
        for (int i = 0; i < samples; i++) {
            long globalSample = startSample + i;
            double t = globalSample / (double) sampleRate;
            double beat = t / plan.beatSeconds;
            int beatIndex = (int) Math.floor(beat);
            double beatPhase = beat - beatIndex;
            int chordIndex = (beatIndex / 4) % plan.chords.length;
            double chord = plan.chords[chordIndex];
            double barPhase = (beatIndex % 4) + beatPhase;
            double section = (t % Math.max(12.0, plan.durationSeconds)) / Math.max(12.0, plan.durationSeconds);
            double intensity = section < 0.12 ? 0.55 : (section > 0.70 ? 1.0 : 0.82);

            double value = 0.0;
            if (plan.instrumentDrums) value += drums(t, beatIndex, beatPhase, plan) * 0.85 * intensity;
            if (plan.instrumentPercussion) value += percussion(t, beat, globalSample, plan) * 0.65 * intensity;
            if (plan.instrumentBass) value += bass(t, beatPhase, chord, plan) * 0.90 * intensity;
            if (plan.instrumentPiano) value += piano(t, beatIndex, beatPhase, chord, plan) * 0.62;
            if (plan.instrumentFolkGuitar) value += acousticGuitar(t, beatIndex, beatPhase, chord, plan, false) * 0.58;
            if (plan.instrumentClassicGuitar) value += acousticGuitar(t, beatIndex, beatPhase, chord, plan, true) * 0.50;
            if (plan.instrumentElectricGuitar) value += electricGuitar(t, beatIndex, beatPhase, chord, plan) * 0.46;
            if (plan.instrumentStrings) value += stringsPad(t, chord, plan) * 0.46;
            if (plan.hasVoiceGuide) value += vocalGuide(t, beatIndex, beatPhase, plan) * plan.voiceGain;
            if (plan.hasChoir) value += choirPad(t, chord, plan) * 0.26;

            // Mastering simple : compression douce + limiteur.
            value *= plan.masterGain;
            value = softClip(value * plan.drive) / Math.max(1.0, plan.drive * 0.82);
            value = Math.max(-plan.targetPeak, Math.min(plan.targetPeak, value));
            short pcm = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, (int) (value * 32767.0)));
            input.put((byte) (pcm & 0xff));
            input.put((byte) ((pcm >> 8) & 0xff));
        }
    }

    private static double drums(double t, int beatIndex, double beatPhase, SongPlan plan) {
        double kick = 0.0;
        boolean fourOnFloor = plan.mood.contains("Dance") || plan.mood.contains("Rap");
        if ((fourOnFloor || beatIndex % 4 == 0 || (plan.mood.contains("Rock") && beatIndex % 4 == 2)) && beatPhase < 0.24) {
            kick = Math.sin(2.0 * Math.PI * (46 + 90 * (1.0 - beatPhase)) * t) * Math.exp(-beatPhase * 14.0);
        }
        double snare = 0.0;
        if ((beatIndex % 4 == 1 || beatIndex % 4 == 3) && beatPhase < 0.14) {
            snare = noise((long) (t * 44100.0)) * Math.exp(-beatPhase * 18.0);
        }
        double hat = 0.0;
        double half = (t / (plan.beatSeconds / 2.0)) % 1.0;
        if (half < 0.08) hat = noise((long) (t * 44100.0 * 7.0)) * Math.exp(-half * 20.0);
        if (plan.mood.contains("Reggae") && beatIndex % 2 == 1 && beatPhase < 0.15) snare *= 0.75;
        return kick * 0.42 + snare * 0.22 + hat * 0.09;
    }

    private static double percussion(double t, double beat, long sample, SongPlan plan) {
        double off = (beat + 0.5) % 1.0;
        double shaker = off < 0.10 ? noise(sample * 11L) * Math.exp(-off * 24.0) : 0.0;
        double clave = 0.0;
        int slot = (int) Math.floor(beat * 2.0) % 8;
        double phase = (beat * 2.0) - Math.floor(beat * 2.0);
        if ((slot == 0 || slot == 3 || slot == 5) && phase < 0.09) {
            clave = Math.sin(2.0 * Math.PI * 1450.0 * t) * Math.exp(-phase * 32.0);
        }
        return shaker * 0.07 + clave * 0.10;
    }

    private static double bass(double t, double beatPhase, double chord, SongPlan plan) {
        double freq = plan.root * 0.5 * chord;
        if (plan.mood.contains("Reggae")) freq *= (beatPhase < 0.5 ? 1.0 : 1.125);
        double env = 0.45 + 0.55 * Math.exp(-beatPhase * 3.5);
        return sine(freq, t) * 0.30 * env + sine(freq * 2.0, t) * 0.07 * env;
    }

    private static double piano(double t, int beatIndex, double beatPhase, double chord, SongPlan plan) {
        int note = (beatIndex + plan.noteSeed(beatIndex)) % plan.scale.length;
        double freq = plan.root * chord * plan.scale[note] * (beatIndex % 8 < 6 ? 1.0 : 2.0);
        double env = Math.exp(-beatPhase * 5.0);
        double arp = sine(freq, t) * 0.26 + sine(freq * 2.0, t) * 0.06;
        return arp * env;
    }

    private static double acousticGuitar(double t, int beatIndex, double beatPhase, double chord, SongPlan plan, boolean classic) {
        double strumPhase = ((beatPhase + (classic ? 0.08 : 0.0)) % 0.5) / 0.5;
        double env = Math.exp(-strumPhase * (classic ? 5.2 : 7.0));
        double base = plan.root * chord;
        double s = sine(base, t) * 0.16 + sine(base * 1.25, t) * 0.13 + sine(base * 1.5, t) * 0.10;
        double pick = noise((long) (t * 44100.0 * 3.0)) * 0.018;
        return (s + pick) * env;
    }

    private static double electricGuitar(double t, int beatIndex, double beatPhase, double chord, SongPlan plan) {
        int note = (beatIndex * 2 + plan.noteSeed(beatIndex)) % plan.scale.length;
        double freq = plan.root * chord * plan.scale[note] * 2.0;
        double env = Math.exp(-beatPhase * 2.4) * (0.6 + 0.4 * Math.sin(Math.PI * Math.min(1.0, beatPhase * 2.0)));
        return softClip((sine(freq, t) + 0.5 * sine(freq * 2.0, t)) * 1.8) * 0.18 * env;
    }

    private static double stringsPad(double t, double chord, SongPlan plan) {
        double freq = plan.root * chord;
        double slow = 0.75 + 0.25 * Math.sin(2.0 * Math.PI * 0.11 * t);
        return (sine(freq, t) * 0.13 + sine(freq * 1.5, t) * 0.11 + sine(freq * 2.0, t) * 0.08) * slow;
    }

    private static double vocalGuide(double t, int beatIndex, double beatPhase, SongPlan plan) {
        int note = (plan.noteSeed(beatIndex) + beatIndex / 2) % plan.scale.length;
        double freq = plan.root * plan.scale[note] * (plan.femaleVoice ? 2.0 : 1.0);
        double phrase = (beatIndex % 8 < 6) ? 1.0 : 0.0;
        double env = phrase * Math.exp(-beatPhase * 1.35) * (0.65 + 0.35 * Math.sin(Math.PI * Math.min(1.0, beatPhase * 1.7)));
        double vibrato = 1.0 + 0.008 * Math.sin(2.0 * Math.PI * 5.5 * t);
        double f = freq * vibrato;
        double voice = sine(f, t) * 0.38 + sine(f * 2.0, t) * 0.11 + sine(f * 3.0, t) * 0.05;
        // Formant simple pour donner une couleur de voix guide, sans prétendre à une vraie voix chantée.
        double formant = Math.sin(2.0 * Math.PI * (plan.femaleVoice ? 860.0 : 610.0) * t) * 0.035;
        return (voice + formant) * env;
    }

    private static double choirPad(double t, double chord, SongPlan plan) {
        double freq = plan.root * chord * (plan.femaleVoice ? 2.0 : 1.0);
        double slow = 0.55 + 0.45 * Math.sin(2.0 * Math.PI * 0.07 * t + 0.5);
        return (sine(freq, t) + sine(freq * 1.25, t) * 0.7 + sine(freq * 1.5, t) * 0.55) * 0.10 * slow;
    }

    private static double sine(double f, double t) { return Math.sin(2.0 * Math.PI * f * t); }
    private static double softClip(double x) { return Math.tanh(x); }

    private static double noise(long x) {
        long n = (x << 13) ^ x;
        return 1.0 - ((n * (n * n * 15731L + 789221L) + 1376312589L) & 0x7fffffff) / 1073741824.0;
    }

    private static class SongPlan {
        final String text;
        final String mood;
        final int hash;
        final double beatSeconds;
        final double root;
        final double[] scale;
        final double[] chords;
        final double masterGain;
        final double drive;
        final double targetPeak;
        final boolean instrumentFolkGuitar;
        final boolean instrumentClassicGuitar;
        final boolean instrumentElectricGuitar;
        final boolean instrumentPiano;
        final boolean instrumentBass;
        final boolean instrumentDrums;
        final boolean instrumentPercussion;
        final boolean instrumentStrings;
        final boolean hasVoiceGuide;
        final boolean hasChoir;
        final boolean femaleVoice;
        final double voiceGain;
        final double durationSeconds;

        SongPlan(String text, ProjectOptions options) {
            this.text = text.toLowerCase(Locale.ROOT);
            this.hash = Math.abs(this.text.hashCode());
            this.mood = options.textSongMood == null ? "" : options.textSongMood;
            String key = options.textSongKey == null ? "" : options.textSongKey;
            String voice = options.textVoiceType == null ? "" : options.textVoiceType;
            this.femaleVoice = voice.contains("femme") || voice.contains("Femme");
            this.hasVoiceGuide = !voice.contains("Instrumental");
            this.hasChoir = this.hasVoiceGuide && !voice.contains("Ma voix");
            this.voiceGain = voice.contains("Ma voix") ? 0.18 : 0.34;
            this.instrumentFolkGuitar = options.instrumentFolkGuitar;
            this.instrumentClassicGuitar = options.instrumentClassicGuitar;
            this.instrumentElectricGuitar = options.instrumentElectricGuitar;
            this.instrumentPiano = options.instrumentPiano;
            this.instrumentBass = options.instrumentBass;
            this.instrumentDrums = options.instrumentDrums;
            this.instrumentPercussion = options.instrumentPercussion;
            this.instrumentStrings = options.instrumentStrings;
            this.durationSeconds = Math.max(8.0, options.textSongDurationUs() / 1_000_000.0);

            int tempo = 86 + (hash % 22);
            if (mood.contains("Rap")) tempo = 94 + (hash % 16);
            if (mood.contains("Reggae")) tempo = 74 + (hash % 14);
            if (mood.contains("Ballade")) tempo = 68 + (hash % 12);
            if (mood.contains("Émotion")) tempo = 70 + (hash % 16);
            if (mood.contains("Dance")) tempo = 116 + (hash % 16);
            if (mood.contains("Rock")) tempo = 100 + (hash % 18);
            this.beatSeconds = 60.0 / tempo;

            double selectedRoot = 246.94;
            if (key.contains("Do majeur")) selectedRoot = 261.63;
            else if (key.contains("Ré majeur")) selectedRoot = 293.66;
            else if (key.contains("Mi majeur")) selectedRoot = 329.63;
            else if (key.contains("Fa majeur")) selectedRoot = 349.23;
            else if (key.contains("Sol majeur")) selectedRoot = 392.00;
            else if (key.contains("La majeur") || key.contains("La mineur")) selectedRoot = 220.00;
            else if (key.contains("Mi mineur")) selectedRoot = 164.81;
            else if (key.contains("Ré mineur")) selectedRoot = 293.66;
            else if (mood.contains("Émotion") || mood.contains("Ballade")) selectedRoot = 220.0;
            else if (mood.contains("Dance")) selectedRoot = 261.63;
            this.root = selectedRoot;

            if (mood.contains("Émotion") || mood.contains("Ballade") || key.contains("mineur")) {
                this.scale = new double[]{1.0, 1.122, 1.189, 1.335, 1.498, 1.587, 1.782, 2.0};
                this.chords = new double[]{1.0, 1.335, 1.498, 1.122};
            } else if (mood.contains("Rap")) {
                this.scale = new double[]{1.0, 1.122, 1.335, 1.498, 1.682, 2.0};
                this.chords = new double[]{1.0, 1.0, 1.335, 1.122};
            } else if (mood.contains("Reggae")) {
                this.scale = new double[]{1.0, 1.125, 1.25, 1.333, 1.5, 1.667, 1.875, 2.0};
                this.chords = new double[]{1.0, 1.333, 1.5, 1.25};
            } else {
                this.scale = new double[]{1.0, 1.125, 1.25, 1.333, 1.5, 1.667, 1.875, 2.0};
                this.chords = new double[]{1.0, 1.25, 1.5, 1.333};
            }
            this.masterGain = options.masterPreset.contains("Radio") ? 0.82 : (options.masterPreset.contains("Doux") ? 0.66 : 0.74);
            this.drive = options.masterPreset.contains("Radio") ? 1.45 : (options.masterPreset.contains("Rap") ? 1.35 : 1.12);
            this.targetPeak = options.targetPeak();
        }

        int noteSeed(int beatIndex) {
            if (text.length() == 0) return beatIndex;
            char c = text.charAt(Math.abs(beatIndex * 5 + hash) % text.length());
            return Math.abs(c + beatIndex + hash) % 97;
        }
    }
}
