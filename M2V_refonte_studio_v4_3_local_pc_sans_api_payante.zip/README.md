# Music2Video Free Studio V4.3 — local + PC, sans API payante

Cette version consolide la V4/V4.2 et retire les anciennes options qui parlaient de services cloud ou d'API payantes.

## Règle principale

- Aucune redirection vers une API payante.
- Aucune clé payante intégrée.
- Aucun lancement de service cloud payant.
- Les fonctions lourdes doivent passer par Android local ou par un futur **Music2Video PC Companion** installé sur le PC de l'utilisateur.

## Ce qui reste intégré côté Android

- Interface compacte avec aides dépliables.
- Texte → Vidéo avec clavier, paroles structurées et boucle instrumentale locale.
- Lecteurs audio/vidéo intégrés.
- Import multi-images avec miniatures.
- Sources libres : Pexels, Pixabay, Jamendo, Freesound.
- Studio correction avec vignettes timecodées.
- Remplacement sécurisé par timecode.
- Verrous par défaut : qualité source, motion source, ambiance originale, durée originale, pas de zoom/recadrage.
- Export MP4 local qualité source, 720p, 1080p ou 4K selon capacité du téléphone.
- Bouton partager / télécharger après export.
- Fusion vidéo dans vidéo / chanteur intégré.
- Ancien smiley lip-sync supprimé.

## Nouveau : moteur PC local

La section **Moteur PC local / open source** prépare la connexion à un futur compagnon PC.

Le téléphone sert de studio mobile. Le PC fera les traitements lourds :

- rendu 4K plus fiable ;
- upscale IA local avec Real-ESRGAN ou équivalent ;
- interpolation de mouvement RIFE ;
- lip-sync SadTalker/Wav2Lip ;
- génération musicale MusicGen/AudioCraft ;
- workflows ComfyUI ;
- rendu final plus rapide.

Tout cela est prévu comme **local/open source**, pas comme API payante.

## Build Android

Le workflow GitHub doit décompresser ce ZIP puis construire l'APK debug.
