package com.entilio.music2videofree;

public class ProjectOptions {
    public int width = 720;
    public int height = 1280;
    public int fps = 24;
    public int bitrate = 4_500_000;
    public int maxSeconds = 20;
    public boolean testMode = false;
    // Ancien avatar/smiley supprimé. Conservé à false pour compatibilité interne.
    public boolean simpleLipSync = false;

    public String format = "TikTok / Reels 9:16";
    public String style = "Cinématique sombre";
    public String motion = "Ken Burns";
    public String visualizer = "Minimal";
    public String exportQuality = "Qualité source / auto";
    public String correctionPreset = "Préserver original — copie non destructive";

    // Correction vidéo / remplacement d'images.
    public String replacementMode = "Garder la vidéo originale";
    public String replacementMotion = "Conserver motion source / aucun zoom";
    public boolean lockSourceQuality = true;
    public boolean lockSourceMotion = true;
    public boolean noCropZoom = true;
    public boolean preserveOriginalAmbience = true;
    public boolean preserveOriginalDuration = true;
    public long replacementStartTimeUs = 0L;
    public long replacementSegmentDurationUs = 4_500_000L;

    // Vidéo dans vidéo / fusion chanteur.
    public String fusionMode = "Incrustation picture-in-picture";
    public String fusionPosition = "Bas droite";
    public boolean fusionChromaKey = false;
    public boolean fusionFeather = true;
    public boolean fusionSyncAudio = true;
    public long fusionStartTimeUs = 0L;
    public long fusionDurationUs = 20_000_000L;

    // Création film guidé.
    public String characterPreset = "Personnage seul";
    public String environmentPreset = "Village portugais ancien";
    public String filmPrompt = "";

    // Texte -> vidéo / texte -> song.
    public String textPrompt = "";
    public String textSongMood = "Pop cinématique";
    public int textVideoSeconds = 24;
    public int songSeconds = 35;

    // Studio audio : mixage / mastering.
    public String mixPreset = "Équilibré";
    public String masterPreset = "Streaming propre";
    public float mixLeadGain = 1.0f;
    public float mixInstrumentalGain = 0.82f;
    public float mixFxGain = 0.45f;
    public int fadeInMs = 500;
    public int fadeOutMs = 1400;
    public boolean autoNormalize = true;
    public boolean limiterEnabled = true;

    // Moteur PC local / IA open source.
    // Aucune API payante/cloud n'est proposée dans cette version.
    public boolean usePcLocalEngine = false;
    public String pcEngineAddress = "http://192.168.1.10:7860";

    public boolean hasImageReplacement() {
        return replacementMode != null && !replacementMode.startsWith("Garder") && !replacementMode.startsWith("Aucun");
    }

    public boolean shouldReplaceAllScenes() {
        return replacementMode != null && replacementMode.toLowerCase().contains("toute");
    }

    public boolean shouldAlternateReplacement() {
        return replacementMode != null && replacementMode.contains("Alterner");
    }

    public boolean shouldUseTimecodedReplacement() {
        return replacementMode != null && replacementMode.toLowerCase().contains("timecode");
    }

    public long maxDurationUs(long fullDurationUs) {
        if (fullDurationUs <= 0) fullDurationUs = maxSeconds * 1_000_000L;
        if (testMode) {
            return Math.min(fullDurationUs, maxSeconds * 1_000_000L);
        }
        return fullDurationUs;
    }

    public long textVideoDurationUs() {
        int seconds = testMode ? Math.min(textVideoSeconds, maxSeconds) : textVideoSeconds;
        return Math.max(5, seconds) * 1_000_000L;
    }

    public long textSongDurationUs() {
        int seconds = testMode ? Math.min(songSeconds, maxSeconds) : songSeconds;
        return Math.max(8, seconds) * 1_000_000L;
    }

    public float compressionThreshold() {
        String p = masterPreset == null ? "" : masterPreset;
        if (p.contains("Radio") || p.contains("Rap")) return 0.52f;
        if (p.contains("Cinéma")) return 0.62f;
        if (p.contains("Doux")) return 0.72f;
        return 0.60f;
    }

    public float compressionRatio() {
        String p = masterPreset == null ? "" : masterPreset;
        if (p.contains("Radio")) return 4.2f;
        if (p.contains("Rap")) return 3.4f;
        if (p.contains("Cinéma")) return 2.4f;
        if (p.contains("Doux")) return 1.8f;
        return 2.7f;
    }

    public float targetPeak() {
        String p = masterPreset == null ? "" : masterPreset;
        if (p.contains("Radio")) return 0.96f;
        if (p.contains("Rap")) return 0.95f;
        if (p.contains("Cinéma")) return 0.90f;
        if (p.contains("Doux")) return 0.86f;
        return 0.92f;
    }

    public float saturationDrive() {
        String p = masterPreset == null ? "" : masterPreset;
        if (p.contains("Radio")) return 1.55f;
        if (p.contains("Rap")) return 1.38f;
        if (p.contains("Cinéma")) return 1.12f;
        if (p.contains("Doux")) return 0.95f;
        return 1.18f;
    }
}
