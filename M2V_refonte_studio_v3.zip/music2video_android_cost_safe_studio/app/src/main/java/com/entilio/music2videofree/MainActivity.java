package com.entilio.music2videofree;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_IMAGES = 1002;
    private static final int REQ_CORRECTION_VIDEO = 1003;
    private static final int REQ_CORRECTION_AUDIO = 1004;
    private static final int REQ_REPLACEMENT_IMAGES = 1005;
    private static final int REQ_TEXT_AUDIO = 1006;

    private Uri audioUri;
    private Uri textAudioUri;
    private Uri videoToCorrectUri;
    private Uri correctionAudioUri;
    private Uri lastOutputUri;

    private final ArrayList<Uri> imageUris = new ArrayList<>();
    private final ArrayList<Uri> replacementImageUris = new ArrayList<>();

    private LinearLayout modeContainer;
    private LinearLayout outputBox;
    private TextView statusText;
    private TextView songSelectionText;
    private TextView textSelectionText;
    private TextView correctionSelectionText;
    private TextView outputText;
    private ProgressBar progressBar;
    private VideoView sourceVideoPreview;
    private VideoView outputVideoPreview;

    private Spinner formatSpinner;
    private Spinner exportQualitySpinner;
    private Spinner styleSpinner;
    private Spinner motionSpinner;
    private Spinner visualizerSpinner;
    private Spinner correctionSpinner;
    private Spinner replacementModeSpinner;
    private Spinner replacementMotionSpinner;
    private Spinner textDurationSpinner;
    private Spinner aiCostSpinner;

    private EditText songStoryEdit;
    private EditText textPromptEdit;

    private CheckBox lipSyncCheck;
    private CheckBox testModeCheck;
    private CheckBox useReplacementAudioCheck;
    private CheckBox blockPaidOptionsCheck;
    private CheckBox lockSourceQualityCheck;
    private CheckBox lockSourceMotionCheck;
    private CheckBox noCropZoomCheck;

    private EditText replacementStartTimeEdit;
    private EditText replacementPlanSecondsEdit;
    private TextView timelineText;
    private TextView libraryText;
    private TextView homeLibraryText;
    private TextView autoPromptText;

    private Button songGenerateButton;
    private Button textGenerateButton;
    private Button correctionGenerateButton;
    private Button openButton;
    private TextView costSafetyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 17, 22));
        getWindow().setNavigationBarColor(Color.rgb(16, 17, 22));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16, 17, 22));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Music2Video Free Studio V3");
        title.setTextColor(Color.rgb(244, 241, 232));
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(4), 0, dp(6));
        root.addView(title);

        TextView subtitle = smallText("Studio local gratuit : vos fichiers restent sur le téléphone. L'original n'est jamais remplacé ; chaque rendu crée une nouvelle vidéo MP4 dans la galerie.");
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        root.addView(tabs);

        Button homeTab = tabButton("Accueil");
        Button songTab = tabButton("Chanson");
        Button textTab = tabButton("Texte");
        Button correctionTab = tabButton("Correction");
        tabs.addView(homeTab);
        tabs.addView(songTab);
        tabs.addView(textTab);
        tabs.addView(correctionTab);
        homeTab.setOnClickListener(v -> showHomeMode());
        songTab.setOnClickListener(v -> showSongMode());
        textTab.setOnClickListener(v -> showTextMode());
        correctionTab.setOnClickListener(v -> showCorrectionMode());

        modeContainer = new LinearLayout(this);
        modeContainer.setOrientation(LinearLayout.VERTICAL);
        modeContainer.setPadding(0, dp(8), 0, dp(8));
        root.addView(modeContainer);

        buildProgressAndOutput(root);
        buildCostSafety(root);
        showHomeMode();
        setContentView(scroll);
    }

    private void buildProgressAndOutput(LinearLayout root) {
        root.addView(sectionTitle("Progression et résultat"));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.VISIBLE);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(16));
        barParams.setMargins(0, dp(8), 0, dp(8));
        root.addView(progressBar, barParams);

        statusText = smallText("Prêt. Choisissez un mode ci-dessus.");
        root.addView(statusText);

        outputBox = card();
        outputBox.setVisibility(View.GONE);
        outputText = smallText("Aucune vidéo exportée pour le moment.");
        outputBox.addView(outputText);
        outputVideoPreview = new VideoView(this);
        outputBox.addView(outputVideoPreview, videoLayoutParams());
        openButton = secondaryButton("Ouvrir la dernière vidéo dans le lecteur du téléphone");
        openButton.setOnClickListener(v -> openLastVideo());
        outputBox.addView(openButton);
        root.addView(outputBox);
    }

    private void buildCostSafety(LinearLayout root) {
        root.addView(sectionTitle("Sécurité coûts / IA avancée"));
        TextView costIntro = smallText("Les fonctions cloud ou payantes restent verrouillées par défaut. Cette version ne contient aucune clé API et ne lance aucun paiement.");
        root.addView(costIntro);

        blockPaidOptionsCheck = new CheckBox(this);
        blockPaidOptionsCheck.setText("Bloquer toutes les options payantes/cloud — recommandé");
        blockPaidOptionsCheck.setTextColor(Color.rgb(244, 241, 232));
        blockPaidOptionsCheck.setChecked(true);
        root.addView(blockPaidOptionsCheck);

        root.addView(label("Option IA avancée à vérifier"));
        aiCostSpinner = spinner(CostPolicy.featureLabels());
        root.addView(aiCostSpinner);

        Button explainCostButton = secondaryButton("Voir coût, risque et alternative gratuite");
        explainCostButton.setOnClickListener(v -> showAiCostDialog(false));
        root.addView(explainCostButton);

        Button guardedLaunchButton = secondaryButton("Tester le verrouillage avant option payante");
        guardedLaunchButton.setOnClickListener(v -> showAiCostDialog(true));
        root.addView(guardedLaunchButton);

        costSafetyText = smallText("Statut : mode gratuit/offline. Aucune option payante n'est autorisée.");
        root.addView(costSafetyText);
    }

    private void showHomeMode() {
        modeContainer.removeAllViews();
        LinearLayout hero = premiumCard();
        TextView h1 = sectionTitle("Accueil studio moderne");
        TextView h2 = smallText("Tableau de bord local : derniers rendus, accès rapide, bibliothèque par catégorie et retour direct vers correction/timeline. L'original reste toujours protégé.");
        hero.addView(h1);
        hero.addView(h2);
        modeContainer.addView(hero);

        LinearLayout grid1 = new LinearLayout(this);
        grid1.setOrientation(LinearLayout.HORIZONTAL);
        modeContainer.addView(grid1);
        grid1.addView(dashboardCard("🎬", "Vidéos", "Derniers exports MP4", v -> openLastVideo()));
        grid1.addView(dashboardCard("🎵", "Musiques", "Sources audio", v -> showSongMode()));

        LinearLayout grid2 = new LinearLayout(this);
        grid2.setOrientation(LinearLayout.HORIZONTAL);
        modeContainer.addView(grid2);
        grid2.addView(dashboardCard("🖼", "Images", "Plans et photos", v -> showCorrectionMode()));
        grid2.addView(dashboardCard("🕒", "Timecode", "Studio multipiste", v -> showCorrectionMode()));

        homeLibraryText = smallText(
                "Bibliothèque locale prévue en accès direct :\n" +
                "• vidéos créées par chanson ;\n" +
                "• vidéos créées par texte ;\n" +
                "• corrections non destructives ;\n" +
                "• musiques, images et séquences classées par catégorie.\n\n" +
                "Dans cette version, le bouton ci-dessous ouvre la dernière vidéo exportée pendant la session. Les prochains rendus restent dans Galerie > Movies > Music2VideoFree.");
        modeContainer.addView(fileCard("Bibliothèque / dernières créations", homeLibraryText));

        Button openLast = primaryButton("Ouvrir la dernière vidéo créée");
        openLast.setOnClickListener(v -> openLastVideo());
        modeContainer.addView(openLast);

        Button qSong = secondaryButton("Créer depuis une chanson");
        qSong.setOnClickListener(v -> showSongMode());
        Button qText = secondaryButton("Créer depuis un texte");
        qText.setOnClickListener(v -> showTextMode());
        Button qCorrection = secondaryButton("Studio correction / timeline multipiste");
        qCorrection.setOnClickListener(v -> showCorrectionMode());
        modeContainer.addView(qSong);
        modeContainer.addView(qText);
        modeContainer.addView(qCorrection);
    }

    private void showSongMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Créer une vidéo depuis une chanson"));
        modeContainer.addView(smallText("Importez la chanson, ajoutez des images si vous en avez, puis exportez une vidéo de la durée complète de la musique. Le mode 20 secondes est désactivé par défaut."));

        Button pickAudio = primaryButton("Choisir la musique");
        pickAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_AUDIO));
        modeContainer.addView(pickAudio);

        Button addImages = secondaryButton("Ajouter des images pour la vidéo");
        addImages.setOnClickListener(v -> pickMultiple("image/*", REQ_IMAGES));
        modeContainer.addView(addImages);

        LinearLayout fileActions = new LinearLayout(this);
        fileActions.setOrientation(LinearLayout.HORIZONTAL);
        Button openAudio = compactButton("Écouter");
        openAudio.setOnClickListener(v -> openUri(audioUri, "audio/*"));
        Button clearSong = compactButton("Supprimer fichiers");
        clearSong.setOnClickListener(v -> { audioUri = null; imageUris.clear(); updateSongSelectionText(); });
        fileActions.addView(openAudio);
        fileActions.addView(clearSong);
        modeContainer.addView(fileActions);

        songSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers importés", songSelectionText));
        updateSongSelectionText();

        modeContainer.addView(label("Histoire ou intention visuelle"));
        songStoryEdit = editText("Exemple : clip cinématographique noir et blanc dans un village portugais, scènes cohérentes avec la chanson, sans texte à l'écran…", 4);
        modeContainer.addView(songStoryEdit);

        LinearLayout promptCard = fileCard("Prompt automatique musique → vidéo", smallText("Générez une base de storyboard automatiquement, puis ajustez-la avant l'export. Aucun texte n'est incrusté dans la vidéo sauf si vous l'écrivez explicitement."));
        autoPromptText = smallText("Prompt auto : non généré.");
        promptCard.addView(autoPromptText);
        modeContainer.addView(promptCard);
        Button autoPromptButton = secondaryButton("✨ Remplir un prompt automatique cinématographique");
        autoPromptButton.setOnClickListener(v -> fillAutomaticSongPrompt());
        modeContainer.addView(autoPromptButton);
        Button promptHelp = secondaryButton("? Aide : comment utiliser le prompt automatique");
        promptHelp.setOnClickListener(v -> showPromptHelpDialog());
        modeContainer.addView(promptHelp);

        addCommonVideoControls(modeContainer);

        lipSyncCheck = new CheckBox(this);
        lipSyncCheck.setText("Ajouter un avatar lip-sync simple / smiley — désactivé par défaut");
        lipSyncCheck.setTextColor(Color.rgb(244, 241, 232));
        lipSyncCheck.setChecked(false);
        modeContainer.addView(lipSyncCheck);

        addTestModeCheck(modeContainer);

        songGenerateButton = primaryButton("Générer la vidéo MP4 complète");
        songGenerateButton.setOnClickListener(v -> startSongRender());
        modeContainer.addView(songGenerateButton);
    }

    private void showTextMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Créer une vidéo depuis un texte"));
        modeContainer.addView(smallText("Écrivez une scène, un poème, un synopsis ou un storyboard. L'application crée des scènes animées locales, puis ajoute une musique optionnelle si vous en choisissez une."));

        textPromptEdit = editText("Écrivez votre histoire ou vos scènes ici…", 7);
        modeContainer.addView(textPromptEdit);

        Button pickTextAudio = secondaryButton("Ajouter une musique optionnelle");
        pickTextAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_TEXT_AUDIO));
        modeContainer.addView(pickTextAudio);

        Button clearTextAudio = secondaryButton("Supprimer la musique du mode texte");
        clearTextAudio.setOnClickListener(v -> { textAudioUri = null; updateTextSelectionText(); });
        modeContainer.addView(clearTextAudio);

        textSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers du mode texte", textSelectionText));
        updateTextSelectionText();

        modeContainer.addView(label("Durée si aucune musique n'est ajoutée"));
        textDurationSpinner = spinner(new String[]{"15 secondes", "30 secondes", "60 secondes", "90 secondes", "2 minutes", "3 minutes", "4 minutes", "Durée libre via musique"});
        modeContainer.addView(textDurationSpinner);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        textGenerateButton = primaryButton("Créer la vidéo depuis le texte");
        textGenerateButton.setOnClickListener(v -> startTextRender());
        modeContainer.addView(textGenerateButton);
    }

    private void showCorrectionMode() {
        modeContainer.removeAllViews();
        modeContainer.addView(sectionTitle("Corriger / améliorer une vidéo existante"));
        modeContainer.addView(smallText("Mode non destructif : la vidéo originale reste intacte. Importez une vidéo déjà créée, placez vos images au timecode exact, verrouillez la qualité et conservez la motion source."));

        Button pickVideo = primaryButton("Importer vidéo / clip dans le studio multipiste");
        pickVideo.setOnClickListener(v -> pickSingle("video/*", REQ_CORRECTION_VIDEO));
        modeContainer.addView(pickVideo);

        sourceVideoPreview = new VideoView(this);
        sourceVideoPreview.setVisibility(videoToCorrectUri == null ? View.GONE : View.VISIBLE);
        modeContainer.addView(sourceVideoPreview, videoLayoutParams());
        if (videoToCorrectUri != null) prepareVideoPreview(sourceVideoPreview, videoToCorrectUri, false);

        Button pickReplacementImages = secondaryButton("Ajouter image(s) de remplacement optionnelle(s)");
        pickReplacementImages.setOnClickListener(v -> pickMultiple("image/*", REQ_REPLACEMENT_IMAGES));
        modeContainer.addView(pickReplacementImages);

        Button pickCorrectionAudio = secondaryButton("Ajouter nouvelle musique optionnelle");
        pickCorrectionAudio.setOnClickListener(v -> pickSingle("audio/*", REQ_CORRECTION_AUDIO));
        modeContainer.addView(pickCorrectionAudio);

        Button clearCorrectionFiles = secondaryButton("Supprimer les fichiers de correction sélectionnés");
        clearCorrectionFiles.setOnClickListener(v -> {
            videoToCorrectUri = null;
            correctionAudioUri = null;
            replacementImageUris.clear();
            if (useReplacementAudioCheck != null) useReplacementAudioCheck.setChecked(false);
            updateCorrectionSelectionText();
            showCorrectionMode();
        });
        modeContainer.addView(clearCorrectionFiles);

        correctionSelectionText = smallText("");
        modeContainer.addView(fileCard("Fichiers importés pour correction", correctionSelectionText));
        updateCorrectionSelectionText();

        buildTimelineEditor(modeContainer);

        modeContainer.addView(label("Type de correction"));
        correctionSpinner = spinner(new String[]{
                "Préserver original — copie non destructive",
                "Montage timecodé sans altérer source",
                "Auto léger sans détruire",
                "Éclaircir",
                "Contraste fort",
                "Couleurs douces",
                "Noir et blanc cinéma",
                "Stabilisation visuelle légère"
        });
        modeContainer.addView(correctionSpinner);

        modeContainer.addView(label("Remplacement d'image"));
        replacementModeSpinner = spinner(new String[]{
                "Garder la vidéo originale",
                "Remplacer scènes au timecode",
                "Remplacer quelques scènes par les images",
                "Alterner vidéo originale et images",
                "Remplacer toute la vidéo par les images"
        });
        modeContainer.addView(replacementModeSpinner);

        modeContainer.addView(label("Motion des images remplacées"));
        replacementMotionSpinner = spinner(new String[]{
                "Conserver motion source / aucun zoom",
                "Image fixe timecodée",
                "Garder motion similaire",
                "Motion corrigée douce",
                "Motion dynamique",
                "Motion pulse audio"
        });
        modeContainer.addView(replacementMotionSpinner);
        Button motionHelp = secondaryButton("? Expliquer les motions et le verrouillage");
        motionHelp.setOnClickListener(v -> showMotionHelpDialog());
        modeContainer.addView(motionHelp);

        useReplacementAudioCheck = new CheckBox(this);
        useReplacementAudioCheck.setText("Remplacer l'audio par la nouvelle musique sélectionnée");
        useReplacementAudioCheck.setTextColor(Color.rgb(244, 241, 232));
        useReplacementAudioCheck.setChecked(false);
        modeContainer.addView(useReplacementAudioCheck);

        addCommonVideoControls(modeContainer);
        addTestModeCheck(modeContainer);

        correctionGenerateButton = primaryButton("Créer une copie corrigée");
        correctionGenerateButton.setOnClickListener(v -> startVideoCorrection());
        modeContainer.addView(correctionGenerateButton);
    }

    private void addCommonVideoControls(LinearLayout parent) {
        parent.addView(label("Format d'export"));
        formatSpinner = spinner(new String[]{"YouTube 16:9", "TikTok / Reels 9:16", "Carré 1:1"});
        parent.addView(formatSpinner);

        parent.addView(label("Qualité d'export"));
        exportQualitySpinner = spinner(new String[]{"Qualité source / auto", "720p HD", "1080p Full HD", "4K UHD", "Garder qualité source si vidéo importée"});
        parent.addView(exportQualitySpinner);
        Button qualityHelp = secondaryButton("? Expliquer 720p / 1080p / 4K / qualité source");
        qualityHelp.setOnClickListener(v -> showQualityHelpDialog());
        parent.addView(qualityHelp);

        parent.addView(label("Ambiance visuelle"));
        styleSpinner = spinner(new String[]{"Cinématique sombre", "Rêve lumineux", "Nature douce", "Sport chic", "Abstrait néon"});
        parent.addView(styleSpinner);

        parent.addView(label("Motion"));
        motionSpinner = spinner(new String[]{"Conserver motion source", "Ken Burns", "Slide dynamique", "Pulse audio", "Rotation douce", "Shake dramatique", "Image fixe sans mouvement"});
        parent.addView(motionSpinner);
        Button commonMotionHelp = secondaryButton("? Quelle motion choisir ?");
        commonMotionHelp.setOnClickListener(v -> showSelectedMotionHelpDialog());
        parent.addView(commonMotionHelp);

        parent.addView(label("Visualiseur audio"));
        visualizerSpinner = spinner(new String[]{"Minimal", "Barres audio", "Anneau audio"});
        parent.addView(visualizerSpinner);
    }

    private void buildTimelineEditor(LinearLayout parent) {
        parent.addView(sectionTitle("Studio d'arrangement multipiste / timecode"));
        parent.addView(smallText("Placez chaque photo avec un timecode précis. La piste vidéo source reste verrouillée par défaut pour éviter toute perte de qualité ou changement de motion."));

        lockSourceQualityCheck = new CheckBox(this);
        lockSourceQualityCheck.setText("Verrouiller qualité source — recommandé");
        lockSourceQualityCheck.setTextColor(Color.rgb(244, 241, 232));
        lockSourceQualityCheck.setChecked(true);
        parent.addView(lockSourceQualityCheck);

        lockSourceMotionCheck = new CheckBox(this);
        lockSourceMotionCheck.setText("Verrouiller motion originale de la vidéo");
        lockSourceMotionCheck.setTextColor(Color.rgb(244, 241, 232));
        lockSourceMotionCheck.setChecked(true);
        parent.addView(lockSourceMotionCheck);

        noCropZoomCheck = new CheckBox(this);
        noCropZoomCheck.setText("Ne pas recadrer / ne pas zoomer la vidéo source");
        noCropZoomCheck.setTextColor(Color.rgb(244, 241, 232));
        noCropZoomCheck.setChecked(true);
        parent.addView(noCropZoomCheck);

        parent.addView(label("Timecode de départ du premier remplacement"));
        replacementStartTimeEdit = editText("00:00:00.000", 1);
        replacementStartTimeEdit.setText("00:00:00.000");
        parent.addView(replacementStartTimeEdit);

        LinearLayout timeAdjust = new LinearLayout(this);
        timeAdjust.setOrientation(LinearLayout.HORIZONTAL);
        Button minusHalf = compactButton("-0,5 s");
        minusHalf.setOnClickListener(v -> adjustReplacementStart(-0.5));
        Button plusHalf = compactButton("+0,5 s");
        plusHalf.setOnClickListener(v -> adjustReplacementStart(0.5));
        timeAdjust.addView(minusHalf);
        timeAdjust.addView(plusHalf);
        parent.addView(timeAdjust);
        Button seekTime = secondaryButton("Aller au timecode dans l'aperçu source");
        seekTime.setOnClickListener(v -> seekSourcePreviewToReplacementStart());
        parent.addView(seekTime);

        parent.addView(label("Durée de chaque photo / séquence de photos"));
        replacementPlanSecondsEdit = editText("4.5 secondes", 1);
        replacementPlanSecondsEdit.setText("4.5");
        parent.addView(replacementPlanSecondsEdit);

        Button recalc = secondaryButton("Recalculer / afficher les timecodes des photos");
        recalc.setOnClickListener(v -> updateTimelineText());
        parent.addView(recalc);
        Button validate = secondaryButton("Valider le placement sécurisé");
        validate.setOnClickListener(v -> validateSafePlacement());
        parent.addView(validate);

        Button help = secondaryButton("? Aide timecode : placer une image sans erreur");
        help.setOnClickListener(v -> showTimecodeHelpDialog());
        parent.addView(help);

        timelineText = smallText("");
        parent.addView(fileCard("Timeline des photos et séquences", timelineText));
        updateTimelineText();
    }

    private void addTestModeCheck(LinearLayout parent) {
        testModeCheck = new CheckBox(this);
        testModeCheck.setText("Mode test : limiter à 20 secondes — désactivé par défaut");
        testModeCheck.setTextColor(Color.rgb(244, 241, 232));
        testModeCheck.setChecked(false);
        parent.addView(testModeCheck);
    }

    private void pickSingle(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    private void pickMultiple(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        final int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;

        if (requestCode == REQ_AUDIO && data.getData() != null) {
            audioUri = data.getData();
            persistReadPermission(audioUri, flags);
            updateSongSelectionText();
        } else if (requestCode == REQ_TEXT_AUDIO && data.getData() != null) {
            textAudioUri = data.getData();
            persistReadPermission(textAudioUri, flags);
            updateTextSelectionText();
        } else if (requestCode == REQ_IMAGES) {
            addReturnedUris(data, imageUris, flags);
            updateSongSelectionText();
        } else if (requestCode == REQ_REPLACEMENT_IMAGES) {
            addReturnedUris(data, replacementImageUris, flags);
            updateCorrectionSelectionText();
        } else if (requestCode == REQ_CORRECTION_VIDEO && data.getData() != null) {
            videoToCorrectUri = data.getData();
            persistReadPermission(videoToCorrectUri, flags);
            updateCorrectionSelectionText();
            showCorrectionMode();
        } else if (requestCode == REQ_CORRECTION_AUDIO && data.getData() != null) {
            correctionAudioUri = data.getData();
            persistReadPermission(correctionAudioUri, flags);
            if (useReplacementAudioCheck != null) useReplacementAudioCheck.setChecked(true);
            updateCorrectionSelectionText();
        }
    }

    private void addReturnedUris(Intent data, ArrayList<Uri> list, int flags) {
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < count; i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                list.add(uri);
                persistReadPermission(uri, flags);
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            list.add(uri);
            persistReadPermission(uri, flags);
        }
    }

    private void persistReadPermission(Uri uri, int flags) {
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
    }

    private void updateSongSelectionText() {
        if (songSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Musique : ").append(describeMedia(audioUri)).append("\n");
        sb.append("Images : ").append(imageUris.size()).append(imageUris.isEmpty() ? "" : " image(s) sélectionnée(s)").append("\n");
        if (!imageUris.isEmpty()) sb.append("Première image : ").append(nameOf(imageUris.get(0))).append("\n");
        sb.append("Contrôle : vous pouvez écouter la musique, supprimer les fichiers et relancer un import.");
        songSelectionText.setText(sb.toString());
    }

    private void updateTextSelectionText() {
        if (textSelectionText == null) return;
        textSelectionText.setText("Musique optionnelle : " + describeMedia(textAudioUri));
    }

    private void updateCorrectionSelectionText() {
        if (correctionSelectionText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Vidéo originale : ").append(describeMedia(videoToCorrectUri)).append("\n");
        sb.append("Images de remplacement : ").append(replacementImageUris.size()).append("\n");
        sb.append("Nouvelle musique : ").append(describeMedia(correctionAudioUri)).append("\n");
        sb.append("Règle : la vidéo source reste intacte ; l'export crée une nouvelle copie.");
        correctionSelectionText.setText(sb.toString());
        updateTimelineText();
    }

    private void startSongRender() {
        if (audioUri == null) {
            Toast.makeText(this, "Choisissez d'abord une musique.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageUris.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Aucune image ajoutée")
                    .setMessage("Sans images importées, le rendu local sera abstrait. Pour obtenir une histoire réaliste, ajoutez vos photos/images ou utilisez plus tard un module IA visuel explicitement activé.")
                    .setPositiveButton("Continuer", (d, w) -> renderSongNow())
                    .setNegativeButton("Ajouter des images", null)
                    .show();
        } else {
            renderSongNow();
        }
    }

    private void renderSongNow() {
        ProjectOptions options = readOptions();
        String story = songStoryEdit == null || songStoryEdit.getText() == null ? "" : songStoryEdit.getText().toString().trim();
        options.filmPrompt = story;
        setBusy(true, "Préparation de la vidéo depuis la chanson…");
        List<Uri> images = new ArrayList<>(imageUris);
        new Thread(() -> {
            try {
                Uri output = VideoComposer.compose(MainActivity.this, audioUri, images, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startTextRender() {
        String text = textPromptEdit == null || textPromptEdit.getText() == null ? "" : textPromptEdit.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "Écrivez d'abord un texte ou une histoire.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.textPrompt = text;
        options.textVideoSeconds = readTextSeconds();
        setBusy(true, "Préparation de la vidéo depuis le texte…");
        new Thread(() -> {
            try {
                Uri output = ImageVideoComposer.composeTextToVideo(MainActivity.this, text, textAudioUri, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Vidéo texte créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private void startVideoCorrection() {
        if (videoToCorrectUri == null) {
            Toast.makeText(this, "Choisissez d'abord une vidéo à corriger.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (useReplacementAudioCheck != null && useReplacementAudioCheck.isChecked() && correctionAudioUri == null) {
            Toast.makeText(this, "Choisissez une nouvelle musique ou décochez le remplacement audio.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectOptions options = readOptions();
        options.correctionPreset = correctionSpinner == null ? "Préserver original — copie non destructive" : String.valueOf(correctionSpinner.getSelectedItem());
        options.replacementMode = replacementModeSpinner == null ? "Garder la vidéo originale" : String.valueOf(replacementModeSpinner.getSelectedItem());
        options.replacementMotion = replacementMotionSpinner == null ? "Garder motion similaire" : String.valueOf(replacementMotionSpinner.getSelectedItem());
        Uri audioForCorrection = useReplacementAudioCheck != null && useReplacementAudioCheck.isChecked() ? correctionAudioUri : null;
        List<Uri> replacements = new ArrayList<>(replacementImageUris);

        setBusy(true, "Préparation de la copie corrigée…");
        new Thread(() -> {
            try {
                Uri output = VideoCorrector.correct(MainActivity.this, videoToCorrectUri, audioForCorrection, replacements, options, new UiProgress());
                runOnUiThread(() -> finishJob(output, "Copie corrigée créée dans Galerie > Movies > Music2VideoFree."));
            } catch (Exception e) {
                runOnUiThread(() -> failJob(e));
            }
        }).start();
    }

    private ProjectOptions readOptions() {
        ProjectOptions o = new ProjectOptions();
        o.format = formatSpinner == null ? "YouTube 16:9" : String.valueOf(formatSpinner.getSelectedItem());
        o.exportQuality = exportQualitySpinner == null ? "Qualité source / auto" : String.valueOf(exportQualitySpinner.getSelectedItem());
        o.style = styleSpinner == null ? "Cinématique sombre" : String.valueOf(styleSpinner.getSelectedItem());
        o.motion = motionSpinner == null ? "Ken Burns" : String.valueOf(motionSpinner.getSelectedItem());
        o.visualizer = visualizerSpinner == null ? "Minimal" : String.valueOf(visualizerSpinner.getSelectedItem());
        o.lockSourceQuality = lockSourceQualityCheck != null && lockSourceQualityCheck.isChecked();
        o.lockSourceMotion = lockSourceMotionCheck != null && lockSourceMotionCheck.isChecked();
        o.noCropZoom = noCropZoomCheck != null && noCropZoomCheck.isChecked();
        o.replacementStartTimeUs = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        o.replacementSegmentDurationUs = parseSecondsToUs(replacementPlanSecondsEdit == null ? "4.5" : replacementPlanSecondsEdit.getText().toString());
        o.simpleLipSync = lipSyncCheck != null && lipSyncCheck.isChecked();
        o.testMode = testModeCheck != null && testModeCheck.isChecked();
        o.blockPaidOptions = blockPaidOptionsCheck == null || blockPaidOptionsCheck.isChecked();
        o.allowCloudAi = !o.blockPaidOptions;
        o.requireExplicitCostConsent = true;
        if (aiCostSpinner != null) o.selectedAdvancedAiFeature = String.valueOf(aiCostSpinner.getSelectedItem());

        applyExportQuality(o);
        return o;
    }

    private void applyExportQuality(ProjectOptions o) {
        String q = o.exportQuality == null ? "" : o.exportQuality;
        boolean square = o.format != null && o.format.contains("1:1");
        boolean vertical = o.format != null && o.format.contains("9:16");

        int longSide = 1280;
        int shortSide = 720;
        int bitrate = 4_500_000;
        if (q.contains("1080")) { longSide = 1920; shortSide = 1080; bitrate = 9_000_000; }
        if (q.contains("4K")) { longSide = 3840; shortSide = 2160; bitrate = 35_000_000; }

        if ((q.contains("source") || q.contains("Source")) && videoToCorrectUri != null && o.lockSourceQuality) {
            int[] size = MediaMuxerTools.getVideoSize(this, videoToCorrectUri);
            if (size[0] > 0 && size[1] > 0) {
                o.width = size[0];
                o.height = size[1];
                o.bitrate = Math.max(6_000_000, Math.min(40_000_000, size[0] * size[1] * 4));
                return;
            }
        }

        if (square) {
            o.width = shortSide;
            o.height = shortSide;
        } else if (vertical) {
            o.width = shortSide;
            o.height = longSide;
        } else {
            o.width = longSide;
            o.height = shortSide;
        }
        o.bitrate = bitrate;
    }

    private int readTextSeconds() {
        String v = textDurationSpinner == null ? "30 secondes" : String.valueOf(textDurationSpinner.getSelectedItem());
        if (v.startsWith("15")) return 15;
        if (v.startsWith("60")) return 60;
        if (v.startsWith("90")) return 90;
        if (v.startsWith("2")) return 120;
        if (v.startsWith("3")) return 180;
        if (v.startsWith("4")) return 240;
        return 30;
    }

    private long parseTimecodeUs(String raw) {
        if (raw == null) return 0L;
        String s = raw.trim().replace(',', '.');
        if (s.isEmpty()) return 0L;
        try {
            String[] parts = s.split(":");
            double seconds;
            if (parts.length == 3) {
                seconds = Integer.parseInt(parts[0].trim()) * 3600.0 + Integer.parseInt(parts[1].trim()) * 60.0 + Double.parseDouble(parts[2].trim());
            } else if (parts.length == 2) {
                seconds = Integer.parseInt(parts[0].trim()) * 60.0 + Double.parseDouble(parts[1].trim());
            } else {
                seconds = Double.parseDouble(s);
            }
            return Math.max(0L, (long) (seconds * 1_000_000L));
        } catch (Exception e) {
            return 0L;
        }
    }

    private long parseSecondsToUs(String raw) {
        if (raw == null) return 4_500_000L;
        String s = raw.trim().replace(',', '.').replace("secondes", "").replace("seconde", "").replace("s", "").trim();
        try { return Math.max(500_000L, (long) (Double.parseDouble(s) * 1_000_000L)); }
        catch (Exception e) { return 4_500_000L; }
    }

    private String formatTimecode(long us) {
        long ms = Math.max(0L, us / 1000L);
        long h = ms / 3_600_000L;
        ms %= 3_600_000L;
        long m = ms / 60_000L;
        ms %= 60_000L;
        long sec = ms / 1000L;
        long milli = ms % 1000L;
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, sec, milli);
    }

    private void updateTimelineText() {
        if (timelineText == null) return;
        StringBuilder sb = new StringBuilder();
        long videoDuration = MediaMuxerTools.getDurationUs(this, videoToCorrectUri);
        sb.append("Piste 1 — vidéo source : ").append(describeMedia(videoToCorrectUri)).append("\n");
        if (videoDuration > 0) {
            sb.append("Timecode source : 00:00:00.000 → ").append(formatTimecode(videoDuration)).append("\n");
            sb.append("Repères rapides : ").append(buildRuler(videoDuration)).append("\n");
        } else {
            sb.append("Importez une vidéo : les timecodes apparaîtront automatiquement ici.\n");
        }
        sb.append("Verrous : qualité source ").append(lockSourceQualityCheck != null && lockSourceQualityCheck.isChecked() ? "ON" : "OFF")
                .append(" • motion source ").append(lockSourceMotionCheck != null && lockSourceMotionCheck.isChecked() ? "ON" : "OFF")
                .append(" • recadrage/zoom ").append(noCropZoomCheck != null && noCropZoomCheck.isChecked() ? "bloqué" : "autorisé").append("\n\n");
        long start = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        long seg = parseSecondsToUs(replacementPlanSecondsEdit == null ? "4.5" : replacementPlanSecondsEdit.getText().toString());
        if (replacementImageUris.isEmpty()) {
            sb.append("Piste 2 — images : aucune image de remplacement.\n");
            sb.append("Après import, chaque photo aura un timecode d'entrée/sortie pour éviter les erreurs de placement.");
        } else {
            sb.append("Piste 2 — images de remplacement timecodées :\n");
            for (int i = 0; i < replacementImageUris.size(); i++) {
                long in = start + i * seg;
                long out = in + seg;
                sb.append(String.format(Locale.US, "Plan %02d • %s → %s • %s", i + 1, formatTimecode(in), formatTimecode(out), nameOf(replacementImageUris.get(i)))).append("\n");
            }
        }
        timelineText.setText(sb.toString());
    }

    private void fillAutomaticSongPrompt() {
        String style = styleSpinner == null ? "Cinématique sombre" : String.valueOf(styleSpinner.getSelectedItem());
        String format = formatSpinner == null ? "YouTube 16:9" : String.valueOf(formatSpinner.getSelectedItem());
        String motion = motionSpinner == null ? "Conserver motion source" : String.valueOf(motionSpinner.getSelectedItem());
        String prompt = "Créer un clip vidéo cinématographique cohérent avec la chanson. " +
                "Style visuel : " + style + ". Format : " + format + ". Motion : " + motion + ". " +
                "Construire une histoire en plusieurs scènes, sans texte incrusté à l'écran. " +
                "Garder une continuité de personnages, de lieux, de lumière et d'émotion. " +
                "Respecter la durée complète de la musique. Utiliser les images importées comme références visuelles si elles existent. " +
                "Éviter les avatars/smileys sauf si l'option lip-sync est activée. Rendu final : MP4 propre, fluide, avec ambiance cinématographique.";
        if (songStoryEdit != null) songStoryEdit.setText(prompt);
        if (autoPromptText != null) autoPromptText.setText("Prompt auto généré :\n" + prompt);
        Toast.makeText(this, "Prompt automatique ajouté. Vous pouvez le modifier avant export.", Toast.LENGTH_LONG).show();
    }

    private void showPromptHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Prompt automatique musique → vidéo")
                .setMessage("Le prompt automatique sert de base de storyboard. Il décrit le style, le format, la motion et les règles de continuité. Vous pouvez ensuite ajouter vos détails : lieu, époque, personnage, émotion, couleurs, scènes interdites ou obligatoires. Pour une chanson complète, gardez le mode test 20 secondes désactivé.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showSelectedMotionHelpDialog() {
        String selected = motionSpinner == null ? "Conserver motion source" : String.valueOf(motionSpinner.getSelectedItem());
        String advice;
        if (selected.contains("source")) {
            advice = "Recommandé pour une vidéo déjà créée : ne modifie pas la motion, ne rajoute pas de zoom, protège la stabilité.";
        } else if (selected.contains("Ken")) {
            advice = "Bon pour transformer des photos en vidéo. Moins adapté si vous voulez préserver une vidéo source intacte.";
        } else if (selected.contains("Slide")) {
            advice = "Effet dynamique pour montage depuis texte ou images. À utiliser si vous voulez un mouvement visible.";
        } else if (selected.contains("Pulse")) {
            advice = "Effet lié au son. Adapté aux clips musicaux ou visualiseurs, pas aux corrections réalistes.";
        } else if (selected.contains("Rotation")) {
            advice = "Effet doux et cinématique pour images fixes. Peut donner du style, mais change la sensation originale.";
        } else if (selected.contains("Shake")) {
            advice = "Effet dramatique. À éviter si la priorité est la qualité, la stabilité et le réalisme.";
        } else {
            advice = "Sans mouvement artificiel : adapté aux remplacements précis au timecode.";
        }
        new AlertDialog.Builder(this)
                .setTitle("Motion : " + selected)
                .setMessage(advice + "\n\nRègle simple : pour remplacer des images dans une vidéo existante sans altérer la motion, choisissez toujours “Conserver motion source” ou “Image fixe timecodée”.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void adjustReplacementStart(double deltaSeconds) {
        long current = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        long delta = (long) (deltaSeconds * 1_000_000L);
        long next = Math.max(0L, current + delta);
        if (replacementStartTimeEdit != null) replacementStartTimeEdit.setText(formatTimecode(next));
        updateTimelineText();
    }

    private void seekSourcePreviewToReplacementStart() {
        if (sourceVideoPreview == null || videoToCorrectUri == null) {
            Toast.makeText(this, "Importez d'abord une vidéo source.", Toast.LENGTH_SHORT).show();
            return;
        }
        long startUs = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        try {
            sourceVideoPreview.seekTo((int) Math.max(0L, startUs / 1000L));
            Toast.makeText(this, "Aperçu placé au timecode " + formatTimecode(startUs), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Impossible de déplacer l'aperçu.", Toast.LENGTH_SHORT).show();
        }
    }

    private void validateSafePlacement() {
        long start = parseTimecodeUs(replacementStartTimeEdit == null ? "00:00:00.000" : replacementStartTimeEdit.getText().toString());
        long seg = parseSecondsToUs(replacementPlanSecondsEdit == null ? "4.5" : replacementPlanSecondsEdit.getText().toString());
        long duration = MediaMuxerTools.getDurationUs(this, videoToCorrectUri);
        boolean locksOk = (lockSourceQualityCheck == null || lockSourceQualityCheck.isChecked())
                && (lockSourceMotionCheck == null || lockSourceMotionCheck.isChecked())
                && (noCropZoomCheck == null || noCropZoomCheck.isChecked());
        StringBuilder msg = new StringBuilder();
        msg.append("Début remplacement : ").append(formatTimecode(start)).append("\n");
        msg.append("Durée par image : ").append(String.format(Locale.US, "%.2f s", seg / 1_000_000.0)).append("\n");
        msg.append("Images sélectionnées : ").append(replacementImageUris.size()).append("\n");
        if (duration > 0) msg.append("Durée vidéo source : ").append(formatTimecode(duration)).append("\n");
        msg.append("Verrous sécurité : ").append(locksOk ? "OK" : "attention, un verrou est désactivé").append("\n\n");
        msg.append("Conseil : pour ne pas altérer la vidéo, gardez qualité source, motion source et recadrage/zoom bloqué.");
        new AlertDialog.Builder(this)
                .setTitle("Validation timecode")
                .setMessage(msg.toString())
                .setPositiveButton("Compris", null)
                .show();
    }

    private String buildRuler(long durationUs) {
        if (durationUs <= 0) return "aucune durée détectée";
        StringBuilder r = new StringBuilder();
        for (int i = 0; i <= 4; i++) {
            long t = durationUs * i / 4L;
            if (i > 0) r.append(" | ");
            r.append(formatTimecode(t));
        }
        return r.toString();
    }

    private void showTimecodeHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Aide timecode")
                .setMessage("Le timecode permet de placer une photo à l'endroit exact dans la vidéo. Format conseillé : HH:MM:SS.mmm. Exemple : 00:01:12.500 commence à 1 minute 12 secondes et 500 ms. La durée de chaque photo détermine son point de sortie. Chaque image importée est listée avec entrée et sortie pour éviter les erreurs.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showMotionHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Motions expliquées")
                .setMessage("Conserver motion source : recommandé pour corriger une vidéo déjà créée. La vidéo garde son mouvement, son cadrage et sa stabilité.\n\nImage fixe timecodée : remplace une séquence par une photo sans zoom. Idéal si vous devez respecter précisément un moment.\n\nGarder motion similaire : applique un mouvement doux aux images remplacées sans changer la vidéo source.\n\nKen Burns : zoom/panoramique lent, utile pour photos seules, moins conseillé si vous voulez préserver une vidéo existante.\n\nSlide dynamique : déplacement latéral visible, utile pour une création depuis texte.\n\nPulse audio : mouvement lié au son, utile pour clip musical abstrait.\n\nRotation douce : effet cinématique léger.\n\nShake dramatique : tremblement volontaire, à éviter pour une correction réaliste ou familiale.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void showQualityHelpDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Qualité d'export")
                .setMessage("Qualité source : essaie de garder les dimensions de la vidéo importée. Recommandé pour corriger une vidéo sans l'abîmer.\n\n720p HD : plus léger.\n\n1080p Full HD : meilleur compromis.\n\n4K UHD : très lourd et plus lent sur téléphone. À utiliser seulement si la source est déjà de bonne qualité.\n\nLe verrouillage qualité source reste recommandé en mode correction.")
                .setPositiveButton("Compris", null)
                .show();
    }

    private void setBusy(boolean busy, String message) {
        if (songGenerateButton != null) songGenerateButton.setEnabled(!busy);
        if (textGenerateButton != null) textGenerateButton.setEnabled(!busy);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(!busy);
        if (openButton != null) openButton.setEnabled(!busy);
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        if (progressBar != null) progressBar.setProgress(0);
        if (statusText != null) statusText.setText(message);
        if (outputBox != null) outputBox.setVisibility(View.GONE);
    }

    private void finishJob(Uri output, String message) {
        lastOutputUri = output;
        statusText.setText(message);
        progressBar.setProgress(100);
        if (songGenerateButton != null) songGenerateButton.setEnabled(true);
        if (textGenerateButton != null) textGenerateButton.setEnabled(true);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
        if (openButton != null) openButton.setEnabled(true);
        if (outputBox != null) outputBox.setVisibility(View.VISIBLE);
        if (outputText != null) outputText.setText(message + "\nFichier : " + describeMedia(output));
        if (outputVideoPreview != null && output != null) prepareVideoPreview(outputVideoPreview, output, false);
    }

    private void failJob(Exception e) {
        String msg = e == null || e.getMessage() == null ? "erreur inconnue" : e.getMessage();
        statusText.setText("Erreur : " + msg);
        if (songGenerateButton != null) songGenerateButton.setEnabled(true);
        if (textGenerateButton != null) textGenerateButton.setEnabled(true);
        if (correctionGenerateButton != null) correctionGenerateButton.setEnabled(true);
        progressBar.setVisibility(View.GONE);
        new AlertDialog.Builder(this)
                .setTitle("Erreur de rendu")
                .setMessage(msg)
                .setPositiveButton("Compris", null)
                .show();
    }

    private void openLastVideo() {
        openUri(lastOutputUri, "video/mp4");
    }

    private void openUri(Uri uri, String mimeType) {
        if (uri == null) {
            Toast.makeText(this, "Aucun fichier sélectionné.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, mimeType);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(intent); } catch (Exception e) { Toast.makeText(this, "Aucune application compatible trouvée.", Toast.LENGTH_SHORT).show(); }
    }

    private void prepareVideoPreview(VideoView view, Uri uri, boolean autoplay) {
        if (view == null || uri == null) return;
        view.setVisibility(View.VISIBLE);
        MediaController controller = new MediaController(this);
        controller.setAnchorView(view);
        view.setMediaController(controller);
        view.setVideoURI(uri);
        view.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            try { view.seekTo(autoplay ? 0 : 250); } catch (Exception ignored) {}
            if (autoplay) view.start();
        });
    }

    private String describeMedia(Uri uri) {
        if (uri == null) return "aucun fichier";
        long durationUs = MediaMuxerTools.getDurationUs(this, uri);
        String duration = durationUs > 0 ? " • durée " + formatDuration(durationUs) : "";
        return nameOf(uri) + duration;
    }

    private String nameOf(Uri uri) {
        if (uri == null) return "";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.trim().length() > 0) return name;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "fichier sélectionné" : last;
    }

    private String formatDuration(long durationUs) {
        long total = Math.max(0L, durationUs / 1_000_000L);
        long minutes = total / 60L;
        long seconds = total % 60L;
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private void showAiCostDialog(boolean attemptLaunch) {
        String label = aiCostSpinner == null ? "" : String.valueOf(aiCostSpinner.getSelectedItem());
        CostPolicy.CostInfo info = CostPolicy.infoFor(label);
        String message = CostPolicy.buildHumanMessage(info);

        if (!attemptLaunch) {
            new AlertDialog.Builder(this)
                    .setTitle("Information coût")
                    .setMessage(message)
                    .setPositiveButton("Compris", null)
                    .show();
            return;
        }

        if (blockPaidOptionsCheck == null || blockPaidOptionsCheck.isChecked()) {
            new AlertDialog.Builder(this)
                    .setTitle("Option bloquée")
                    .setMessage(message + "\n\nAction refusée : le blocage des options payantes/cloud est activé. Aucun coût ne peut être lancé.")
                    .setPositiveButton("Garder le blocage", null)
                    .show();
            if (costSafetyText != null) costSafetyText.setText("Statut : action bloquée. Aucun coût lancé.");
            return;
        }

        final EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setHint(CostPolicy.CONSENT_PHRASE);
        input.setTextColor(Color.rgb(20, 18, 14));
        new AlertDialog.Builder(this)
                .setTitle("Confirmation obligatoire")
                .setMessage(message + "\n\nPour confirmer volontairement dans une future version cloud, il faudra taper exactement : " + CostPolicy.CONSENT_PHRASE + "\n\nDans cette version, aucun service payant n'est configuré.")
                .setView(input)
                .setPositiveButton("Confirmer", (dialog, which) -> {
                    String typed = input.getText() == null ? "" : input.getText().toString().trim();
                    if (CostPolicy.CONSENT_PHRASE.equals(typed)) {
                        if (costSafetyText != null) costSafetyText.setText("Statut : consentement compris, mais aucun module payant n'est configuré. Aucun coût lancé.");
                        Toast.makeText(this, "Aucun service payant configuré : coût impossible.", Toast.LENGTH_LONG).show();
                    } else {
                        if (costSafetyText != null) costSafetyText.setText("Statut : confirmation incorrecte. Aucun coût lancé.");
                        Toast.makeText(this, "Confirmation incorrecte : action annulée.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Annuler", (dialog, which) -> {
                    if (costSafetyText != null) costSafetyText.setText("Statut : action annulée. Aucun coût lancé.");
                })
                .show();
    }

    private LinearLayout premiumCard() {
        LinearLayout box = card();
        box.setBackground(roundedBg(Color.rgb(30, 32, 42), 2, Color.rgb(216, 180, 93), 18));
        return box;
    }

    private LinearLayout dashboardCard(String icon, String title, String desc, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        box.setGravity(Gravity.CENTER);
        box.setBackground(roundedBg(Color.rgb(38, 40, 52), 1, Color.rgb(62, 64, 76), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), dp(6), dp(4), dp(6));
        box.setLayoutParams(lp);
        TextView i = new TextView(this);
        i.setText(icon);
        i.setTextSize(24);
        i.setGravity(Gravity.CENTER);
        box.addView(i);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.rgb(244, 241, 232));
        t.setTextSize(16);
        t.setGravity(Gravity.CENTER);
        box.addView(t);
        TextView d = smallText(desc);
        d.setGravity(Gravity.CENTER);
        box.addView(d);
        box.setOnClickListener(listener);
        return box;
    }

    private GradientDrawable roundedBg(int color, int strokeDp, int strokeColor, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private LinearLayout fileCard(String title, TextView body) {
        LinearLayout box = card();
        TextView t = label(title);
        t.setPadding(0, 0, 0, dp(6));
        box.addView(t);
        box.addView(body);
        return box;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackground(roundedBg(Color.rgb(28, 30, 38), 1, Color.rgb(48, 50, 62), 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(244, 241, 232));
        v.setTextSize(20);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(18), 0, dp(8));
        return v;
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(216, 180, 93));
        v.setTextSize(14);
        v.setPadding(0, dp(12), 0, dp(4));
        return v;
    }

    private TextView smallText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(190, 188, 180));
        v.setTextSize(13);
        v.setLineSpacing(2, 1.08f);
        return v;
    }

    private EditText editText(String hint, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(Color.rgb(244, 241, 232));
        e.setHintTextColor(Color.rgb(150, 150, 145));
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setSingleLine(false);
        e.setBackgroundColor(Color.rgb(38, 40, 50));
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private Button primaryButton(String text) {
        Button b = baseButton(text);
        b.setTextColor(Color.rgb(20, 18, 14));
        b.setBackground(roundedBg(Color.rgb(216, 180, 93), 0, Color.TRANSPARENT, 14));
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = baseButton(text);
        b.setTextColor(Color.rgb(244, 241, 232));
        b.setBackground(roundedBg(Color.rgb(38, 40, 50), 1, Color.rgb(55, 57, 68), 14));
        return b;
    }

    private Button compactButton(String text) {
        Button b = secondaryButton(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), dp(6), dp(3), dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private Button tabButton(String text) {
        Button b = secondaryButton(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private Button baseButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout.LayoutParams videoLayoutParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        lp.setMargins(0, dp(8), 0, dp(8));
        return lp;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class UiProgress implements ProgressCallback {
        @Override public void onStep(String message) {
            runOnUiThread(() -> statusText.setText(message));
        }
        @Override public void onProgress(int percent) {
            runOnUiThread(() -> progressBar.setProgress(Math.max(0, Math.min(100, percent))));
        }
    }
}
